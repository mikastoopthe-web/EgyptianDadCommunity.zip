package com.egyptiandad.prayer

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.time.format.DecimalStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(this)
        val previousCrash = CrashReporter.read(this)
        if (previousCrash != null) {
            CrashReporter.show(this, previousCrash)
            return
        }
        try {
            Notifier.ensureChannel(this)
            Scheduler.scheduleNext(this)
        } catch (t: Throwable) {
            CrashReporter.save(this, t)
            CrashReporter.show(this, CrashReporter.read(this) ?: t.toString())
            return
        }
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                AppTheme { PrayerScreen() }
            }
        }
    }
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F6B5C),
    onPrimary = Color.White,
    background = Color(0xFFEDF2F0),
    onBackground = Color(0xFF14302E),
    surface = Color(0xFFF8FBFA),
    onSurface = Color(0xFF14302E),
    surfaceVariant = Color(0xFFDCE8E4),
    onSurfaceVariant = Color(0xFF587069),
    secondaryContainer = Color(0xFFCFE6E0),
    onSecondaryContainer = Color(0xFF0A3A32)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DBBA6),
    onPrimary = Color(0xFF0B1A19),
    background = Color(0xFF0F1E1F),
    onBackground = Color(0xFFE3EEEC),
    surface = Color(0xFF162829),
    onSurface = Color(0xFFE3EEEC),
    surfaceVariant = Color(0xFF1F3637),
    onSurfaceVariant = Color(0xFF93ABA6),
    secondaryContainer = Color(0xFF244B46),
    onSecondaryContainer = Color(0xFFD6EFE9)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}

private val arabic: Locale = Locale.forLanguageTag("ar-EG")
private val timeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a", arabic)
    .withDecimalStyle(DecimalStyle.of(arabic))
    .withZone(PrayerTimes.zone)

private fun formatTime(ms: Long): String = timeFormat.format(Instant.ofEpochMilli(ms))

private fun countdown(ms: Long): String {
    val s = maxOf(0L, ms / 1000)
    return String.format(arabic, "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
}

@Composable
fun PrayerScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }

    var cityId by remember { mutableStateOf(prefs.cityId) }
    var repeatMinutes by remember { mutableIntStateOf(prefs.repeatMinutes) }
    var remindersOn by remember { mutableStateOf(prefs.remindersOn) }
    var cityMenu by remember { mutableStateOf(false) }
    var version by remember { mutableIntStateOf(0) }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000)
        }
    }

    val today = PrayerTimes.today(now)
    val city = Cities.byId(cityId)
    val events = remember(cityId, today) { PrayerTimes.events(city, today) }
    val next = events.firstOrNull { it.start > now }
    val prev = events.lastOrNull { it.start <= now }
    val active = events.lastOrNull { it.start <= now && now < it.end }

    val notifOk = Notifier.hasPermission(ctx)
    val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val exactOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        Scheduler.scheduleNext(ctx)
    }

    fun reschedule() = Scheduler.scheduleNext(ctx)

    // Ask for the notification permission once, the first time the screen opens (Android 13+).
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.hasPermission(ctx)) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Column(
        modifier = Modifier
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Egyptian Dad Community", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("مواقيت الصلاة", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column {
                OutlinedButton(onClick = { cityMenu = true }) { Text(city.arabic + " ▾") }
                DropdownMenu(expanded = cityMenu, onDismissRequest = { cityMenu = false }) {
                    Cities.all.forEach { c ->
                        DropdownMenuItem(
                            text = { Text(c.arabic) },
                            onClick = {
                                cityMenu = false
                                prefs.cityId = c.id
                                cityId = c.id
                                reschedule()
                            }
                        )
                    }
                }
            }
        }

        if (!notifOk) {
            NoticeCard("لازم تسمح بالإشعارات عشان التنبيه يظهر لك، حتى والشاشة مقفولة.") {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }) { Text("اسمح بالإشعارات") }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    )
                }) { Text("افتح الإعدادات") }
            }
        }

        if (!exactOk) {
            NoticeCard("اسمح بالمنبهات الدقيقة عشان التنبيه يجيلك في الدقيقة بالظبط.") {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))
                        )
                    }
                }) { Text("اسمح بالمنبهات") }
            }
        }

        if (active != null && remindersOn && !prefs.isPrayed(active.key)) {
            NoticeCard("حان وقت ${active.prayer.arabic} — الوقت لحد ${formatTime(active.end)}. لسه ما علّمتش إنك صلّيت.") {}
        }

        // Next prayer
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isSystemInDarkTheme()) Color(0xFF1B4943) else Color(0xFF0F4F46)
            )
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val ink = Color(0xFFEAF6F3)
                Text("الصلاة الجاية", color = ink, fontSize = 14.sp)
                if (next != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(next.prayer.arabic, color = ink, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                        Text(formatTime(next.start), color = ink, fontSize = 18.sp)
                    }
                    Text(countdown(next.start - now), color = ink, fontSize = 32.sp, fontWeight = FontWeight.SemiBold)
                    if (prev != null) {
                        val fraction = ((now - prev.start).toFloat() / (next.start - prev.start).toFloat()).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFFF2C47E),
                            trackColor = Color(0x33EAF6F3)
                        )
                    }
                }
            }
        }

        // Today's prayers
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                val todays = events.filter { it.date == today }
                todays.forEachIndexed { index, e ->
                    val done = prefs.isPrayed(e.key) // re-read every second, so the notification button shows up here too
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                e.prayer.arabic + if (active?.key == e.key) "  (دلوقتي)" else "",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (active?.key == e.key) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface
                            )
                            Text(formatTime(e.start), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (done) {
                            FilledTonalButton(onClick = {
                                prefs.setPrayed(e.key, false)
                                version++
                                reschedule()
                            }) { Text("تمّت ✓") }
                        } else {
                            Button(
                                enabled = e.start <= now,
                                onClick = {
                                    prefs.setPrayed(e.key, true)
                                    Notifier.cancel(ctx, e.key)
                                    version++
                                    reschedule()
                                }
                            ) { Text("صلّيت") }
                        }
                    }
                    if (index < todays.lastIndex) HorizontalDivider()
                }
            }
        }

        // Settings
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تنبيهات الصلاة", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Switch(checked = remindersOn, onCheckedChange = {
                        remindersOn = it
                        prefs.remindersOn = it
                        reschedule()
                    })
                }

                Text("كرّر التنبيه كل (دقيقة) لحد ما تضغط \"صلّيت\":", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(10, 15, 20, 30).forEach { m ->
                        val label = String.format(arabic, "%d", m)
                        if (m == repeatMinutes) {
                            Button(
                                onClick = {},
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(label) }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    repeatMinutes = m
                                    prefs.repeatMinutes = m
                                    reschedule()
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(label) }
                        }
                    }
                }

                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                                .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CHANNEL)
                        )
                    }
                ) { Text("غيّر صوت التنبيه") }
            }
        }

        Text(
            "لو التنبيه مجاش على موبايل شاومي أو أوبو أو سامسونج، افتح إعدادات التطبيق واسمح له بالتشغيل التلقائي واستثنيه من توفير البطارية. المواقيت محسوبة بطريقة الهيئة المصرية العامة للمساحة وممكن تفرق كام دقيقة عن تقويم المسجد.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun NoticeCard(text: String, actions: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { actions() }
        }
    }
}
