package com.egyptiandad.prayer

import android.content.Context
import android.media.MediaPlayer

/** The short sound played when the app opens and when the user taps "صلّيت". */
object AppSound {
    private var player: MediaPlayer? = null

    fun play(context: Context) {
        try {
            player?.release()
            val p = MediaPlayer.create(context.applicationContext, R.raw.app_sound) ?: return
            p.setOnCompletionListener {
                it.release()
                if (player === it) player = null
            }
            player = p
            p.start()
        } catch (e: Exception) {
            player = null
        }
    }
}
