package com.egyptiandad.prayer

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

const val FACEBOOK_URL = "https://www.facebook.com/share/1JkBSfpsRh/"

/** Opens a link in the Facebook app if it is installed, otherwise in the browser. */
fun openLink(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        // No app can open the link. Nothing else to do.
    }
}
