package com.egyptiandad.prayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

/** Reads the phone's location. It needs no Google services and no internet. */
object Locations {
    /** Ask for both. Android lets the user pick "precise" or "approximate". */
    val PERMISSIONS = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)

    fun hasPermission(context: Context): Boolean =
        PERMISSIONS.any { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }

    private fun hasFine(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun lastKnown(context: Context): Location? {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        val providers = listOf(
            LocationManager.NETWORK_PROVIDER,
            LocationManager.GPS_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        for (provider in providers) {
            val found: Location? = try {
                manager.getLastKnownLocation(provider)
            } catch (e: Exception) {
                null
            }
            val current = best
            if (found != null && (current == null || found.time > current.time)) {
                best = found
            }
        }
        return best
    }

    /**
     * Asks the phone for a new position instead of an old saved one, which is what made the Qibla direction wrong.
     * Calls [onResult] once, on the main thread. If no new position arrives in 15 seconds it gives the last known
     * one, or null when there is none.
     */
    @SuppressLint("MissingPermission")
    fun fresh(context: Context, onResult: (Location?) -> Unit) {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val done = AtomicBoolean(false)
        val handler = Handler(Looper.getMainLooper())
        fun finish(location: Location?) {
            if (done.compareAndSet(false, true)) onResult(location ?: lastKnown(context))
        }

        val provider = try {
            when {
                hasFine(context) && manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> null
            }
        } catch (e: Exception) {
            null
        }
        if (provider == null) {
            finish(null)
            return
        }

        handler.postDelayed({ finish(null) }, 15_000)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                manager.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(context)) { finish(it) }
            } else {
                @Suppress("DEPRECATION")
                manager.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(location: Location) = finish(location)
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(p: String?, status: Int, extras: android.os.Bundle?) {}
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                }, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            finish(null)
        }
    }
}
