package com.egyptiandad.prayer

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Surface
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

object Qibla {
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LON = 39.8262

    /** Direction to the Kaaba in degrees clockwise from true north. */
    fun bearing(lat: Double, lon: Double): Double {
        val p1 = Math.toRadians(lat)
        val p2 = Math.toRadians(KAABA_LAT)
        val dl = Math.toRadians(KAABA_LON - lon)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /** Straight-line distance to the Kaaba in kilometres. */
    fun distanceKm(lat: Double, lon: Double): Double {
        val p1 = Math.toRadians(lat)
        val p2 = Math.toRadians(KAABA_LAT)
        val dp = p2 - p1
        val dl = Math.toRadians(KAABA_LON - lon)
        val a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 6371.0 * 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
    }
}

/** Smallest difference between two compass angles, 0 to 180. */
private fun angleDiff(a: Float, b: Float): Float {
    val d = abs(a - b) % 360f
    return if (d > 180f) 360f - d else d
}

private class CompassReading(val magneticHeading: Float?, val accuracy: Int, val hasSensor: Boolean)

/**
 * Reads the phone's heading in degrees from MAGNETIC north (null until the first reading).
 *
 * The heading is worked out from the direction the top of the screen points to and the direction the back of the
 * phone points to, added together. When the phone lies flat the first one is strong, when it is held upright the
 * second one is strong, and in between both agree. That is why the reading no longer jumps when the phone is tilted.
 * The result is smoothed as a direction (not as a number), so it never spins at the north / 360 edge.
 */
@Composable
private fun rememberCompass(): CompassReading {
    val ctx = LocalContext.current
    var heading by remember { mutableStateOf<Float?>(null) }
    var accuracy by remember { mutableIntStateOf(SensorManager.SENSOR_STATUS_ACCURACY_HIGH) }
    var hasSensor by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        val manager = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotationSensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val accelSensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val magSensor = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        val rotation = FloatArray(9)
        val remapped = FloatArray(9)
        val gravity = FloatArray(3)
        val field = FloatArray(3)
        var haveGravity = false
        var haveField = false
        var sx = 0f
        var sy = 0f
        var started = false
        var lastPublished = Float.NaN

        @Suppress("DEPRECATION")
        fun screenRotation(): Int = try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        } catch (e: Exception) {
            Surface.ROTATION_0
        }

        fun publish(matrix: FloatArray) {
            val axisX: Int
            val axisY: Int
            when (screenRotation()) {
                Surface.ROTATION_90 -> {
                    axisX = SensorManager.AXIS_Y
                    axisY = SensorManager.AXIS_MINUS_X
                }
                Surface.ROTATION_180 -> {
                    axisX = SensorManager.AXIS_MINUS_X
                    axisY = SensorManager.AXIS_MINUS_Y
                }
                Surface.ROTATION_270 -> {
                    axisX = SensorManager.AXIS_MINUS_Y
                    axisY = SensorManager.AXIS_X
                }
                else -> {
                    axisX = SensorManager.AXIS_X
                    axisY = SensorManager.AXIS_Y
                }
            }
            if (!SensorManager.remapCoordinateSystem(matrix, axisX, axisY, remapped)) return

            // World axes: x = east, y = north. Column 1 is the top of the screen, column 2 is the screen's normal.
            val east = remapped[1] - remapped[2]
            val north = remapped[4] - remapped[5]
            val len = hypot(east, north)
            if (len < 0.1f) return
            val ux = east / len
            val uy = north / len
            if (!started) {
                sx = ux
                sy = uy
                started = true
            } else {
                sx += (ux - sx) * 0.12f
                sy += (uy - sy) * 0.12f
            }
            val deg = ((Math.toDegrees(atan2(sx.toDouble(), sy.toDouble())) + 360.0) % 360.0).toFloat()
            if (lastPublished.isNaN() || angleDiff(deg, lastPublished) >= 0.6f) {
                lastPublished = deg
                heading = deg
            }
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                when (event.sensor.type) {
                    Sensor.TYPE_ROTATION_VECTOR -> {
                        // Some phones send more than 4 values, which makes the conversion crash.
                        val v = if (event.values.size > 4) event.values.copyOf(4) else event.values
                        SensorManager.getRotationMatrixFromVector(rotation, v)
                        publish(rotation)
                    }
                    Sensor.TYPE_ACCELEROMETER -> {
                        for (i in 0 until 3) {
                            gravity[i] = if (haveGravity) gravity[i] + (event.values[i] - gravity[i]) * 0.15f else event.values[i]
                        }
                        haveGravity = true
                    }
                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        for (i in 0 until 3) {
                            field[i] = if (haveField) field[i] + (event.values[i] - field[i]) * 0.15f else event.values[i]
                        }
                        haveField = true
                        if (haveGravity && SensorManager.getRotationMatrix(rotation, null, gravity, field)) publish(rotation)
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, newAccuracy: Int) {
                if (sensor != null && (sensor.type == Sensor.TYPE_MAGNETIC_FIELD || sensor.type == Sensor.TYPE_ROTATION_VECTOR)) {
                    accuracy = newAccuracy
                }
            }
        }

        // The fused rotation sensor is the steadiest. Phones without it fall back to accelerometer + magnetometer.
        if (rotationSensor != null) {
            manager.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_GAME)
        } else if (accelSensor != null && magSensor != null) {
            manager.registerListener(listener, accelSensor, SensorManager.SENSOR_DELAY_GAME)
            manager.registerListener(listener, magSensor, SensorManager.SENSOR_DELAY_GAME)
        } else {
            hasSensor = false
        }
        onDispose { manager.unregisterListener(listener) }
    }
    return CompassReading(heading, accuracy, hasSensor)
}

/** Looks up a readable place name (city, country). Needs no key; gives null when the phone cannot do it offline. */
@Suppress("DEPRECATION")
private fun reverseGeocode(ctx: Context, lat: Double, lon: Double, onResult: (String?) -> Unit) {
    fun describe(list: List<Address>?): String? {
        val a = list?.firstOrNull() ?: return null
        val place = a.locality ?: a.subAdminArea ?: a.adminArea
        val text = listOfNotNull(place, a.countryName).distinct().joinToString("، ")
        return if (text.isBlank()) null else text
    }
    try {
        if (!Geocoder.isPresent()) {
            onResult(null)
            return
        }
        val geocoder = Geocoder(ctx, Locale.forLanguageTag("ar"))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            geocoder.getFromLocation(lat, lon, 1, object : Geocoder.GeocodeListener {
                override fun onGeocode(addresses: MutableList<Address>) {
                    onResult(describe(addresses))
                }

                override fun onError(errorMessage: String?) {
                    onResult(null)
                }
            })
        } else {
            Thread {
                val found: List<Address>? = try {
                    geocoder.getFromLocation(lat, lon, 1)
                } catch (e: Exception) {
                    null
                }
                Handler(Looper.getMainLooper()).post { onResult(describe(found)) }
            }.start()
        }
    } catch (e: Exception) {
        onResult(null)
    }
}

/** A small Kaaba drawn as a 3D cube: dark faces, a gold belt and a gold door. [w] is its total width. */
private fun DrawScope.drawKaaba(cx: Float, cy: Float, w: Float) {
    val d = w * 0.26f
    val fw = w - d
    val fh = w - d
    val x0 = cx - w / 2f
    val y0 = cy - w / 2f + d

    val front = Path()
    front.moveTo(x0, y0)
    front.lineTo(x0 + fw, y0)
    front.lineTo(x0 + fw, y0 + fh)
    front.lineTo(x0, y0 + fh)
    front.close()

    val side = Path()
    side.moveTo(x0 + fw, y0)
    side.lineTo(x0 + fw + d, y0 - d)
    side.lineTo(x0 + fw + d, y0 + fh - d)
    side.lineTo(x0 + fw, y0 + fh)
    side.close()

    val top = Path()
    top.moveTo(x0, y0)
    top.lineTo(x0 + d, y0 - d)
    top.lineTo(x0 + fw + d, y0 - d)
    top.lineTo(x0 + fw, y0)
    top.close()

    drawPath(front, Brush.verticalGradient(listOf(Color(0xFF2E2E2E), Color(0xFF111111)), startY = y0, endY = y0 + fh))
    drawPath(side, Color(0xFF080808))
    drawPath(top, Color(0xFF3C3C3C))

    // The gold belt around the upper part.
    val b1 = y0 + fh * 0.18f
    val b2 = y0 + fh * 0.36f
    drawRect(Gold.Gold, Offset(x0, b1), Size(fw, b2 - b1))
    val belt = Path()
    belt.moveTo(x0 + fw, b1)
    belt.lineTo(x0 + fw + d, b1 - d)
    belt.lineTo(x0 + fw + d, b2 - d)
    belt.lineTo(x0 + fw, b2)
    belt.close()
    drawPath(belt, Gold.GoldDark)

    // The door.
    drawRect(Gold.GoldLight, Offset(x0 + fw * 0.58f, y0 + fh * 0.52f), Size(fw * 0.20f, fh * 0.48f))

    val edge = Stroke(width = w * 0.025f)
    val edgeColor = Gold.GoldDark.copy(alpha = 0.9f)
    drawPath(front, edgeColor, style = edge)
    drawPath(side, edgeColor, style = edge)
    drawPath(top, edgeColor, style = edge)
}

@Composable
fun QiblaScreen(onNavigate: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val city = Cities.of(prefs)

    // Use the phone's real position when we can get it, and the chosen city otherwise.
    var live by remember { mutableStateOf<Location?>(null) }
    var locating by remember { mutableStateOf(false) }
    var locateFailed by remember { mutableStateOf(false) }
    var place by remember { mutableStateOf<String?>(null) }
    fun locate() {
        locating = true
        locateFailed = false
        Locations.fresh(ctx) {
            if (it != null) live = it else locateFailed = true
            locating = false
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) locate()
    }
    LaunchedEffect(Unit) {
        if (Locations.hasPermission(ctx)) locate()
    }
    LaunchedEffect(live) {
        val l = live
        if (l != null) reverseGeocode(ctx, l.latitude, l.longitude) { place = it }
    }

    val lat = live?.latitude ?: city.lat
    val lon = live?.longitude ?: city.lon
    val bearing = remember(lat, lon) { Qibla.bearing(lat, lon).toFloat() }
    val distanceKm = remember(lat, lon) { Qibla.distanceKm(lat, lon).roundToInt() }
    val declination = remember(lat, lon) {
        GeomagneticField(lat.toFloat(), lon.toFloat(), 0f, System.currentTimeMillis()).declination
    }

    val compass = rememberCompass()
    val magnetic = compass.magneticHeading
    // True north = magnetic north + declination.
    val heading: Float? = if (magnetic != null) (magnetic + declination + 360f) % 360f else null
    val angle: Float = if (heading != null) (bearing - heading + 360f) % 360f else bearing
    val aligned = heading != null && angleDiff(angle, 0f) < 4f

    val haptic = LocalHapticFeedback.current
    LaunchedEffect(aligned) {
        if (aligned) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    val shownPlace = when {
        live != null -> place ?: "موقعك الحالي"
        city.id == Cities.GPS_ID -> "موقعك المحفوظ"
        else -> city.arabic + "، مصر"
    }

    val title = when {
        !compass.hasSensor -> "الموبايل مفيهوش حساس اتجاه"
        aligned -> "أنت في اتجاه القبلة"
        else -> "اتجه باتجاه القبلة"
    }

    val hint: String? = when {
        locateFailed -> "مقدرتش أحدد موقعك. شغّل الـ GPS وجرّب تاني، ولحد ما يشتغل باستخدم المدينة المختارة."
        heading != null && compass.accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW ->
            "البوصلة محتاجة معايرة: حرّك الموبايل على شكل ٨ في الهوا كذا مرة وابعد عن المعادن والمغناطيس."
        else -> null
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val screenHeight: Dp = maxHeight
        val compassSize: Dp = maxOf(minOf(maxWidth - 40.dp, screenHeight * 0.44f), 220.dp)
        val gap: Dp = screenHeight * 0.03f
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ScreenHeader(
                title = "القبلة",
                onSettings = { onNavigate(Routes.SETTINGS) },
                onProfile = { onNavigate(Routes.SETTINGS) }
            )
            Spacer(Modifier.height(gap))
            CompassDial(size = compassSize, heading = heading, angle = angle, aligned = aligned)
            Spacer(Modifier.height(gap))
            LocationPill(shownPlace)
            Spacer(Modifier.height(14.dp))
            DirectionCard(
                title = title,
                distanceText = "يبعد عنك حوالي ${arabicNumber(distanceKm)} كم",
                bearingText = "زاوية القبلة ${arabicNumber(bearing.roundToInt())}° من الشمال الحقيقي",
                angle = angle,
                aligned = aligned
            )
            Spacer(Modifier.height(16.dp))
            LocateButton(locating = locating) {
                if (Locations.hasPermission(ctx)) locate() else permissionLauncher.launch(Locations.PERMISSIONS)
            }
            if (hint != null) {
                Spacer(Modifier.height(12.dp))
                Text(
                    hint,
                    fontSize = 13.sp,
                    color = Gold.Muted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RoundIconButton(kind: IconKind, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Gold.Black.copy(alpha = 0.92f))
            .border(1.5.dp, Gold.Gold, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        GoldIcon(kind, Gold.Gold, Modifier.size(26.dp))
    }
}

@Composable
fun ScreenHeader(title: String, onSettings: () -> Unit, onProfile: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(48.dp)) {
        RoundIconButton(IconKind.SETTINGS, Modifier.align(Alignment.CenterStart), onSettings)
        Row(
            modifier = Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.width(36.dp).height(1.dp)
                    .background(Brush.horizontalGradient(listOf(Gold.Gold, Color.Transparent)))
            )
            Text(title, color = Gold.Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Box(
                Modifier.width(36.dp).height(1.dp)
                    .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold.Gold)))
            )
        }
        RoundIconButton(IconKind.PROFILE, Modifier.align(Alignment.CenterEnd), onProfile)
    }
}

@Composable
private fun CompassDial(size: Dp, heading: Float?, angle: Float, aligned: Boolean) {
    val labelPaint = remember {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
    }
    Canvas(modifier = Modifier.size(size)) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val r = this.size.minDimension / 2f - 10.dp.toPx()
        val h = heading ?: 0f

        // Soft glow around the outer ring (stronger when the phone faces the Qibla).
        drawCircle(
            brush = Brush.radialGradient(
                0.82f to Color.Transparent,
                0.94f to Gold.Gold.copy(alpha = if (aligned) 0.45f else 0.22f),
                1f to Color.Transparent,
                center = c,
                radius = r + 10.dp.toPx()
            ),
            radius = r + 10.dp.toPx(),
            center = c
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0xFF1B160B), Gold.Black), center = c, radius = r),
            radius = r,
            center = c
        )
        drawCircle(Gold.Gold, radius = r, center = c, style = Stroke(width = 2.5.dp.toPx()))
        drawCircle(Gold.GoldDark.copy(alpha = 0.85f), radius = r + 6.dp.toPx(), center = c, style = Stroke(width = 1.dp.toPx()))
        drawCircle(Gold.GoldDark.copy(alpha = 0.55f), radius = r * 0.55f, center = c, style = Stroke(width = 1.dp.toPx()))

        // The dial turns against the phone, so N always points to the real north.
        rotate(degrees = -h, pivot = c) {
            for (i in 0 until 72) {
                val cardinal = i % 18 == 0
                val major = i % 6 == 0
                val len = when {
                    cardinal -> 22.dp.toPx()
                    major -> 14.dp.toPx()
                    else -> 7.dp.toPx()
                }
                rotate(degrees = i * 5f, pivot = c) {
                    drawLine(
                        color = if (major) Gold.Gold else Gold.Gold.copy(alpha = 0.7f),
                        start = Offset(c.x, c.y - r + 7.dp.toPx()),
                        end = Offset(c.x, c.y - r + 7.dp.toPx() + len),
                        strokeWidth = if (cardinal) 3.dp.toPx() else if (major) 2.dp.toPx() else 1.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }
        }
        // The letters ride on the dial but stay upright.
        val names = listOf("N", "E", "S", "W")
        labelPaint.color = Gold.Gold.toArgb()
        labelPaint.textSize = 19.sp.toPx()
        val labelRadius = r * 0.76f
        for (k in 0 until 4) {
            val a = Math.toRadians((k * 90f - h).toDouble())
            val x = c.x + labelRadius * sin(a).toFloat()
            val y = c.y - labelRadius * cos(a).toFloat()
            drawContext.canvas.nativeCanvas.drawText(names[k], x, y + labelPaint.textSize * 0.35f, labelPaint)
        }

        // The Kaaba in the middle.
        val kaabaW = this.size.minDimension * 0.25f
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Gold.Gold.copy(alpha = 0.28f), Color.Transparent),
                center = c,
                radius = r * 0.45f
            ),
            radius = r * 0.45f,
            center = c
        )
        drawOval(
            color = Gold.Gold.copy(alpha = 0.35f),
            topLeft = Offset(c.x - kaabaW * 0.75f, c.y + kaabaW * 0.38f),
            size = Size(kaabaW * 1.5f, kaabaW * 0.36f),
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawKaaba(c.x, c.y, kaabaW)

        // The golden arrow points to the Qibla. When it points straight up, the phone is facing the Qibla.
        rotate(degrees = angle, pivot = c) {
            if (aligned) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Gold.GoldLight.copy(alpha = 0.55f), Color.Transparent),
                        center = Offset(c.x, c.y - r * 0.40f),
                        radius = r * 0.30f
                    ),
                    radius = r * 0.30f,
                    center = Offset(c.x, c.y - r * 0.40f)
                )
            }
            val arrow = Path()
            arrow.moveTo(c.x, c.y - r * 0.50f)
            arrow.lineTo(c.x + r * 0.085f, c.y - r * 0.26f)
            arrow.lineTo(c.x, c.y - r * 0.31f)
            arrow.lineTo(c.x - r * 0.085f, c.y - r * 0.26f)
            arrow.close()
            drawPath(
                arrow,
                Brush.verticalGradient(
                    listOf(Gold.GoldLight, Gold.Gold),
                    startY = c.y - r * 0.50f,
                    endY = c.y - r * 0.26f
                )
            )
            drawCircle(Gold.GoldLight, radius = 2.5.dp.toPx(), center = Offset(c.x, c.y - r * 0.56f))
        }
    }
}

@Composable
private fun LocationPill(placeText: String) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth(0.82f)
            .clip(shape)
            .background(Gold.Black.copy(alpha = 0.55f))
            .border(1.dp, Gold.GoldDark.copy(alpha = 0.8f), shape)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        GoldIcon(IconKind.PIN, Gold.Gold, Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text("أنت الآن في:", color = Gold.Muted, fontSize = 14.sp)
        Spacer(Modifier.width(6.dp))
        Text(
            placeText,
            color = Gold.Ink,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}

@Composable
private fun DirectionCard(title: String, distanceText: String, bearingText: String, angle: Float, aligned: Boolean) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Gold.Black.copy(alpha = 0.55f))
            .border(1.dp, if (aligned) Gold.Gold else Gold.GoldDark.copy(alpha = 0.8f), shape)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Gold.Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(distanceText, color = Gold.Ink.copy(alpha = 0.85f), fontSize = 15.sp)
            Spacer(Modifier.height(2.dp))
            Text(bearingText, color = Gold.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(14.dp))
        Box(Modifier.width(1.dp).height(56.dp).background(Gold.Line))
        Spacer(Modifier.width(14.dp))
        NavBadge(angle = angle, aligned = aligned)
    }
}

/** A ring with an arrow inside that turns toward the Qibla. */
@Composable
private fun NavBadge(angle: Float, aligned: Boolean) {
    Canvas(modifier = Modifier.size(58.dp)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val stroke = 2.dp.toPx()
        drawArc(
            color = Gold.Gold,
            startAngle = -70f,
            sweepAngle = 320f,
            useCenter = false,
            topLeft = Offset(stroke, stroke),
            size = Size(s - stroke * 2f, s - stroke * 2f),
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
        rotate(degrees = angle, pivot = c) {
            val arrow = Path()
            arrow.moveTo(c.x, s * 0.20f)
            arrow.lineTo(s * 0.68f, s * 0.76f)
            arrow.lineTo(c.x, s * 0.62f)
            arrow.lineTo(s * 0.32f, s * 0.76f)
            arrow.close()
            drawPath(arrow, if (aligned) Gold.GoldLight else Gold.Gold)
        }
    }
}

@Composable
private fun LocateButton(locating: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth(0.68f)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Gold.GoldLight, Gold.Gold, Gold.GoldLight)))
            .clickable(enabled = !locating, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Canvas(modifier = Modifier.size(24.dp)) {
            val s = this.size.minDimension
            val c = Offset(s / 2f, s / 2f)
            val w = 2.dp.toPx()
            drawCircle(Gold.Black, radius = s * 0.30f, center = c, style = Stroke(width = w))
            drawCircle(Gold.Black, radius = s * 0.09f, center = c)
            for (k in 0 until 4) {
                rotate(degrees = k * 90f, pivot = c) {
                    drawLine(Gold.Black, Offset(c.x, s * 0.02f), Offset(c.x, s * 0.24f), w, StrokeCap.Round)
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            if (locating) "بحدد موقعك..." else "تحديد موقعي الحالي",
            color = Gold.Black,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
