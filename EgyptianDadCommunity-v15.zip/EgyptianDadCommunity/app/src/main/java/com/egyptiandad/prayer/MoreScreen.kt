package com.egyptiandad.prayer

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MoreScreen(onNavigate: (Int) -> Unit) {
    val ctx = LocalContext.current
    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("المزيد", color = Gold.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        MoreRow(IconKind.SALAWAT, "الصلاة على النبي ﷺ", "عدّاد يتحفظ تلقائي") { onNavigate(Routes.SALAWAT) }
        MoreRow(IconKind.STREAK, "إنجازي", "سلسلتك وإحصائيات صلاتك") { onNavigate(Routes.STREAK) }
        MoreRow(IconKind.SETTINGS, "الإعدادات", "الأذان والتذكير والمدينة والعرض") { onNavigate(Routes.SETTINGS) }
        MoreRow(IconKind.FACEBOOK, "تابعنا على فيسبوك", "صفحة Egyptian Dad Community") { openLink(ctx, FACEBOOK_URL) }
    }
}

@Composable
private fun MoreRow(icon: IconKind, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Gold.Line)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Gold.SurfaceHigh)
                    .border(1.dp, Gold.GoldDark, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                GoldIcon(icon, Gold.Gold, Modifier.size(24.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Gold.Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Text("‹", color = Gold.Gold, fontSize = 26.sp)
        }
    }
}
