package com.egyptiandad.prayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.time.format.DecimalStyle

/** Starts, updates or stops the persistent countdown notification, depending on the user's setting. */
object PrayerStatus {
    fun refresh(context: Context) {
        val app = context.applicationContext
        try {
            if (Prefs(app).statusBarOn && Notifier.hasPermission(app)) {
                ContextCompat.startForegroundService(app, Intent(app, PrayerStatusService::class.java))
            } else {
                app.stopService(Intent(app, PrayerStatusService::class.java))
            }
        } catch (e: Exception) {
            // Android may refuse to start a service while the app is in the background. The next refresh retries.
        }
    }
}

class PrayerStatusService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = PrayerStatusNotification.build(this)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(PrayerStatusNotification.ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(PrayerStatusNotification.ID, notification)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        // The user may have switched it off while the service was starting.
        if (!Prefs(this).statusBarOn || !Notifier.hasPermission(this)) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }
}

object PrayerStatusNotification {
    const val ID = 4242
    private const val CHANNEL = "prayer_status"

    private val chipIds = intArrayOf(R.id.chip_0, R.id.chip_1, R.id.chip_2, R.id.chip_3, R.id.chip_4)
    private val nameIds = intArrayOf(R.id.n_0, R.id.n_1, R.id.n_2, R.id.n_3, R.id.n_4)
    private val timeIds = intArrayOf(R.id.t_0, R.id.t_1, R.id.t_2, R.id.t_3, R.id.t_4)

    private val shortTime: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm", arabicLocale)
        .withDecimalStyle(DecimalStyle.of(arabicLocale))
        .withZone(PrayerTimes.zone)

    fun build(context: Context): Notification {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val channel = NotificationChannel(CHANNEL, "العدّ التنازلي للصلاة", NotificationManager.IMPORTANCE_LOW)
            channel.description = "إشعار دائم بالصلاة الجاية ومواقيت اليوم"
            channel.setShowBadge(false)
            nm.createNotificationChannel(channel)
        }

        val prefs = Prefs(context)
        val now = System.currentTimeMillis()
        val city = Cities.of(prefs)
        val today = PrayerTimes.today(now)
        val events = PrayerTimes.events(city, today)
        val next = events.firstOrNull { it.start > now }
        val rowDate = next?.date ?: today
        val base = if (next != null) SystemClock.elapsedRealtime() + (next.start - now) else SystemClock.elapsedRealtime()
        val title = if (next != null) "الصلاة القادمة: " + next.prayer.arabic else "مواقيت الصلاة"

        fun header(v: RemoteViews) {
            v.setTextViewText(R.id.title, title)
            v.setChronometerCountDown(R.id.countdown, true)
            v.setChronometer(R.id.countdown, base, null, next != null)
        }

        val small = RemoteViews(context.packageName, R.layout.notif_small)
        header(small)

        val big = RemoteViews(context.packageName, R.layout.notif_big)
        header(big)
        for ((i, prayer) in Prayer.values().withIndex()) {
            val event = events.firstOrNull { it.date == rowDate && it.prayer == prayer }
            val highlighted = next != null && event != null && event.key == next.key
            big.setTextViewText(nameIds[i], prayer.arabic)
            big.setTextViewText(timeIds[i], if (event != null) shortTime.format(Instant.ofEpochMilli(event.start)) else "")
            big.setInt(chipIds[i], "setBackgroundResource", if (highlighted) R.drawable.notif_chip else 0)
            big.setTextColor(nameIds[i], if (highlighted) 0xFFF0D78C.toInt() else 0xFFF3EAD3.toInt())
            big.setTextColor(timeIds[i], if (highlighted) 0xFFD4AF37.toInt() else 0xFFA89E86.toInt())
        }

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(small)
            .setCustomBigContentView(big)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }
}
