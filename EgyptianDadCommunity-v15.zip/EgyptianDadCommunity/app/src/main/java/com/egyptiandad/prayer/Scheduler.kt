package com.egyptiandad.prayer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Keeps exactly one alarm pending: the next moment the phone must wake up, which is either
 * the start of the next prayer or the next repeat reminder inside a prayer that is not yet marked as prayed.
 */
object Scheduler {
    private const val REQUEST_CODE = 1001
    const val EXTRA_KEY = "key"
    const val EXTRA_AT = "at"
    const val EXTRA_REPEAT = "repeat"

    data class Trigger(val at: Long, val event: PrayerEvent, val isRepeat: Boolean)

    fun nextTrigger(prefs: Prefs, now: Long): Trigger? {
        val city = Cities.of(prefs)
        val events = PrayerTimes.events(city, PrayerTimes.today(now))
        val intervalMs = prefs.repeatMinutes * 60_000L

        var best: Trigger? = events.firstOrNull { it.start > now }?.let { Trigger(it.start, it, false) }

        val active = events.lastOrNull { it.start <= now && now < it.end }
        if (prefs.remindersOn && active != null && !prefs.isPrayed(active.key)) {
            val n = (now - active.start) / intervalMs + 1
            val at = active.start + n * intervalMs
            if (at < active.end && (best == null || at < best.at)) {
                best = Trigger(at, active, true)
            }
        }
        return best
    }

    fun scheduleNext(context: Context, nowOverride: Long? = null) {
        val app = context.applicationContext
        val prefs = Prefs(app)
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // The alarm is needed for reminders and also to refresh the persistent countdown notification at each prayer.
        val trigger = if (prefs.remindersOn || prefs.statusBarOn) {
            nextTrigger(prefs, nowOverride ?: System.currentTimeMillis())
        } else {
            null
        }
        if (trigger == null) {
            am.cancel(pendingIntent(app, null))
        } else {
            arm(app, am, trigger)
        }
        PrayerStatus.refresh(app)
    }

    private fun arm(app: Context, am: AlarmManager, trigger: Trigger) {
        val pi = pendingIntent(app, trigger)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger.at, pi)
            } else {
                val show = PendingIntent.getActivity(
                    app, 0, Intent(app, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(trigger.at, show), pi)
            }
        } catch (e: SecurityException) {
            // Newer Android versions refuse exact alarms without the permission.
            // An inexact alarm needs no permission and may be a few minutes late, but the app keeps working.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger.at, pi)
        }
    }

    private fun pendingIntent(context: Context, trigger: Trigger?): PendingIntent {
        val intent = Intent(context, PrayerReceiver::class.java)
        if (trigger != null) {
            intent.putExtra(EXTRA_KEY, trigger.event.key)
            intent.putExtra(EXTRA_AT, trigger.at)
            intent.putExtra(EXTRA_REPEAT, trigger.isRepeat)
        }
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
