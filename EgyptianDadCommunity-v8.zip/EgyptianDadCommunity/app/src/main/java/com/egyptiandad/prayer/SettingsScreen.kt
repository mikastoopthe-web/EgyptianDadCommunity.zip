package com.egyptiandad.prayer

import android.Manifest
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }

    var cityId by remember { mutableStateOf(prefs.cityId) }
    var remindersOn by remember { mutableStateOf(prefs.remindersOn) }
    var repeat by remember { mutableIntStateOf(prefs.repeatMinutes) }
    var statusOn by remember { mutableStateOf(prefs.statusBarOn) }
    var adhanOn by remember { mutableStateOf(prefs.adhanOn) }
    var muezzin by remember { mutableIntStateOf(prefs.muezzin) }
    var scale by remember { mutableFloatStateOf(prefs.textScale) }
    var locationMessage by remember { mutableStateOf("") }
    var playing by remember { mutableIntStateOf(0) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE")
    val tick = refresh

    val muezzins = Notifier.muezzinResIds(ctx)

    DisposableEffect(Unit) {
        onDispose {
            runCatching { player?.release() }
            player = null
        }
    }

    fun changed() {
        Scheduler.scheduleNext(ctx)
    }

    fun useLocation() {
        val loc = Locations.lastKnown(ctx)
        if (loc == null) {
            locationMessage = "مش لاقي موقع محفوظ على الموبايل. شغّل الموقع (GPS)، افتح خرائط جوجل مرة، وارجع جرّب تاني."
            return
        }
        val inEgypt = loc.latitude in 21.5..32.0 && loc.longitude in 24.5..37.0
        if (!inEgypt) {
            locationMessage = "موقعك خارج مصر. المواقيت هنا محسوبة بطريقة الهيئة المصرية، فاختار أقرب مدينة من القايمة."
            return
        }
        prefs.lat = loc.latitude.toFloat()
        prefs.lon = loc.longitude.toFloat()
        prefs.cityId = Cities.GPS_ID
        cityId = Cities.GPS_ID
        locationMessage = "تم استخدام موقعك الحالي."
        changed()
    }

    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) useLocation() else locationMessage = "من غير إذن الموقع اختار مدينتك من القايمة."
        refresh++
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh++
        changed()
    }

    fun preview(number: Int, resId: Int) {
        runCatching { player?.release() }
        player = null
        if (playing == number) {
            playing = 0
            return
        }
        val mp = MediaPlayer.create(ctx, resId)
        if (mp == null) {
            playing = 0
            return
        }
        mp.setOnCompletionListener {
            playing = 0
            runCatching { it.release() }
            if (player === it) player = null
        }
        player = mp
        playing = number
        mp.start()
    }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("الإعدادات", color = Gold.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Section("المدينة ومواقيت الصلاة") {
            for (city in Cities.all) {
                RadioRow(city.arabic, cityId == city.id) {
                    prefs.cityId = city.id
                    cityId = city.id
                    changed()
                }
            }
            if (cityId == Cities.GPS_ID) RadioRow("موقعي الحالي", true) {}
            OutlinedButton(onClick = {
                if (Locations.hasPermission(ctx)) useLocation()
                else locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            }) { Text("استخدم موقعي الحالي") }
            if (locationMessage.isNotEmpty()) {
                Text(locationMessage, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Hint("الموقع بيتقرا مرة واحدة وبيتخزن على موبايلك بس، ومبيتبعتش لأي مكان.")
        }

        Section("التذكير") {
            SwitchRow("تذكير الصلاة", remindersOn) {
                remindersOn = it
                prefs.remindersOn = it
                changed()
            }
            SwitchRow("إشعار دائم بالعدّ التنازلي", statusOn) {
                statusOn = it
                prefs.statusBarOn = it
                changed()
            }
            Text("كرر التذكير كل", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (m in listOf(10, 15, 20, 30)) {
                    FilterChip(
                        selected = repeat == m,
                        onClick = {
                            repeat = m
                            prefs.repeatMinutes = m
                            changed()
                        },
                        label = { Text(arabicNumber(m) + " د") }
                    )
                }
            }
            Hint("التكرار بيستمر لحد ما تضغط \"صلّيت\" أو الوقت يخلص.")
        }

        Section("الأذان") {
            if (muezzins.isEmpty()) {
                Hint("مفيش ملف أذان في التطبيق.")
            } else {
                SwitchRow("تشغيل صوت الأذان", adhanOn) {
                    adhanOn = it
                    prefs.adhanOn = it
                }
                for (p in Prayer.values()) {
                    var on by remember { mutableStateOf(prefs.adhanFor(p)) }
                    SwitchRow("أذان " + p.arabic, on && adhanOn, enabled = adhanOn) {
                        on = it
                        prefs.setAdhanFor(p, it)
                    }
                }
                Text("المؤذن", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                muezzins.forEachIndexed { index, resId ->
                    val number = index + 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                muezzin = number
                                prefs.muezzin = number
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = muezzin == number, onClick = {
                            muezzin = number
                            prefs.muezzin = number
                        })
                        Text("المؤذن " + arabicNumber(number), modifier = Modifier.weight(1f))
                        TextButton(onClick = { preview(number, resId) }) {
                            Text(if (playing == number) "إيقاف" else "استمع")
                        }
                    }
                }
                Hint("لو غيّرت صوت الإشعار من إعدادات الأندرويد، التغيير هناك هو اللي بيمشي.")
            }
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                )
            }) { Text("إعدادات إشعارات التطبيق") }
        }

        Section("العرض") {
            Text("حجم الخط", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((label, value) in listOf("عادي" to 1f, "كبير" to 1.15f, "كبير جدًا" to 1.3f)) {
                    FilterChip(
                        selected = scale == value,
                        onClick = {
                            scale = value
                            prefs.textScale = value
                            UiState.textScale = value
                        },
                        label = { Text(label) }
                    )
                }
            }
        }

        Section("الصلاحيات") {
            val notifOk = Notifier.hasPermission(ctx)
            PermissionRow("الإشعارات", notifOk) {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            PermissionRow("الموقع (اختياري)", Locations.hasPermission(ctx)) {
                locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
            Hint("عشان التنبيه يوصل والشاشة مقفولة، اسمح للتطبيق إنه يشتغل في الخلفية من إعدادات البطارية ومتخليش الموبايل يقفله (خصوصًا في هونر وشاومي وسامسونج).")
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }) { Text("إعدادات البطارية") }
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                )
            }) { Text("إعدادات التطبيق") }
        }

        Section("تابعنا") {
            Hint("تابع صفحتنا على فيسبوك لآخر التحديثات.")
            Button(onClick = { openLink(ctx, FACEBOOK_URL) }) { Text("افتح صفحة فيسبوك") }
        }

        Section("الحساب") {
            Hint("مفيش تسجيل دخول أو حسابات دلوقتي. كل بياناتك (الصلوات، الأذكار، الصلاة على النبي) متخزنة على موبايلك بس. لو مسحت بيانات التطبيق هتتمسح.")
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Gold.Line)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, color = Gold.GoldLight, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun PermissionRow(label: String, granted: Boolean, onRequest: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        if (granted) Text("مسموح ✓", color = Gold.Gold)
        else TextButton(onClick = onRequest) { Text("اسمح") }
    }
}
