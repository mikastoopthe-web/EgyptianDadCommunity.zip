package com.egyptiandad.prayer

import android.content.Context
import java.time.LocalDate

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("prayer", Context.MODE_PRIVATE)

    var cityId: String
        get() = sp.getString("city", "cairo") ?: "cairo"
        set(v) { sp.edit().putString("city", v).apply() }

    /** Coordinates read once from the phone when the user taps "use my location". */
    var lat: Float
        get() = sp.getFloat("lat", 0f)
        set(v) { sp.edit().putFloat("lat", v).apply() }

    var lon: Float
        get() = sp.getFloat("lon", 0f)
        set(v) { sp.edit().putFloat("lon", v).apply() }

    val hasLocation: Boolean
        get() = sp.contains("lat") && sp.contains("lon")

    var repeatMinutes: Int
        get() = sp.getInt("repeat", 10)
        set(v) { sp.edit().putInt("repeat", v).apply() }

    var remindersOn: Boolean
        get() = sp.getBoolean("on", true)
        set(v) { sp.edit().putBoolean("on", v).apply() }

    /** Persistent notification with the countdown to the next prayer. */
    var statusBarOn: Boolean
        get() = sp.getBoolean("status_bar", true)
        set(v) { sp.edit().putBoolean("status_bar", v).apply() }

    /** Master switch for the adhan sound. */
    var adhanOn: Boolean
        get() = sp.getBoolean("adhan", true)
        set(v) { sp.edit().putBoolean("adhan", v).apply() }

    fun adhanFor(prayer: Prayer): Boolean = sp.getBoolean("adhan_" + prayer.name, true)

    fun setAdhanFor(prayer: Prayer, value: Boolean) {
        sp.edit().putBoolean("adhan_" + prayer.name, value).apply()
    }

    /** Which muezzin, starting at 1. */
    var muezzin: Int
        get() = sp.getInt("muezzin", 1)
        set(v) { sp.edit().putInt("muezzin", v).apply() }

    /** 1.0 normal, 1.15 large, 1.3 extra large. */
    var textScale: Float
        get() = sp.getFloat("text_scale", 1f)
        set(v) { sp.edit().putFloat("text_scale", v).apply() }

    fun firstUse(): LocalDate {
        val saved = sp.getString("first_use", null)
        if (saved != null) return LocalDate.parse(saved)
        val today = LocalDate.now()
        sp.edit().putString("first_use", today.toString()).apply()
        return today
    }

    fun isPrayed(key: String): Boolean =
        sp.getStringSet("prayed", emptySet())?.contains(key) == true

    /** A copy of every "yyyy-MM-dd:PRAYER" key marked as prayed. */
    fun prayedSet(): Set<String> = HashSet(sp.getStringSet("prayed", emptySet()) ?: emptySet())

    fun setPrayed(key: String, value: Boolean) {
        val set = HashSet(sp.getStringSet("prayed", emptySet()) ?: emptySet())
        if (value) set.add(key) else set.remove(key)
        val cutoff = LocalDate.now().minusDays(400).toString()
        set.removeAll { it.take(10) < cutoff } // keys look like 2026-11-14:ASR
        sp.edit().putStringSet("prayed", set).commit()
    }

    fun dhikrCount(date: String, period: String, index: Int): Int =
        sp.getInt("dk:$date:$period:$index", 0)

    fun setDhikrCount(date: String, period: String, index: Int, value: Int) {
        val editor = sp.edit()
        editor.putInt("dk:$date:$period:$index", value)
        val cutoff = LocalDate.now().minusDays(3).toString()
        for (k in sp.all.keys) {
            if (k.startsWith("dk:") && k.length > 13 && k.substring(3, 13) < cutoff) editor.remove(k)
        }
        editor.apply()
    }

    var salawatTotal: Long
        get() = sp.getLong("sl_total", 0L)
        set(v) { sp.edit().putLong("sl_total", v).apply() }

    fun salawatToday(date: String): Int =
        if (sp.getString("sl_date", "") == date) sp.getInt("sl_today", 0) else 0

    fun addSalawat(date: String) {
        val today = salawatToday(date) + 1
        sp.edit()
            .putLong("sl_total", salawatTotal + 1L)
            .putString("sl_date", date)
            .putInt("sl_today", today)
            .apply()
    }

    fun resetSalawat() {
        sp.edit().putLong("sl_total", 0L).putInt("sl_today", 0).apply()
    }
}
