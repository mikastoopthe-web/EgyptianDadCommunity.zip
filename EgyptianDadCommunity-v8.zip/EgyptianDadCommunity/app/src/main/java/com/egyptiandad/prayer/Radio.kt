package com.egyptiandad.prayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

data class Station(val name: String, val description: String, val url: String)

/** Stream addresses. Change them here if a station moves. */
object Stations {
    val all = listOf(
        Station(
            "إذاعة القرآن الكريم من القاهرة",
            "بث مباشر على مدار الساعة",
            "https://stream.radiojar.com/8s5u5tpdtwzuv"
        ),
        Station(
            "إذاعة الزين محمد أحمد",
            "تلاوات متواصلة",
            "https://Qurango.net/radio/alzain_mohammad_ahmad"
        ),
        Station(
            "إذاعة أحمد خضر الطرابلسي",
            "تلاوات متواصلة",
            "https://Qurango.net/radio/ahmad_khader_altarabulsi"
        )
    )
}

enum class RadioStatus { IDLE, LOADING, PLAYING, ERROR }

/** What the radio screen shows. The service updates it. */
object RadioState {
    var status by mutableStateOf(RadioStatus.IDLE)
    var station by mutableIntStateOf(0)
}

class RadioService : Service() {
    companion object {
        const val ACTION_PLAY = "com.egyptiandad.prayer.RADIO_PLAY"
        const val ACTION_STOP = "com.egyptiandad.prayer.RADIO_STOP"
        const val EXTRA_STATION = "station"
        private const val CHANNEL = "radio"
        private const val NOTIFICATION_ID = 7001

        @Volatile
        var current: RadioService? = null

        fun play(context: Context, station: Int) {
            val intent = Intent(context, RadioService::class.java)
                .setAction(ACTION_PLAY)
                .putExtra(EXTRA_STATION, station)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop() {
            current?.stopPlayback()
            RadioState.status = RadioStatus.IDLE
        }
    }

    private var player: ExoPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        current = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> startPlayback(intent.getIntExtra(EXTRA_STATION, 0))
            ACTION_STOP -> stopPlayback()
            else -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    private fun startPlayback(index: Int) {
        val station = Stations.all[index.coerceIn(0, Stations.all.size - 1)]
        RadioState.station = Stations.all.indexOf(station)
        RadioState.status = RadioStatus.LOADING

        val notification = buildNotification(station)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        player?.release()
        val exo = ExoPlayer.Builder(this).build()
        exo.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
        exo.setHandleAudioBecomingNoisy(true)
        exo.setWakeMode(C.WAKE_MODE_NETWORK)
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_BUFFERING) RadioState.status = RadioStatus.LOADING
                if (state == Player.STATE_READY) RadioState.status = RadioStatus.PLAYING
            }

            override fun onPlayerError(error: PlaybackException) {
                RadioState.status = RadioStatus.ERROR
                stopPlayback(keepStatus = true)
            }
        })
        exo.setMediaItem(MediaItem.fromUri(station.url))
        exo.playWhenReady = true
        exo.prepare()
        player = exo
    }

    fun stopPlayback(keepStatus: Boolean = false) {
        player?.release()
        player = null
        if (!keepStatus) RadioState.status = RadioStatus.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        if (current === this) current = null
        super.onDestroy()
    }

    private fun buildNotification(station: Station): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val channel = NotificationChannel(CHANNEL, "الإذاعة", NotificationManager.IMPORTANCE_LOW)
            channel.description = "تشغيل إذاعة القرآن الكريم"
            nm.createNotificationChannel(channel)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RadioService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setContentTitle(station.name)
            .setContentText("بث مباشر")
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "إيقاف", stop)
            .build()
    }
}
