package com.egyptiandad.prayer

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RadioScreen() {
    val ctx = LocalContext.current
    val status = RadioState.status
    val selected = RadioState.station
    val active = status == RadioStatus.LOADING || status == RadioStatus.PLAYING

    fun toggle(index: Int) {
        if (active && index == selected) {
            RadioService.stop()
        } else {
            RadioState.station = index
            RadioState.status = RadioStatus.LOADING
            RadioService.play(ctx, index)
        }
    }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val wave by pulse.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "wave"
    )

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "إذاعة القرآن الكريم",
            color = Gold.Gold,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )

        Box(modifier = Modifier.size(220.dp), contentAlignment = Alignment.Center) {
            if (status == RadioStatus.PLAYING) {
                Canvas(modifier = Modifier.size(220.dp)) {
                    for (k in 0 until 2) {
                        val t = (wave + k * 0.5f) % 1f
                        drawCircle(
                            color = Gold.Gold.copy(alpha = (1f - t) * 0.5f),
                            radius = size.minDimension * (0.30f + 0.20f * t),
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }
                }
            }
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Gold.GoldLight, Gold.Gold, Gold.GoldDark)))
                    .clickable { toggle(selected) },
                contentAlignment = Alignment.Center
            ) {
                GoldIcon(
                    if (active) IconKind.STOP else IconKind.PLAY,
                    Gold.Black,
                    Modifier.size(52.dp)
                )
            }
        }

        Text(
            Stations.all[selected].name,
            color = Gold.GoldLight,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Text(
            when (status) {
                RadioStatus.IDLE -> "اضغط للتشغيل"
                RadioStatus.LOADING -> "جاري الاتصال..."
                RadioStatus.PLAYING -> "بث مباشر الآن"
                RadioStatus.ERROR -> "تعذّر التشغيل. تأكد من الإنترنت وجرّب تاني."
            },
            color = if (status == RadioStatus.ERROR) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Gold.Line)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Stations.all.forEachIndexed { index, station ->
                    val isSelected = index == selected
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) Gold.SurfaceHigh else Gold.Surface)
                            .clickable { toggle(index) }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                station.name,
                                color = if (isSelected) Gold.Gold else Gold.Ink,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(station.description, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                        GoldIcon(
                            if (active && isSelected) IconKind.STOP else IconKind.PLAY,
                            Gold.Gold,
                            Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        Text(
            "الإذاعة بتحتاج إنترنت، وبتكمل شغل والشاشة مقفولة. بتقف لوحدها لما الأذان يبدأ.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}
