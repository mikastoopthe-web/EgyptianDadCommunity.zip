package com.egyptiandad.prayer

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.format.DecimalStyle

private val timeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a", arabicLocale)
    .withDecimalStyle(DecimalStyle.of(arabicLocale))
    .withZone(PrayerTimes.zone)

fun formatTime(ms: Long): String = timeFormat.format(Instant.ofEpochMilli(ms))

fun countdown(ms: Long): String {
    val s = maxOf(0L, ms / 1000)
    return String.format(arabicLocale, "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
}

private fun two(n: Long): String = String.format(arabicLocale, "%02d", n)

private fun gregorianLine(today: LocalDate): String = runCatching {
    DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", arabicLocale).format(today)
}.getOrDefault("")

private fun hijriLine(today: LocalDate): String = runCatching {
    DateTimeFormatter.ofPattern("d MMMM yyyy", arabicLocale).format(HijrahDate.from(today)) + " هـ"
}.getOrDefault("")

private val Green = Color(0xFF4CAF50)

@Composable
fun TimesScreen(onNavigate: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var version by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE")
    val refreshTick = version

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000)
        }
    }

    val today = PrayerTimes.today(now)
    val city = Cities.of(prefs)
    val events = remember(city, today) { PrayerTimes.events(city, today) }
    val next = events.firstOrNull { it.start > now }
    val prev = events.lastOrNull { it.start <= now }
    val active = events.lastOrNull { it.start <= now && now < it.end }
    val done = prefs.prayedSet()
    val todayEvents = events.filter { it.date == today }
    val prayedToday = Streaks.dayCount(done, today)

    val notifOk = Notifier.hasPermission(ctx)
    val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val exactOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        Scheduler.scheduleNext(ctx)
    }

    // Ask for the notification permission once, the first time the screen opens (Android 13+).
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.hasPermission(ctx)) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun mark(key: String, value: Boolean) {
        prefs.setPrayed(key, value)
        if (value) Notifier.cancel(ctx, key)
        version++
        Scheduler.scheduleNext(ctx)
    }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        HomeHeader(onProfile = { onNavigate(Routes.SETTINGS) })

        DateLocationBar(
            gregorian = gregorianLine(today),
            hijri = hijriLine(today),
            cityName = city.arabic,
            onLocation = { onNavigate(Routes.SETTINGS) }
        )

        if (!notifOk) {
            NoticeCard("لازم تسمح بالإشعارات عشان التنبيه يظهر لك، حتى والشاشة مقفولة.") {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }) { Text("اسمح بالإشعارات") }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    )
                }) { Text("افتح الإعدادات") }
            }
        }

        if (!exactOk) {
            NoticeCard("اسمح بالمنبهات الدقيقة عشان التنبيه يجيلك في الدقيقة بالظبط.") {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))
                        )
                    }
                }) { Text("اسمح بالمنبهات") }
            }
        }

        if (next != null) {
            NextPrayerCard(
                name = next.prayer.arabic,
                time = formatTime(next.start),
                remainingSeconds = maxOf(0L, (next.start - now) / 1000),
                fraction = if (prev != null && next.start > prev.start) {
                    ((now - prev.start).toFloat() / (next.start - prev.start).toFloat()).coerceIn(0f, 1f)
                } else {
                    0f
                }
            )
        }

        FeatureRow(
            listOf(
                Triple(IconKind.QIBLA, "القبلة", { onNavigate(Routes.QIBLA) }),
                Triple(IconKind.RADIO, "الإذاعة", { onNavigate(Routes.RADIO) }),
                Triple(IconKind.ADHKAR, "الأذكار", { onNavigate(Routes.ADHKAR) }),
                Triple(IconKind.SALAWAT, "الصلاة ﷺ", { onNavigate(Routes.SALAWAT) }),
                Triple(IconKind.TROPHY, "إنجازي", { onNavigate(Routes.STREAK) })
            )
        )

        // The prayer that is running now and has not been marked (this also covers last night's Isha after midnight).
        if (active != null && !done.contains(active.key)) {
            val carry = active.date != today
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                border = BorderStroke(1.dp, Gold.GoldDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "حان وقت " + active.prayer.arabic + if (carry) " (إمبارح)" else "",
                            color = Gold.Gold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "الوقت لحد " + formatTime(active.end),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                    Button(onClick = { mark(active.key, true) }) { Text("صلّيت") }
                }
            }
        }

        TodayStatusCard(prayedToday)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoldIcon(IconKind.HOME, Gold.Gold, Modifier.size(24.dp))
            Text("مواقيت الصلاة اليوم", color = Gold.GoldLight, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (e in todayEvents) {
                val prayed = done.contains(e.key)
                val started = e.start <= now
                val isNext = next != null && next.key == e.key
                PrayerChip(
                    name = e.prayer.arabic,
                    time = formatTime(e.start),
                    state = when {
                        prayed -> ChipState.PRAYED
                        isNext -> ChipState.NEXT
                        started -> ChipState.TO_MARK
                        else -> ChipState.LATER
                    },
                    modifier = Modifier.weight(1f),
                    onClick = { if (started) mark(e.key, !prayed) }
                )
            }
        }
        Text(
            "اضغط على صلاة فاتت عشان تسجّلها أو تلغي تسجيلها.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedButton(
            onClick = { openLink(ctx, FACEBOOK_URL) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تابعنا على فيسبوك") }

        Text(
            "المواقيت محسوبة بطريقة الهيئة المصرية العامة للمساحة وممكن تفرق كام دقيقة عن تقويم المسجد.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HomeHeader(onProfile: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(50.dp)
                .clip(CircleShape)
                .background(Gold.Surface.copy(alpha = 0.9f))
                .border(1.5.dp, Gold.Gold, CircleShape)
                .clickable(onClick = onProfile),
            contentAlignment = Alignment.Center
        ) {
            GoldIcon(IconKind.SETTINGS, Gold.Gold, Modifier.size(26.dp))
        }
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Egyptian Dad Community", color = Gold.Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("مجتمع الأبوة .. نحو حياة أفضل", color = Gold.GoldLight, fontSize = 14.sp)
        }
    }
}

@Composable
private fun DateLocationBar(gregorian: String, hijri: String, cityName: String, onLocation: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Gold.Surface.copy(alpha = 0.88f))
            .border(1.dp, Gold.GoldDark.copy(alpha = 0.7f), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GoldIcon(IconKind.CALENDAR, Gold.Gold, Modifier.size(26.dp))
        Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(gregorian, color = Gold.Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            if (hijri.isNotEmpty()) Text(hijri, color = Gold.Muted, fontSize = 12.sp)
        }
        Box(modifier = Modifier.width(1.dp).height(36.dp).background(Gold.Line))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onLocation)
                .padding(start = 12.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GoldIcon(IconKind.PIN, Gold.Gold, Modifier.size(24.dp))
            Column {
                Text("موقعي الحالي", color = Gold.Muted, fontSize = 11.sp)
                Text("$cityName ˅", color = Gold.Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun NextPrayerCard(name: String, time: String, remainingSeconds: Long, fraction: Float) {
    val shape = RoundedCornerShape(28.dp)
    val hours = remainingSeconds / 3600
    val minutes = remainingSeconds % 3600 / 60
    val seconds = remainingSeconds % 60

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.5.dp, Brush.linearGradient(listOf(Gold.GoldLight, Gold.GoldDark, Gold.Gold)), shape)
    ) {
        Image(
            painter = painterResource(R.drawable.hero_mosque),
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(Color(0x80000000), Color(0x10000000), Color(0xE6000000))))
        )
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Gold.Gold)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                GoldIcon(IconKind.HOME, Gold.Black, Modifier.size(18.dp))
                Text("الصلاة القادمة", color = Gold.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Text(name, color = Gold.Gold, fontSize = 54.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GoldIcon(IconKind.CLOCK, Gold.GoldLight, Modifier.size(30.dp))
                Text(time, color = Gold.Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(80.dp))

            val panelShape = RoundedCornerShape(22.dp)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(panelShape)
                    .background(Color(0xD90A0908))
                    .border(1.dp, Gold.GoldDark, panelShape)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "متبقي على صلاة $name",
                    color = Gold.Ink,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeBox(two(hours), "ساعة")
                        TimeBox(two(minutes), "دقيقة")
                        TimeBox(two(seconds), "ثانية")
                    }
                    ProgressRing(fraction)
                }
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                    color = Gold.Gold,
                    trackColor = Gold.Line
                )
            }
        }
    }
}

@Composable
private fun TimeBox(value: String, label: String) {
    Column(
        modifier = Modifier
            .width(62.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Gold.SurfaceHigh.copy(alpha = 0.8f))
            .border(1.dp, Gold.Line, RoundedCornerShape(14.dp))
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = Gold.Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Gold.Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ProgressRing(fraction: Float) {
    Box(modifier = Modifier.size(64.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(64.dp)) {
            val stroke = 5.dp.toPx()
            val inset = stroke / 2f
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawCircle(Gold.Line, radius = (size.minDimension - stroke) / 2f, style = Stroke(width = stroke))
            drawArc(
                color = Gold.Gold,
                startAngle = -90f,
                sweepAngle = 360f * fraction,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        GoldIcon(IconKind.HOURGLASS, Gold.Gold, Modifier.size(26.dp))
    }
}

@Composable
private fun TodayStatusCard(prayedToday: Int) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Gold.SurfaceHigh.copy(alpha = 0.95f), Gold.Surface.copy(alpha = 0.95f))))
            .border(1.dp, Gold.GoldDark, shape)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GoldIcon(IconKind.CHECK, Gold.Gold, Modifier.size(20.dp))
                Text("حالة اليوم", color = Gold.Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "تم تسجيل " + arabicNumber(prayedToday) + " من ٥ صلوات",
                color = Gold.Ink,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                when (prayedToday) {
                    5 -> "ما شاء الله، أكملت صلواتك النهارده"
                    0 -> "ابدأ يومك بالصلاة"
                    else -> "أحسنت، واصل على التميز"
                },
                color = Gold.Muted,
                fontSize = 13.sp
            )
        }
        GoldIcon(IconKind.TROPHY, Gold.Gold, Modifier.size(72.dp))
    }
}

private enum class ChipState { PRAYED, NEXT, TO_MARK, LATER }

@Composable
private fun PrayerChip(name: String, time: String, state: ChipState, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val isNext = state == ChipState.NEXT
    val textColor = if (isNext) Gold.Black else Gold.Ink
    Column(
        modifier = modifier
            .clip(shape)
            .background(if (isNext) Gold.Gold else Gold.Surface.copy(alpha = 0.9f))
            .border(1.dp, if (isNext) Gold.GoldLight else Gold.Line, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(name, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(time, color = textColor, fontSize = 12.sp, maxLines = 1)
        when (state) {
            ChipState.PRAYED -> Row(verticalAlignment = Alignment.CenterVertically) {
                GoldIcon(IconKind.CHECK, Green, Modifier.size(14.dp))
                Text(" تمّت", color = Green, fontSize = 11.sp)
            }
            ChipState.NEXT -> Row(verticalAlignment = Alignment.CenterVertically) {
                GoldIcon(IconKind.CLOCK, Gold.Black, Modifier.size(13.dp))
                Text(" قادمة", color = Gold.Black, fontSize = 11.sp)
            }
            ChipState.TO_MARK -> Text("سجّل", color = Gold.Gold, fontSize = 11.sp)
            ChipState.LATER -> Text("لاحقًا", color = Gold.Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun NoticeCard(text: String, actions: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        border = BorderStroke(1.dp, Gold.GoldDark)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { actions() }
        }
    }
}
