package com.egyptiandad.prayer

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Screen numbers. The first five are in the bottom bar, the rest open from "More". */
object Routes {
    const val HOME = 0
    const val QIBLA = 1
    const val RADIO = 2
    const val ADHKAR = 3
    const val MORE = 4
    const val SALAWAT = 10
    const val STREAK = 11
    const val SETTINGS = 12
}

@Composable
fun AppRoot() {
    var route by remember { mutableIntStateOf(Routes.HOME) }
    val inSubPage = route >= 10
    val barSelected = if (inSubPage) Routes.MORE else route

    // Back goes from a sub-page to "More", and from any other screen to Home.
    BackHandler(enabled = route != Routes.HOME) {
        route = if (inSubPage) Routes.MORE else Routes.HOME
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (route == Routes.HOME) {
            Image(
                painter = painterResource(R.drawable.bg_lanterns),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter
            )
        } else {
            GeometricBackground()
        }
        Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
            Box(modifier = Modifier.weight(1f)) {
                Crossfade(targetState = route, animationSpec = tween(250), label = "screen") { page ->
                    when (page) {
                        Routes.HOME -> TimesScreen(onNavigate = { route = it })
                        Routes.QIBLA -> QiblaScreen()
                        Routes.RADIO -> RadioScreen()
                        Routes.ADHKAR -> AdhkarScreen()
                        Routes.MORE -> MoreScreen(onNavigate = { route = it })
                        Routes.SALAWAT -> SalawatScreen()
                        Routes.STREAK -> StreakScreen()
                        else -> SettingsScreen()
                    }
                }
            }
            FloatingBar(selected = barSelected, onSelect = { route = it })
        }
    }
}

private data class BarItem(val route: Int, val label: String, val icon: IconKind)

private val barItems = listOf(
    BarItem(Routes.HOME, "الرئيسية", IconKind.HOME),
    BarItem(Routes.QIBLA, "القبلة", IconKind.QIBLA),
    BarItem(Routes.RADIO, "الإذاعة", IconKind.RADIO),
    BarItem(Routes.ADHKAR, "الأذكار", IconKind.ADHKAR),
    BarItem(Routes.MORE, "المزيد", IconKind.MORE)
)

@Composable
private fun FloatingBar(selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(shape)
            .background(Gold.Surface)
            .border(1.dp, Gold.GoldDark.copy(alpha = 0.6f), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        for (item in barItems) {
            val isSelected = item.route == selected
            val container by animateColorAsState(
                targetValue = if (isSelected) Gold.Gold else Gold.Surface,
                animationSpec = tween(220),
                label = "barBg"
            )
            val content by animateColorAsState(
                targetValue = if (isSelected) Gold.Black else Gold.Gold,
                animationSpec = tween(220),
                label = "barFg"
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 2.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(container)
                    .clickable { onSelect(item.route) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GoldIcon(item.icon, content, Modifier.size(22.dp))
                Text(
                    item.label,
                    color = content,
                    fontSize = 10.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}
