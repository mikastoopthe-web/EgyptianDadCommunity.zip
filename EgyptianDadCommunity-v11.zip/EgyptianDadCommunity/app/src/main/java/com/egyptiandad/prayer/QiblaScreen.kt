package com.egyptiandad.prayer

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Button
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Qibla {
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LON = 39.8262

    /** Direction to the Kaaba in degrees clockwise from true north. */
    fun bearing(lat: Double, lon: Double): Double {
        val p1 = Math.toRadians(lat)
        val p2 = Math.toRadians(KAABA_LAT)
        val dl = Math.toRadians(KAABA_LON - lon)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }
}

private fun smoothAngle(old: Float, new: Float): Float {
    val diff = ((new - old + 540f) % 360f) - 180f
    return (old + diff * 0.2f + 360f) % 360f
}

/** Phone heading in degrees from magnetic north, or null until the first sensor reading. */
@Composable
private fun rememberMagneticHeading(): Float? {
    val ctx = LocalContext.current
    var heading by remember { mutableStateOf<Float?>(null) }
    DisposableEffect(Unit) {
        val manager = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val rotation = FloatArray(9)
        val remapped = FloatArray(9)
        val orientation = FloatArray(3)
        var smoothed = Float.NaN
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(rotation, event.values)
                SensorManager.getOrientation(rotation, orientation)
                // Held upright (like when taking a photo) the normal reading is wrong, so use the other axes.
                if (kotlin.math.abs(orientation[1]) > 0.9f) {
                    SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped)
                    SensorManager.getOrientation(remapped, orientation)
                }
                val azimuth = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
                smoothed = if (smoothed.isNaN()) azimuth else smoothAngle(smoothed, azimuth)
                heading = smoothed
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { manager.unregisterListener(listener) }
    }
    return heading
}

/** A small Kaaba drawn as a 3D cube: dark faces, a gold belt and a gold door. [w] is its total width. */
private fun DrawScope.drawKaaba(cx: Float, cy: Float, w: Float) {
    val d = w * 0.26f
    val fw = w - d
    val fh = w - d
    val x0 = cx - w / 2f
    val y0 = cy - w / 2f + d

    val front = Path()
    front.moveTo(x0, y0)
    front.lineTo(x0 + fw, y0)
    front.lineTo(x0 + fw, y0 + fh)
    front.lineTo(x0, y0 + fh)
    front.close()

    val side = Path()
    side.moveTo(x0 + fw, y0)
    side.lineTo(x0 + fw + d, y0 - d)
    side.lineTo(x0 + fw + d, y0 + fh - d)
    side.lineTo(x0 + fw, y0 + fh)
    side.close()

    val top = Path()
    top.moveTo(x0, y0)
    top.lineTo(x0 + d, y0 - d)
    top.lineTo(x0 + fw + d, y0 - d)
    top.lineTo(x0 + fw, y0)
    top.close()

    drawPath(front, Brush.verticalGradient(listOf(Color(0xFF2E2E2E), Color(0xFF111111)), startY = y0, endY = y0 + fh))
    drawPath(side, Color(0xFF080808))
    drawPath(top, Color(0xFF3C3C3C))

    // The gold belt around the upper part.
    val b1 = y0 + fh * 0.18f
    val b2 = y0 + fh * 0.36f
    drawRect(Gold.Gold, Offset(x0, b1), Size(fw, b2 - b1))
    val belt = Path()
    belt.moveTo(x0 + fw, b1)
    belt.lineTo(x0 + fw + d, b1 - d)
    belt.lineTo(x0 + fw + d, b2 - d)
    belt.lineTo(x0 + fw, b2)
    belt.close()
    drawPath(belt, Gold.GoldDark)

    // The door.
    drawRect(Gold.GoldLight, Offset(x0 + fw * 0.58f, y0 + fh * 0.52f), Size(fw * 0.20f, fh * 0.48f))

    val edge = androidx.compose.ui.graphics.drawscope.Stroke(width = w * 0.025f)
    val edgeColor = Gold.GoldDark.copy(alpha = 0.9f)
    drawPath(front, edgeColor, style = edge)
    drawPath(side, edgeColor, style = edge)
    drawPath(top, edgeColor, style = edge)
}

@Composable
fun QiblaScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val city = Cities.of(prefs)

    // Use the phone's real position when we can get it, and the chosen city otherwise.
    var live by remember { mutableStateOf<Location?>(null) }
    var locating by remember { mutableStateOf(false) }
    fun locate() {
        locating = true
        Locations.fresh(ctx) {
            if (it != null) live = it
            locating = false
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) locate()
    }
    LaunchedEffect(Unit) {
        if (Locations.hasPermission(ctx)) locate()
    }

    val lat = live?.latitude ?: city.lat
    val lon = live?.longitude ?: city.lon
    val bearing = remember(lat, lon) { Qibla.bearing(lat, lon).toFloat() }
    val declination = remember(lat, lon) {
        GeomagneticField(lat.toFloat(), lon.toFloat(), 0f, System.currentTimeMillis()).declination
    }

    val magnetic = rememberMagneticHeading()
    val heading: Float? = if (magnetic != null) (magnetic + declination + 360f) % 360f else null
    val angle: Float = if (heading != null) (bearing - heading + 360f) % 360f else bearing
    val aligned = heading != null && (angle < 4f || angle > 356f)

    val labelPaint = remember {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            if (live != null) "اتجاه القبلة من موقعك الحالي" else "اتجاه القبلة من " + city.arabic,
            color = Gold.Gold,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Box(modifier = Modifier.size(320.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(320.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val r = size.minDimension / 2f - 6.dp.toPx()

                if (aligned) {
                    drawCircle(Gold.Gold.copy(alpha = 0.22f), radius = r + 5.dp.toPx(), center = c)
                }
                drawCircle(
                    brush = Brush.radialGradient(listOf(Gold.SurfaceHigh, Gold.Black), center = c, radius = r),
                    radius = r,
                    center = c
                )
                drawCircle(Gold.GoldDark, radius = r, center = c, style = Stroke(width = 3.dp.toPx()))
                drawCircle(Gold.Line, radius = r * 0.52f, center = c, style = Stroke(width = 1.dp.toPx()))

                // The dial turns against the phone so that N always points to north.
                rotate(degrees = -(heading ?: 0f), pivot = c) {
                    for (i in 0 until 72) {
                        val big = i % 6 == 0
                        val len = if (big) 14.dp.toPx() else 7.dp.toPx()
                        val top = c.y - r + 8.dp.toPx()
                        rotate(degrees = i * 5f, pivot = c) {
                            drawLine(
                                color = if (i % 18 == 0) Gold.Gold else Gold.GoldDark,
                                start = Offset(c.x, top),
                                end = Offset(c.x, top + len),
                                strokeWidth = if (big) 2.dp.toPx() else 1.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    val names = listOf("N", "E", "S", "W")
                    for (k in 0 until 4) {
                        labelPaint.color = (if (k == 0) Gold.Gold else Gold.GoldLight).toArgb()
                        labelPaint.textSize = 16.sp.toPx()
                        rotate(degrees = k * 90f, pivot = c) {
                            drawContext.canvas.nativeCanvas.drawText(names[k], c.x, c.y - r + 44.dp.toPx(), labelPaint)
                        }
                    }
                }

                // Needle toward the Kaaba, and the Kaaba itself at its end.
                rotate(degrees = angle, pivot = c) {
                    drawLine(
                        color = if (aligned) Gold.GoldLight else Gold.Gold,
                        start = Offset(c.x, c.y - 12.dp.toPx()),
                        end = Offset(c.x, c.y - (r - 112.dp.toPx())),
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
                drawCircle(Gold.Gold, radius = 8.dp.toPx(), center = c)
                drawCircle(Gold.Black, radius = 3.dp.toPx(), center = c)

                val rad = Math.toRadians(angle.toDouble())
                val dist = r - 74.dp.toPx()
                val kaabaSize = 52.dp.toPx() * (if (aligned) 1.18f else 1f)
                drawKaaba(
                    c.x + dist * sin(rad).toFloat(),
                    c.y - dist * cos(rad).toFloat(),
                    kaabaSize
                )
            }
        }

        Text(
            text = when {
                magnetic == null -> "بجهّز البوصلة... لو مفيش حاجة بتتحرك يبقى الموبايل مفيهوش حساس اتجاه، وده الاتجاه بالدرجات."
                aligned -> "أنت في اتجاه القبلة"
                else -> "لفّ لحد ما الكعبة تبقى لفوق"
            },
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = if (aligned) Gold.Gold else Gold.Ink,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "القبلة ${arabicNumber(bearing.roundToInt())}° من الشمال الحقيقي",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        if (live == null) {
            Button(onClick = {
                if (Locations.hasPermission(ctx)) locate() else permissionLauncher.launch(Locations.PERMISSIONS)
            }) { Text(if (locating) "بحدد موقعك..." else "حدّد موقعي الحالي") }
        }

        Text(
            "ضع الموبايل أفقي وبعيد عن المعادن والمغناطيس. لو القراءة مش مظبوطة، حرّك الموبايل على شكل ٨ في الهوا كذا مرة.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
