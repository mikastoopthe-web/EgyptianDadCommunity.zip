package com.egyptiandad.prayer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant

data class Dhikr(val text: String, val times: Int, val source: String? = null)

object Adhkar {
    private const val AYAT_KURSI =
        "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ"

    private const val IKHLAS =
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ ﴿٤﴾"

    private const val FALAQ =
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِنْ شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾"

    private const val NAS =
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾"

    private const val ISTIGHFAR =
        "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ"

    private const val AFIYA_BODY =
        "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ"

    private const val BISMILLAH_LA_YADURR =
        "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"

    private const val RADEETU =
        "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيًّا"

    private const val SUBHAN_ALLAH =
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"

    private const val LA_ILAHA =
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"

    private const val AL_AFW =
        "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي، اللَّهُمَّ اسْتُرْ عَوْرَاتِي وَآمِنْ رَوْعَاتِي، اللَّهُمَّ احْفَظْنِي مِنْ بَيْنِ يَدَيَّ وَمِنْ خَلْفِي وَعَنْ يَمِينِي وَعَنْ شِمَالِي وَمِنْ فَوْقِي، وَأَعُوذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِي"

    val morning: List<Dhikr> = listOf(
        Dhikr(AYAT_KURSI, 1, "آية الكرسي، سورة البقرة ٢٥٥"),
        Dhikr(IKHLAS, 3, "سورة الإخلاص"),
        Dhikr(FALAQ, 3, "سورة الفلق"),
        Dhikr(NAS, 3, "سورة الناس"),
        Dhikr(
            "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
            1, "رواه مسلم"
        ),
        Dhikr(
            "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
            1, "رواه الترمذي"
        ),
        Dhikr(ISTIGHFAR, 1, "سيد الاستغفار، رواه البخاري"),
        Dhikr(AFIYA_BODY, 3, "رواه أبو داود"),
        Dhikr(AL_AFW, 1, "رواه أبو داود وابن ماجه"),
        Dhikr(BISMILLAH_LA_YADURR, 3, "رواه أبو داود والترمذي"),
        Dhikr(RADEETU, 3, "رواه أبو داود والترمذي"),
        Dhikr(SUBHAN_ALLAH, 100, "رواه مسلم"),
        Dhikr(LA_ILAHA, 10)
    )

    val evening: List<Dhikr> = listOf(
        Dhikr(AYAT_KURSI, 1, "آية الكرسي، سورة البقرة ٢٥٥"),
        Dhikr(IKHLAS, 3, "سورة الإخلاص"),
        Dhikr(FALAQ, 3, "سورة الفلق"),
        Dhikr(NAS, 3, "سورة الناس"),
        Dhikr(
            "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
            1, "رواه مسلم"
        ),
        Dhikr(
            "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
            1, "رواه الترمذي"
        ),
        Dhikr(ISTIGHFAR, 1, "سيد الاستغفار، رواه البخاري"),
        Dhikr("أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", 3, "رواه الترمذي"),
        Dhikr(AFIYA_BODY, 3, "رواه أبو داود"),
        Dhikr(AL_AFW, 1, "رواه أبو داود وابن ماجه"),
        Dhikr(BISMILLAH_LA_YADURR, 3, "رواه أبو داود والترمذي"),
        Dhikr(RADEETU, 3, "رواه أبو داود والترمذي"),
        Dhikr(SUBHAN_ALLAH, 100, "رواه مسلم"),
        Dhikr(LA_ILAHA, 10)
    )
}

@Composable
fun AdhkarScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val now = System.currentTimeMillis()
    val hour = Instant.ofEpochMilli(now).atZone(PrayerTimes.zone).hour

    var morning by remember { mutableStateOf(hour < 15) }
    var version by remember { mutableIntStateOf(0) }

    val date = PrayerTimes.today(now).toString()
    val period = if (morning) "morning" else "evening"
    val items = if (morning) Adhkar.morning else Adhkar.evening

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = morning,
                onClick = { morning = true },
                label = { Text("أذكار الصباح") }
            )
            FilterChip(
                selected = !morning,
                onClick = { morning = false },
                label = { Text("أذكار المساء") }
            )
        }

        Text(
            if (morning) "وقتها من بعد الفجر لحد ما الشمس تطلع، ويجوز قبل الظهر."
            else "وقتها من بعد العصر لحد المغرب، ويجوز لحد نص الليل.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        items.forEachIndexed { index, dhikr ->
            val count = remember(version, period, index) { prefs.dhikrCount(date, period, index) }
            DhikrCard(
                dhikr = dhikr,
                count = count,
                onTap = {
                    prefs.setDhikrCount(date, period, index, count + 1)
                    version++
                },
                onReset = {
                    prefs.setDhikrCount(date, period, index, 0)
                    version++
                }
            )
        }
    }
}

@Composable
private fun DhikrCard(dhikr: Dhikr, count: Int, onTap: () -> Unit, onReset: () -> Unit) {
    val done = count >= dhikr.times
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(dhikr.text, fontSize = 20.sp, lineHeight = 34.sp)
            dhikr.source?.let {
                Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (done) {
                    FilledTonalButton(onClick = onReset) { Text("تمّ ✓") }
                } else {
                    Button(onClick = onTap) {
                        Text(
                            if (dhikr.times > 1) arabicNumber(count) + " / " + arabicNumber(dhikr.times) + "   اضغط للعدّ"
                            else "اضغط عند الانتهاء",
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                if (count > 0) {
                    TextButton(onClick = onReset) { Text("تصفير") }
                }
            }
        }
    }
}
