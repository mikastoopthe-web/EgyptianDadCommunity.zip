package com.egyptiandad.prayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

enum class IconKind { HOME, QIBLA, RADIO, ADHKAR, MORE, SALAWAT, STREAK, SETTINGS, PLAY, STOP, FACEBOOK }

/** Simple line icons drawn in code, so the app needs no image files. */
@Composable
fun GoldIcon(kind: IconKind, tint: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier = modifier) {
        val s = size.minDimension
        val stroke = Stroke(width = s * 0.08f, cap = StrokeCap.Round)
        when (kind) {
            IconKind.HOME -> {
                val dome = Path()
                dome.moveTo(s * 0.18f, s * 0.82f)
                dome.lineTo(s * 0.18f, s * 0.50f)
                dome.quadraticTo(s * 0.50f, s * 0.00f, s * 0.82f, s * 0.50f)
                dome.lineTo(s * 0.82f, s * 0.82f)
                dome.close()
                drawPath(dome, tint, style = stroke)
                drawLine(tint, Offset(s * 0.50f, s * 0.08f), Offset(s * 0.50f, s * 0.02f), s * 0.08f, StrokeCap.Round)
                drawRect(tint, Offset(s * 0.42f, s * 0.60f), Size(s * 0.16f, s * 0.22f))
            }
            IconKind.QIBLA -> {
                drawCircle(tint, radius = s * 0.42f, center = center, style = stroke)
                val needle = Path()
                needle.moveTo(center.x, s * 0.20f)
                needle.lineTo(center.x + s * 0.12f, center.y)
                needle.lineTo(center.x, s * 0.80f)
                needle.lineTo(center.x - s * 0.12f, center.y)
                needle.close()
                drawPath(needle, tint)
            }
            IconKind.RADIO -> {
                drawRoundRect(tint, Offset(s * 0.12f, s * 0.36f), Size(s * 0.76f, s * 0.48f), CornerRadius(s * 0.1f), style = stroke)
                drawLine(tint, Offset(s * 0.30f, s * 0.36f), Offset(s * 0.72f, s * 0.12f), s * 0.07f, StrokeCap.Round)
                drawCircle(tint, radius = s * 0.11f, center = Offset(s * 0.34f, s * 0.60f))
                drawLine(tint, Offset(s * 0.54f, s * 0.54f), Offset(s * 0.76f, s * 0.54f), s * 0.06f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.54f, s * 0.68f), Offset(s * 0.76f, s * 0.68f), s * 0.06f, StrokeCap.Round)
            }
            IconKind.ADHKAR -> {
                val left = Path()
                left.moveTo(s * 0.50f, s * 0.26f)
                left.lineTo(s * 0.14f, s * 0.20f)
                left.lineTo(s * 0.14f, s * 0.78f)
                left.lineTo(s * 0.50f, s * 0.84f)
                left.close()
                val right = Path()
                right.moveTo(s * 0.50f, s * 0.26f)
                right.lineTo(s * 0.86f, s * 0.20f)
                right.lineTo(s * 0.86f, s * 0.78f)
                right.lineTo(s * 0.50f, s * 0.84f)
                right.close()
                drawPath(left, tint, style = stroke)
                drawPath(right, tint, style = stroke)
            }
            IconKind.MORE -> {
                for (i in 0 until 3) {
                    drawCircle(tint, radius = s * 0.09f, center = Offset(s * (0.22f + 0.28f * i), s * 0.5f))
                }
            }
            IconKind.SALAWAT -> {
                val outer = Path()
                outer.addOval(Rect(center = center, radius = s * 0.40f))
                val cut = Path()
                cut.addOval(Rect(center = Offset(center.x + s * 0.17f, center.y - s * 0.07f), radius = s * 0.34f))
                val moon = Path.combine(PathOperation.Difference, outer, cut)
                drawPath(moon, tint)
                drawCircle(tint, radius = s * 0.05f, center = Offset(s * 0.72f, s * 0.30f))
            }
            IconKind.STREAK -> {
                for (k in 0 until 2) {
                    val star = Path()
                    for (n in 0 until 4) {
                        val a = Math.toRadians(45.0 * k + 90.0 * n + 45.0)
                        val x = center.x + s * 0.42f * cos(a).toFloat()
                        val y = center.y + s * 0.42f * sin(a).toFloat()
                        if (n == 0) star.moveTo(x, y) else star.lineTo(x, y)
                    }
                    star.close()
                    drawPath(star, tint, style = stroke)
                }
            }
            IconKind.SETTINGS -> {
                drawCircle(tint, radius = s * 0.16f, center = center, style = stroke)
                for (k in 0 until 8) {
                    val a = Math.toRadians(45.0 * k)
                    val c = cos(a).toFloat()
                    val d = sin(a).toFloat()
                    drawLine(
                        tint,
                        Offset(center.x + s * 0.30f * c, center.y + s * 0.30f * d),
                        Offset(center.x + s * 0.42f * c, center.y + s * 0.42f * d),
                        s * 0.09f,
                        StrokeCap.Round
                    )
                }
                drawCircle(tint, radius = s * 0.30f, center = center, style = stroke)
            }
            IconKind.PLAY -> {
                val p = Path()
                p.moveTo(s * 0.28f, s * 0.16f)
                p.lineTo(s * 0.84f, s * 0.50f)
                p.lineTo(s * 0.28f, s * 0.84f)
                p.close()
                drawPath(p, tint)
            }
            IconKind.STOP -> {
                drawRoundRect(tint, Offset(s * 0.20f, s * 0.20f), Size(s * 0.60f, s * 0.60f), CornerRadius(s * 0.08f))
            }
            IconKind.FACEBOOK -> {
                drawCircle(tint, radius = s * 0.44f, center = center, style = stroke)
                drawLine(tint, Offset(s * 0.56f, s * 0.84f), Offset(s * 0.56f, s * 0.36f), s * 0.09f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.42f, s * 0.50f), Offset(s * 0.70f, s * 0.50f), s * 0.08f, StrokeCap.Round)
                val hook = Path()
                hook.moveTo(s * 0.56f, s * 0.38f)
                hook.quadraticTo(s * 0.56f, s * 0.22f, s * 0.72f, s * 0.22f)
                drawPath(hook, tint, style = stroke)
            }
        }
    }
}

/** A gold circle with an icon in it and a small label, like a feature button. */
@Composable
fun FeatureButton(kind: IconKind, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Gold.SurfaceHigh)
                .border(1.dp, Gold.GoldDark, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            GoldIcon(kind, Gold.Gold, Modifier.size(28.dp))
        }
        Text(label, color = Gold.Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** A row of feature buttons. */
@Composable
fun FeatureRow(items: List<Triple<IconKind, String, () -> Unit>>) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        for ((kind, label, action) in items) {
            FeatureButton(kind, label, action, Modifier.weight(1f))
        }
    }
}
