package com.egyptiandad.prayer

import android.content.Context
import java.time.LocalDate

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("prayer", Context.MODE_PRIVATE)

    var cityId: String
        get() = sp.getString("city", "cairo") ?: "cairo"
        set(v) { sp.edit().putString("city", v).apply() }

    var repeatMinutes: Int
        get() = sp.getInt("repeat", 10)
        set(v) { sp.edit().putInt("repeat", v).apply() }

    var remindersOn: Boolean
        get() = sp.getBoolean("on", true)
        set(v) { sp.edit().putBoolean("on", v).apply() }

    fun isPrayed(key: String): Boolean =
        sp.getStringSet("prayed", emptySet())?.contains(key) == true

    fun setPrayed(key: String, value: Boolean) {
        val set = HashSet(sp.getStringSet("prayed", emptySet()) ?: emptySet())
        if (value) set.add(key) else set.remove(key)
        val cutoff = LocalDate.now().minusDays(14).toString()
        set.removeAll { it.take(10) < cutoff } // keys look like 2026-11-14:ASR
        sp.edit().putStringSet("prayed", set).commit()
    }
}
