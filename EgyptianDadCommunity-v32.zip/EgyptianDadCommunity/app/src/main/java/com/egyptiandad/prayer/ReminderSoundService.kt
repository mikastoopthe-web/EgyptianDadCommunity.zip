package com.egyptiandad.prayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Plays the reminder sound all the way through when the user taps the repeat reminder,
 * without opening the app. It stops itself when the sound ends.
 */
class ReminderSoundService : Service() {
    companion object {
        private const val CHANNEL = "reminder_sound"
        private const val NOTIFICATION_ID = 4107
        private const val SOUND_NAME = "reminder_sound"

        fun soundResId(context: Context): Int =
            context.resources.getIdentifier(SOUND_NAME, "raw", context.packageName)

        /** What the notification does when it is tapped: start this service, not the app. */
        fun pendingIntent(context: Context): PendingIntent {
            val intent = Intent(context, ReminderSoundService::class.java)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            return if (Build.VERSION.SDK_INT >= 26) {
                PendingIntent.getForegroundService(context, 4107, intent, flags)
            } else {
                PendingIntent.getService(context, 4107, intent, flags)
            }
        }
    }

    private var player: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // A foreground service must show a notification right away.
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        player?.release()
        player = null
        val resId = soundResId(this)
        if (resId == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            resources.openRawResourceFd(resId).use { p.setDataSource(it.fileDescriptor, it.startOffset, it.length) }
            p.setOnCompletionListener { stopSelf() }
            p.setOnErrorListener { _, _, _ -> stopSelf(); true }
            p.prepare()
            p.start()
            player = p
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "صوت التذكير", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setContentTitle("جاري تشغيل الصوت")
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    override fun onDestroy() {
        runCatching { player?.release() }
        player = null
        super.onDestroy()
    }
}
