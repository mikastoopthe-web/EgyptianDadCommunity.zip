package com.egyptiandad.prayer

import android.content.Context
import android.media.MediaPlayer

/** The sound played once each time the user opens the "الصلاة على النبي ﷺ" page (res/raw/salawat_page.mp3). */
object SalawatPageSound {
    private var player: MediaPlayer? = null

    fun play(context: Context) {
        stop()
        try {
            val p = MediaPlayer.create(context.applicationContext, R.raw.salawat_page) ?: return
            p.setOnCompletionListener {
                it.release()
                if (player === it) player = null
            }
            player = p
            p.start()
        } catch (e: Exception) {
            player = null
        }
    }

    /** Stops the sound when the user leaves the page. */
    fun stop() {
        val p = player ?: return
        player = null
        runCatching { p.stop() }
        runCatching { p.release() }
    }
}
