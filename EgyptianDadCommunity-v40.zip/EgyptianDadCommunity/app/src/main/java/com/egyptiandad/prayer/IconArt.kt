package com.egyptiandad.prayer

/** Icon artwork on a 100 x 100 grid. Mode F = filled, S = outline, B = both. Matches the gold icon set in the design. */
class ArtLayer(val d: String, val mode: Char, val width: Float)

val ICON_ART: Map<IconKind, List<ArtLayer>> = mapOf(
    IconKind.HOME to listOf(
        ArtLayer("M50 10 C46 10 43 12 40 15 L9 46 C6 49 8 54 12 54 H18 V84 C18 87 20 89 23 89 H77 C80 89 82 87 82 84 V54 H88 C92 54 94 49 91 46 L60 15 C57 12 54 10 50 10 Z M41 89 V68 C41 63 45 60 50 60 C55 60 59 63 59 68 V89 Z", 'B', 3f)
    ),
    IconKind.QIBLA to listOf(
        ArtLayer("M50 8 a42 42 0 1 0 0.01 0 Z", 'S', 5f),
        ArtLayer("M68 32 L56 56 L44 44 Z", 'F', 0f),
        ArtLayer("M68 32 L56 56 L32 68 L44 44 Z", 'S', 4.5f)
    ),
    IconKind.RADIO to listOf(
        ArtLayer("M14 38 H86 a6 6 0 0 1 6 6 V80 a6 6 0 0 1 -6 6 H14 a6 6 0 0 1 -6 -6 V44 a6 6 0 0 1 6 -6 Z", 'S', 5f),
        ArtLayer("M30 38 L72 14", 'S', 5f),
        ArtLayer("M36 62 m-11 0 a11 11 0 1 0 22 0 a11 11 0 1 0 -22 0 Z", 'S', 4.5f),
        ArtLayer("M36 62 m-3.5 0 a3.5 3.5 0 1 0 7 0 a3.5 3.5 0 1 0 -7 0 Z", 'F', 0f),
        ArtLayer("M58 52 H80 M58 62 H80 M58 72 H80", 'S', 4.5f)
    ),
    IconKind.ADHKAR to listOf(
        ArtLayer("M50 30 C38 21 22 21 9 25 V77 C22 73 38 73 50 82 C62 73 78 73 91 77 V25 C78 21 62 21 50 30 Z", 'S', 5f),
        ArtLayer("M50 30 V82", 'S', 4.5f)
    ),
    IconKind.SALAWAT to listOf(
        ArtLayer("M56 10 A40 40 0 1 0 90 64 A33 33 0 1 1 56 10 Z", 'F', 0f),
        ArtLayer("M80 23 L81.8 27.6 L86.7 27.8 L82.9 30.9 L84.1 35.7 L80 33 L75.9 35.7 L77.1 30.9 L73.3 27.8 L78.2 27.6 Z", 'F', 0f)
    ),
    IconKind.TROPHY to listOf(
        ArtLayer("M28 12 H72 V36 C72 54 62 62 50 62 C38 62 28 54 28 36 Z", 'B', 3f),
        ArtLayer("M28 22 H15 C14 40 22 48 33 50 M72 22 H85 C86 40 78 48 67 50", 'S', 5f),
        ArtLayer("M44 62 H56 V76 H44 Z M30 78 H70 V90 H30 Z", 'B', 3f)
    ),
    IconKind.HOURGLASS to listOf(
        ArtLayer("M24 12 H76 M24 88 H76", 'S', 6f),
        ArtLayer("M30 12 V20 C30 34 44 42 50 50 C56 42 70 34 70 20 V12 M30 88 V80 C30 66 44 58 50 50 C56 58 70 66 70 80 V88", 'S', 4.5f),
        ArtLayer("M50 56 C46 64 36 70 36 82 V84 H64 V82 C64 70 54 64 50 56 Z", 'F', 0f)
    ),
    IconKind.CALENDAR to listOf(
        ArtLayer("M64 53 V30 a8 8 0 0 0 -8 -8 H16 a8 8 0 0 0 -8 8 V66 a8 8 0 0 0 8 8 H46", 'S', 5f),
        ArtLayer("M8 40 H64 M24 12 V28 M48 12 V28", 'S', 5f),
        ArtLayer("M70 56 m-19 0 a19 19 0 1 0 38 0 a19 19 0 1 0 -38 0 Z", 'S', 4.5f),
        ArtLayer("M70 44 V57 L79 62", 'S', 4.5f),
        ArtLayer("M33 55 m-6.5 0 a6.5 6.5 0 1 0 13 0 a6.5 6.5 0 1 0 -13 0 Z", 'S', 4f),
        ArtLayer("M39.5 55 V59 Q39.5 66 31 67", 'S', 4f)
    ),
    IconKind.PIN to listOf(
        ArtLayer("M40 8 C25 8 14 20 14 34 C14 54 40 80 40 80 C40 80 66 54 66 34 C66 20 55 8 40 8 Z M40 25 a9.5 9.5 0 1 0 0.01 0 Z", 'F', 0f),
        ArtLayer("M90 58 L62 70 L74 76 L80 90 Z", 'F', 2f)
    ),
    IconKind.PROFILE to listOf(
        ArtLayer("M54.9 87.4 A40 40 0 1 1 88 48", 'S', 4.5f),
        ArtLayer("M48 22 a12 12 0 1 0 0.01 0 Z", 'F', 0f),
        ArtLayer("M24 70 C24 54 36 49 48 49 C60 49 72 54 72 70 C66 76 58 78 48 78 C38 78 30 76 24 70 Z", 'F', 0f),
        ArtLayer("M87.4 72.2 L91.6 72.5 L91.6 79.5 L87.4 79.8 L86.7 81.4 L89.5 84.6 L84.6 89.5 L81.4 86.7 L79.8 87.4 L79.5 91.6 L72.5 91.6 L72.2 87.4 L70.6 86.7 L67.4 89.5 L62.5 84.6 L65.3 81.4 L64.6 79.8 L60.4 79.5 L60.4 72.5 L64.6 72.2 L65.3 70.6 L62.5 67.4 L67.4 62.5 L70.6 65.3 L72.2 64.6 L72.5 60.4 L79.5 60.4 L79.8 64.6 L81.4 65.3 L84.6 62.5 L89.5 67.4 L86.7 70.6 Z M70 76 a6 6 0 1 0 12 0 a6 6 0 1 0 -12 0 Z", 'F', 0f)
    ),
    IconKind.MOSQUE to listOf(
        ArtLayer("M16 90 V60 H84 V90 Z M44 90 V76 C44 70 47 67 50 67 C53 67 56 70 56 76 V90 Z", 'F', 0f),
        ArtLayer("M26 60 C26 40 38 30 50 30 C62 30 74 40 74 60 Z", 'F', 0f),
        ArtLayer("M50 30 V16", 'S', 4f),
        ArtLayer("M50 8 m-4 0 a4 4 0 1 0 8 0 a4 4 0 1 0 -8 0 Z", 'F', 0f),
        ArtLayer("M4 90 V40 L9 26 L14 40 V90 Z M86 90 V40 L91 26 L96 40 V90 Z", 'F', 0f),
        ArtLayer("M9 26 V14 M91 26 V14", 'S', 3f)
    ),
    IconKind.MINARET to listOf(
        ArtLayer("M42 90 L44 46 H56 L58 90 Z", 'F', 0f),
        ArtLayer("M36 46 H64 V52 H36 Z", 'F', 0f),
        ArtLayer("M42 46 V36 C42 28 46 24 50 18 C54 24 58 28 58 36 V46 Z", 'F', 0f),
        ArtLayer("M50 18 V6", 'S', 3.5f),
        ArtLayer("M34 90 H66", 'S', 5f)
    ),
    IconKind.TROPHY_LAUREL to listOf(
        ArtLayer("M32 16 H68 V38 C68 54 60 60 50 60 C40 60 32 54 32 38 Z", 'B', 3f),
        ArtLayer("M32 24 H22 C21 38 27 46 36 48 M68 24 H78 C79 38 73 46 64 48", 'S', 4f),
        ArtLayer("M45 60 H55 V74 H45 Z M34 76 H66 V88 H34 Z", 'B', 3f),
        ArtLayer("M34.4 86.8 Q26.5 88.2 22.6 81.3 Q30.4 79.9 34.4 86.8 Z M25.4 81.4 Q17.5 80.5 15.7 72.8 Q23.6 73.6 25.4 81.4 Z M18.5 73.8 Q11.2 70.7 11.7 62.8 Q19 65.9 18.5 73.8 Z M14.3 64.8 Q8.1 59.7 10.9 52.2 Q17 57.3 14.3 64.8 Z M13 55 Q8.6 48.4 13.4 42 Q17.8 48.6 13 55 Z M14.9 45.3 Q12.6 37.7 19 33 Q21.3 40.6 14.9 45.3 Z M19.7 36.5 Q19.7 28.5 27.1 25.8 Q27.2 33.8 19.7 36.5 Z", 'F', 0f),
        ArtLayer("M65.6 86.8 Q69.6 79.9 77.4 81.3 Q73.5 88.2 65.6 86.8 Z M74.6 81.4 Q76.4 73.6 84.3 72.8 Q82.5 80.5 74.6 81.4 Z M81.5 73.8 Q81 65.9 88.3 62.8 Q88.8 70.7 81.5 73.8 Z M85.7 64.8 Q83 57.3 89.1 52.2 Q91.9 59.7 85.7 64.8 Z M87 55 Q82.2 48.6 86.6 42 Q91.4 48.4 87 55 Z M85.1 45.3 Q78.7 40.6 81 33 Q87.4 37.7 85.1 45.3 Z M80.3 36.5 Q72.8 33.8 72.9 25.8 Q80.3 28.5 80.3 36.5 Z", 'F', 0f)
    ),
    IconKind.STAR to listOf(
        ArtLayer("M50.0 8.0 L60.6 37.4 L91.8 38.4 L67.1 57.6 L75.9 87.6 L50.0 70.0 L24.1 87.6 L32.9 57.6 L8.2 38.4 L39.4 37.4 Z", 'B', 4f)
    ),
    IconKind.SHARE to listOf(
        ArtLayer("M78 14 a10 10 0 1 0 0.01 0 Z M22 40 a10 10 0 1 0 0.01 0 Z M78 66 a10 10 0 1 0 0.01 0 Z", 'F', 0f),
        ArtLayer("M28 45 L72 21 M28 55 L72 79", 'S', 5f)
    )
)
