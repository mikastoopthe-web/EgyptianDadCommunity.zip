package com.egyptiandad.prayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** The Black & Gold palette. */
object Gold {
    val Black = Color(0xFF0A0908)
    val Surface = Color(0xFF14110C)
    val SurfaceHigh = Color(0xFF211C12)
    val Gold = Color(0xFFD4AF37)
    val GoldLight = Color(0xFFF0D78C)
    val GoldDark = Color(0xFF8C6D1F)
    val Ink = Color(0xFFF3EAD3)
    val Muted = Color(0xFFA89E86)
    val Line = Color(0xFF3A3220)
}

/** Text size chosen by the user in Settings. 1.0 is normal. */
object UiState {
    var textScale by mutableFloatStateOf(1f)
}

private val GoldColors = darkColorScheme(
    primary = Gold.Gold,
    onPrimary = Gold.Black,
    primaryContainer = Gold.GoldDark,
    onPrimaryContainer = Gold.GoldLight,
    secondary = Gold.GoldLight,
    onSecondary = Gold.Black,
    secondaryContainer = Color(0xFF2E2612),
    onSecondaryContainer = Gold.GoldLight,
    tertiary = Gold.GoldLight,
    onTertiary = Gold.Black,
    background = Gold.Black,
    onBackground = Gold.Ink,
    surface = Gold.Surface,
    onSurface = Gold.Ink,
    surfaceVariant = Gold.SurfaceHigh,
    onSurfaceVariant = Gold.Muted,
    surfaceContainer = Gold.Surface,
    surfaceContainerHigh = Gold.SurfaceHigh,
    surfaceContainerHighest = Gold.SurfaceHigh,
    outline = Gold.GoldDark,
    outlineVariant = Gold.Line
)

private val GoldShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val base = LocalDensity.current
    val density = Density(base.density, base.fontScale * UiState.textScale)
    CompositionLocalProvider(
        LocalDensity provides density,
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = GoldColors, shapes = GoldShapes) {
            Surface(color = MaterialTheme.colorScheme.background, content = content)
        }
    }
}

private fun DrawScope.eightPointStar(center: Offset, r: Float, color: Color, stroke: Stroke) {
    for (k in 0 until 2) {
        val path = Path()
        for (n in 0 until 4) {
            val a = Math.toRadians(45.0 * k + 90.0 * n + 45.0)
            val x = center.x + r * cos(a).toFloat()
            val y = center.y + r * sin(a).toFloat()
            if (n == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color, style = stroke)
    }
}

/** A faint tiling of eight-pointed stars behind every screen. */
@Composable
fun GeometricBackground(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val cell = 64.dp.toPx()
        val color = Gold.Gold.copy(alpha = 0.07f)
        val stroke = Stroke(width = 1.dp.toPx())
        val cols = (size.width / cell).toInt() + 2
        val rows = (size.height / cell).toInt() + 2
        for (i in 0 until cols) {
            for (j in 0 until rows) {
                eightPointStar(Offset(i * cell + cell / 2f, j * cell + cell / 2f), cell * 0.36f, color, stroke)
                drawCircle(
                    color = color,
                    radius = cell * 0.10f,
                    center = Offset(i * cell, j * cell),
                    style = stroke
                )
            }
        }
    }
}

/** A mosque skyline drawn in code, filled with a gold gradient. */
@Composable
fun MosqueSilhouette(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxWidth().height(110.dp)) {
        val w = size.width
        val h = size.height
        val brush = Brush.verticalGradient(listOf(Gold.GoldLight, Gold.Gold, Gold.GoldDark))

        fun dome(cx: Float, rx: Float, baseY: Float, ry: Float) {
            val p = Path()
            p.moveTo(cx - rx, baseY)
            p.arcTo(Rect(cx - rx, baseY - ry, cx + rx, baseY + ry), 180f, 180f, false)
            p.close()
            drawPath(p, brush)
        }

        fun minaret(cx: Float) {
            val half = w * 0.022f
            drawRect(brush, topLeft = Offset(cx - half, h * 0.30f), size = Size(half * 2f, h * 0.70f))
            drawRect(brush, topLeft = Offset(cx - half * 1.6f, h * 0.42f), size = Size(half * 3.2f, h * 0.05f))
            val tip = Path()
            tip.moveTo(cx - half * 1.3f, h * 0.30f)
            tip.lineTo(cx, h * 0.08f)
            tip.lineTo(cx + half * 1.3f, h * 0.30f)
            tip.close()
            drawPath(tip, brush)
        }

        drawRect(brush, topLeft = Offset(w * 0.20f, h * 0.62f), size = Size(w * 0.60f, h * 0.38f))
        dome(w * 0.50f, w * 0.16f, h * 0.62f, h * 0.42f)
        dome(w * 0.28f, w * 0.07f, h * 0.62f, h * 0.22f)
        dome(w * 0.72f, w * 0.07f, h * 0.62f, h * 0.22f)
        drawRect(
            brush,
            topLeft = Offset(w * 0.50f - 1.5.dp.toPx(), h * 0.04f),
            size = Size(3.dp.toPx(), h * 0.17f)
        )
        drawCircle(brush, radius = 4.dp.toPx(), center = Offset(w * 0.50f, h * 0.04f))
        minaret(w * 0.08f)
        minaret(w * 0.92f)

        val door = Path()
        door.moveTo(w * 0.465f, h)
        door.lineTo(w * 0.465f, h * 0.82f)
        door.arcTo(Rect(w * 0.465f, h * 0.74f, w * 0.535f, h * 0.90f), 180f, 180f, false)
        door.lineTo(w * 0.535f, h)
        door.close()
        drawPath(door, Gold.Black)
    }
}
