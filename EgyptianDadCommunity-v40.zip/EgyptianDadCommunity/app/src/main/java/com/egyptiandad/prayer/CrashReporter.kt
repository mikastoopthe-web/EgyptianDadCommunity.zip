package com.egyptiandad.prayer

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Saves the last crash to a file and shows it on screen at the next launch, so it can be photographed and reported. */
object CrashReporter {
    private const val FILE = "crash.txt"
    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                save(app, error)
            } catch (ignored: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun save(context: Context, error: Throwable) {
        val header = "Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.SDK_INT}\n\n"
        val text = header + Log.getStackTraceString(error).take(5000)
        File(context.applicationContext.filesDir, FILE).writeText(text)
    }

    fun read(context: Context): String? {
        val file = File(context.applicationContext.filesDir, FILE)
        return if (file.exists()) file.readText() else null
    }

    fun clear(context: Context) {
        File(context.applicationContext.filesDir, FILE).delete()
    }

    fun show(activity: Activity, report: String) {
        val pad = (16 * activity.resources.displayMetrics.density).toInt()

        val title = TextView(activity)
        title.text = "حصل خطأ في التطبيق. صوّر الشاشة دي وابعتها."
        title.textSize = 16f
        title.setTextColor(Color.WHITE)

        val retry = Button(activity)
        retry.text = "مسح وإعادة المحاولة"
        retry.setOnClickListener {
            clear(activity)
            activity.recreate()
        }

        val body = TextView(activity)
        body.text = report
        body.textSize = 11f
        body.setTextColor(Color.LTGRAY)
        body.setTextIsSelectable(true)

        val column = LinearLayout(activity)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(pad, pad, pad, pad)
        column.addView(title)
        column.addView(retry)
        column.addView(body)

        val scroll = ScrollView(activity)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.fitsSystemWindows = true
        scroll.addView(column)
        activity.setContentView(scroll)
    }
}
