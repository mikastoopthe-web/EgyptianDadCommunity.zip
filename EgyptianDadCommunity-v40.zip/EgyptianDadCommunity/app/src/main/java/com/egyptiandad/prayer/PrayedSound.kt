package com.egyptiandad.prayer

import android.content.Context
import android.media.MediaPlayer

/** The sound played all the way through when the user taps "صلّيت" inside the app (res/raw/prayed_sound.mp3). */
object PrayedSound {
    private var player: MediaPlayer? = null

    fun play(context: Context) {
        try {
            // Let the current sound finish instead of cutting it off with a new tap.
            if (player?.isPlaying == true) return
            player?.release()
            val p = MediaPlayer.create(context.applicationContext, R.raw.prayed_sound) ?: return
            p.setOnCompletionListener {
                it.release()
                if (player === it) player = null
            }
            player = p
            p.start()
        } catch (e: Exception) {
            player = null
        }
    }
}
