package com.egyptiandad.prayer

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

enum class Prayer(val arabic: String) {
    FAJR("الفجر"),
    DHUHR("الظهر"),
    ASR("العصر"),
    MAGHRIB("المغرب"),
    ISHA("العشاء")
}

data class City(val id: String, val arabic: String, val lat: Double, val lon: Double)

object Cities {
    /**
     * The 27 governorates of Egypt.
     * The coordinates are the ones that make the calculation below reproduce the official timetable of the
     * Egyptian Survey Authority (esa.gov.eg) for the capital of each governorate. Giza has no row in that
     * table, so it uses Cairo's. Qalyubia and Monufia are not listed either, so they use their capitals.
     */
    val all = listOf(
        City("cairo", "القاهرة", 30.107, 31.266),
        City("giza", "الجيزة", 30.107, 31.266),
        City("alex", "الإسكندرية", 31.215, 30.017),
        City("qalyubia", "القليوبية (بنها)", 30.466, 31.185),
        City("sharqia", "الشرقية (الزقازيق)", 30.556, 31.551),
        City("dakahlia", "الدقهلية (المنصورة)", 30.937, 31.432),
        City("gharbia", "الغربية (طنطا)", 30.707, 31.007),
        City("monufia", "المنوفية (شبين الكوم)", 30.597, 30.988),
        City("beheira", "البحيرة (دمنهور)", 31.050, 30.479),
        City("kafrelsheikh", "كفر الشيخ", 31.057, 30.978),
        City("damietta", "دمياط", 31.411, 31.799),
        City("portsaid", "بورسعيد", 31.304, 32.302),
        City("ismailia", "الإسماعيلية", 30.556, 32.301),
        City("suez", "السويس", 29.997, 32.546),
        City("northsinai", "شمال سيناء (العريش)", 31.200, 33.768),
        City("southsinai", "جنوب سيناء (الطور)", 28.243, 33.685),
        City("beniswef", "بني سويف", 29.098, 31.122),
        City("fayoum", "الفيوم", 29.253, 30.893),
        City("minya", "المنيا", 28.003, 30.775),
        City("asyut", "أسيوط", 27.117, 31.177),
        City("sohag", "سوهاج", 26.482, 31.673),
        City("qena", "قنا", 26.179, 32.748),
        City("luxor", "الأقصر", 25.634, 32.683),
        City("aswan", "أسوان", 24.076, 32.941),
        City("redsea", "البحر الأحمر (الغردقة)", 27.151, 33.931),
        City("newvalley", "الوادي الجديد (الخارجة)", 25.459, 30.304),
        City("matrouh", "مطروح (مرسى مطروح)", 31.407, 27.269)
    )

    /** "mansoura" is the old id of Dakahlia, kept so saved choices still work. */
    fun byId(id: String): City {
        val fixed = if (id == "mansoura") "dakahlia" else id
        return all.firstOrNull { it.id == fixed } ?: all[0]
    }

    const val GPS_ID = "gps"

    /** The chosen city, or the saved phone location when the user picked "my location". */
    fun of(prefs: Prefs): City {
        if (prefs.cityId == GPS_ID && prefs.hasLocation) {
            return City(GPS_ID, "موقعي الحالي", prefs.lat.toDouble(), prefs.lon.toDouble())
        }
        return byId(prefs.cityId)
    }
}

/** All times are epoch milliseconds. */
data class DayTimes(
    val date: LocalDate,
    val fajr: Long,
    val sunrise: Long,
    val dhuhr: Long,
    val asr: Long,
    val maghrib: Long,
    val isha: Long
) {
    fun of(p: Prayer): Long = when (p) {
        Prayer.FAJR -> fajr
        Prayer.DHUHR -> dhuhr
        Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib
        Prayer.ISHA -> isha
    }
}

/** One prayer window: it starts at [start] and the prayer can be performed until [end]. */
data class PrayerEvent(val prayer: Prayer, val date: LocalDate, val start: Long, val end: Long) {
    val key: String get() = "$date:${prayer.name}"
}

object PrayerTimes {
    val zone: ZoneId = ZoneId.of("Africa/Cairo")

    private const val FAJR_ANGLE = 19.5   // Egyptian Survey Authority
    private const val ISHA_ANGLE = 17.5
    private const val SUNRISE_ANGLE = 0.833

    private fun Double.rad(): Double = Math.toRadians(this)

    fun today(nowMs: Long): LocalDate = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()

    fun compute(date: LocalDate, city: City): DayTimes {
        val base = date.toEpochDay() * 86_400_000L // UTC midnight of the civil date
        val jd = (base + 12 * 3_600_000.0) / 86_400_000.0 + 2440587.5
        val d = jd - 2451545.0

        val g = (357.529 + 0.98560028 * d) % 360.0
        val q = (280.459 + 0.98564736 * d) % 360.0
        val l = (q + 1.915 * sin(g.rad()) + 0.020 * sin(2 * g.rad())) % 360.0
        val e = 23.439 - 0.00000036 * d

        var ra = Math.toDegrees(atan2(cos(e.rad()) * sin(l.rad()), cos(l.rad()))) / 15.0
        ra = ((ra % 24.0) + 24.0) % 24.0
        val dec = Math.toDegrees(asin(sin(e.rad()) * sin(l.rad())))

        var eq = q / 15.0 - ra
        eq = (((eq + 12.0) % 24.0) + 24.0) % 24.0 - 12.0

        val noon = 12.0 - eq - city.lon / 15.0 // solar noon, hours UTC

        fun hourAngle(altitudeDeg: Double): Double {
            val x = (sin(altitudeDeg.rad()) - sin(dec.rad()) * sin(city.lat.rad())) /
                (cos(dec.rad()) * cos(city.lat.rad()))
            return Math.toDegrees(acos(x.coerceIn(-1.0, 1.0))) / 15.0
        }

        val asrAltitude = Math.toDegrees(atan(1.0 / (1.0 + tan(abs(city.lat - dec).rad()))))
        // The official table lists whole minutes, rounded to the nearest one. Local time is a whole number
        // of hours from UTC, so rounding the epoch value gives the same minute as rounding local time.
        fun at(hours: Double): Long = ((base + (hours * 3_600_000.0).toLong() + 30_000L) / 60_000L) * 60_000L

        return DayTimes(
            date = date,
            fajr = at(noon - hourAngle(-FAJR_ANGLE)),
            sunrise = at(noon - hourAngle(-SUNRISE_ANGLE)),
            dhuhr = at(noon),
            asr = at(noon + hourAngle(asrAltitude)),
            maghrib = at(noon + hourAngle(-SUNRISE_ANGLE)),
            isha = at(noon + hourAngle(-ISHA_ANGLE))
        )
    }

    /** Prayer windows from yesterday to the day after tomorrow, sorted by start time. */
    fun events(city: City, today: LocalDate): List<PrayerEvent> {
        val days = (-1..2).map { compute(today.plusDays(it.toLong()), city) }
        val out = ArrayList<PrayerEvent>()
        for ((i, day) in days.withIndex()) {
            for (p in Prayer.values()) {
                val start = day.of(p)
                val end = when (p) {
                    Prayer.FAJR -> day.sunrise
                    Prayer.DHUHR -> day.asr
                    Prayer.ASR -> day.maghrib
                    Prayer.MAGHRIB -> day.isha
                    Prayer.ISHA -> days.getOrNull(i + 1)?.fajr ?: (start + 3_600_000L)
                }
                out.add(PrayerEvent(p, day.date, start, end))
            }
        }
        return out
    }
}
