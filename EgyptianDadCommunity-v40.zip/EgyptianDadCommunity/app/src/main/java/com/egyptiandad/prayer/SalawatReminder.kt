package com.egyptiandad.prayer

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.Instant
import java.time.LocalDate
import java.time.ZonedDateTime

/** A repeating reminder with a short sound that says "صلّ على محمد ﷺ". The user turns it on in settings. */
object SalawatReminder {
    const val CHANNEL = "salawat_reminder_v2"
    const val CHANNEL_SILENT = "salawat_reminder_silent"
    const val ACTION_COUNT = "com.egyptiandad.prayer.SALAWAT_COUNT"
    private const val REQUEST_CODE = 1002
    private const val NOTIFICATION_ID = 5151

    /** The next moment on the clock that is a multiple of [every] minutes, counted from midnight, after [now]. */
    fun nextAt(now: Long, every: Int): Long {
        val zdt: ZonedDateTime = Instant.ofEpochMilli(now).atZone(PrayerTimes.zone)
        val minutes = zdt.hour * 60 + zdt.minute
        val next = (minutes / every + 1) * every
        return zdt.toLocalDate().atStartOfDay(PrayerTimes.zone).plusMinutes(next.toLong()).toInstant().toEpochMilli()
    }

    fun isQuiet(prefs: Prefs, at: Long): Boolean {
        if (!prefs.quietOn) return false
        val zdt = Instant.ofEpochMilli(at).atZone(PrayerTimes.zone)
        val minute = zdt.hour * 60 + zdt.minute
        val from = prefs.quietStart * 60
        val to = prefs.quietEnd * 60
        return if (from == to) false else if (from < to) minute in from until to else minute >= from || minute < to
    }

    /** True when a prayer starts within two minutes of [at], so the adhan is not interrupted. */
    private fun nearAdhan(prefs: Prefs, at: Long): Boolean {
        val city = Cities.of(prefs)
        return PrayerTimes.events(city, PrayerTimes.today(at)).any {
            at >= it.start - 2 * 60_000L && at <= it.start + 2 * 60_000L
        }
    }

    private fun pending(context: Context, flags: Int = 0): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQUEST_CODE, Intent(context, SalawatReminderReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or flags
        )

    /** Arms the next reminder, or cancels it when the reminder is off. */
    fun schedule(context: Context, nowOverride: Long? = null) {
        val app = context.applicationContext
        val prefs = Prefs(app)
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(app, PendingIntent.FLAG_UPDATE_CURRENT)
        if (!prefs.salawatRemindOn) {
            am.cancel(pi)
            return
        }
        val at = nextAt(nowOverride ?: System.currentTimeMillis(), prefs.salawatEvery)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_SILENT) == null) {
            val silent = NotificationChannel(CHANNEL_SILENT, "تذكير الصلاة على النبي ﷺ (من غير صوت)", NotificationManager.IMPORTANCE_LOW)
            silent.description = "نفس التذكير لكن بدون صوت"
            silent.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(silent)
        }
        // The old channel kept the old sound (a channel's sound is fixed once created), so drop it.
        if (nm.getNotificationChannel("salawat_reminder") != null) nm.deleteNotificationChannel("salawat_reminder")
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val resId = context.resources.getIdentifier("salawat_reminder", "raw", context.packageName)
        val channel = NotificationChannel(CHANNEL, "تذكير الصلاة على النبي ﷺ", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "تنبيه متكرر بصوت \"صلّ على محمد\" بالفترة اللي تختارها"
        if (resId != 0) {
            channel.setSound(
                Uri.parse("android.resource://" + context.packageName + "/" + resId),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(channel)
    }

    @SuppressLint("MissingPermission")
    fun show(context: Context) {
        if (!Notifier.hasPermission(context)) return
        ensureChannel(context)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), flags)
        val count = PendingIntent.getBroadcast(
            context, REQUEST_CODE + 1,
            Intent(context, SalawatReminderReceiver::class.java).setAction(ACTION_COUNT), flags
        )
        val channelId = if (Prefs(context).salawatSoundOn) CHANNEL else CHANNEL_SILENT
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setContentTitle("صلّ على محمد ﷺ")
            .setContentText("اللهم صلّ وسلّم وبارك على سيدنا محمد")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setTimeoutAfter(10 * 60_000L)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "صلّيت عليه ﷺ", count)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
    }

    fun cancelNotification(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    /** Decides whether this reminder is heard now. */
    fun shouldShow(context: Context, at: Long): Boolean {
        val prefs = Prefs(context)
        if (!prefs.salawatRemindOn) return false
        if (isQuiet(prefs, at)) return false
        if (nearAdhan(prefs, at)) return false
        if (RadioState.status == RadioStatus.LOADING || RadioState.status == RadioStatus.PLAYING) return false
        return true
    }
}

class SalawatReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == SalawatReminder.ACTION_COUNT) {
            Prefs(context).addSalawat(LocalDate.now(PrayerTimes.zone).toString())
            SalawatReminder.cancelNotification(context)
            return
        }
        val now = System.currentTimeMillis()
        // An alarm that arrives much later than planned (phone asleep) is skipped instead of playing late.
        if (SalawatReminder.shouldShow(context, now)) SalawatReminder.show(context)
        SalawatReminder.schedule(context, now)
    }
}
