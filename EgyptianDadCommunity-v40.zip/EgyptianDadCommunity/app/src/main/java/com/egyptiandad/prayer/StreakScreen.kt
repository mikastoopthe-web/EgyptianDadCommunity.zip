package com.egyptiandad.prayer

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable
fun StreakScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(5000)
        }
    }

    val today = PrayerTimes.today(now)
    val done = prefs.prayedSet()
    val city = Cities.of(prefs)
    val current = Streaks.current(done, today)
    val best = Streaks.best(done, today)
    val total = Streaks.totalFullDays(done, today)

    // Counting starts on the first day the app was used, or the earliest day with a mark.
    val earliestMark = done.mapNotNull { runCatching { LocalDate.parse(it.take(10)) }.getOrNull() }.minOrNull()
    val first = prefs.firstUse()
    val start = if (earliestMark != null && earliestMark.isBefore(first)) earliestMark else first

    val startedToday = PrayerTimes.events(city, today).count { it.date == today && it.start <= now }

    fun due(from: LocalDate): Int {
        val begin = if (from.isBefore(start)) start else from
        if (begin.isAfter(today)) return 0
        val daysBefore = java.time.temporal.ChronoUnit.DAYS.between(begin, today).toInt()
        return daysBefore * Prayer.values().size + startedToday
    }

    val weekFrom = today.minusDays(6)
    val monthFrom = today.minusDays(29)

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("إنجازي في الصلاة", color = Gold.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.verticalGradient(listOf(Gold.GoldDark, Gold.Gold)))
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("أيام الصلاة كاملة ورا بعض", color = Gold.Black, fontSize = 14.sp)
                Text(
                    if (current > 0) daysText(current) else "ابدأ سلسلتك النهارده",
                    color = Gold.Black,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )
                Text("أفضل سلسلة: " + daysText(best), color = Gold.Black, fontSize = 14.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SmallStat("أيام كاملة", arabicNumber(total), Modifier.weight(1f))
            SmallStat("صلوات النهارده", arabicNumber(Streaks.dayCount(done, today)) + " / ٥", Modifier.weight(1f))
        }

        PeriodCard(
            "آخر ٧ أيام",
            Streaks.prayedBetween(done, weekFrom, today),
            due(weekFrom),
            Streaks.fullBetween(done, weekFrom, today)
        )
        PeriodCard(
            "آخر ٣٠ يوم",
            Streaks.prayedBetween(done, monthFrom, today),
            due(monthFrom),
            Streaks.fullBetween(done, monthFrom, today)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Gold.Line)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سجل آخر ٢٨ يوم", color = Gold.GoldLight, fontWeight = FontWeight.SemiBold)
                for (week in 0 until 4) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        for (d in 0 until 7) {
                            val date = today.minusDays((27 - (week * 7 + d)).toLong())
                            val count = Streaks.dayCount(done, date)
                            val color = when {
                                date.isBefore(start) -> Gold.Surface
                                count == 5 -> Gold.Gold
                                count > 0 -> Gold.GoldDark
                                else -> Gold.Line
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(color),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    arabicNumber(date.dayOfMonth),
                                    fontSize = 11.sp,
                                    color = if (count == 5) Gold.Black else Gold.Ink
                                )
                            }
                        }
                    }
                }
                Text(
                    "ذهبي = الخمس صلوات كاملة، ذهبي غامق = بعضهم.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }
        }

        Text(
            "الإحصائيات خاصة بيك ومتخزنة على موبايلك بس. الحساب بيبدأ من أول يوم استخدمت فيه التطبيق.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun SmallStat(label: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Gold.Line)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Text(value, color = Gold.Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PeriodCard(title: String, prayed: Int, due: Int, fullDays: Int) {
    val fraction = if (due > 0) (prayed.toFloat() / due.toFloat()).coerceIn(0f, 1f) else 0f
    val percent = (fraction * 100f).toInt()
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Gold.Line)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = Gold.GoldLight, fontWeight = FontWeight.SemiBold)
                Text(arabicNumber(percent) + "٪", color = Gold.Gold, fontWeight = FontWeight.Bold)
            }
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth(),
                color = Gold.Gold,
                trackColor = Gold.Line
            )
            Text(
                "صلّيت " + arabicNumber(prayed) + " من " + arabicNumber(due) + " صلاة · " +
                    arabicNumber(fullDays) + " يوم كامل",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
        }
    }
}
