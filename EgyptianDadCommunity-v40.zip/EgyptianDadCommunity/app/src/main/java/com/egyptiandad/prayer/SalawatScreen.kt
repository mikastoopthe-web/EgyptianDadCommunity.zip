package com.egyptiandad.prayer

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun SalawatScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val prefs = remember { Prefs(ctx) }
    val date = LocalDate.now(PrayerTimes.zone).toString()

    var total by remember { mutableLongStateOf(prefs.salawatTotal) }
    var todayCount by remember { mutableIntStateOf(prefs.salawatToday(date)) }
    var confirmReset by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }

    // Play the page sound as soon as the page opens, and stop it when the user leaves.
    DisposableEffect(Unit) {
        SalawatPageSound.play(ctx)
        onDispose { SalawatPageSound.stop() }
    }

    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "press",
        finishedListener = { pressed = false }
    )

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("الصلاة على النبي ﷺ", color = Gold.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Gold.GoldDark)
        ) {
            Text(
                "اللّهمّ صلّ وسلّم وبارك على سيّدنا محمّد",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                textAlign = TextAlign.Center,
                color = Gold.GoldLight,
                fontSize = 22.sp,
                lineHeight = 36.sp
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard("النهارده", arabicNumber(todayCount), Modifier.weight(1f))
            StatCard("الإجمالي", arabicNumber(total), Modifier.weight(1f))
        }

        Box(
            modifier = Modifier
                .size(190.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Gold.GoldLight, Gold.Gold, Gold.GoldDark)))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    prefs.addSalawat(date)
                    total = prefs.salawatTotal
                    todayCount = prefs.salawatToday(date)
                    pressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("+", color = Gold.Black, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                Text("صلّيت على النبي ﷺ", color = Gold.Black, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Text(
            "العدّاد بيتحفظ تلقائي على موبايلك.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )

        OutlinedButton(onClick = { confirmReset = true }, enabled = total > 0L) {
            Text("تصفير العدّاد")
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("تصفير العدّاد؟") },
            text = { Text("هيتمسح الإجمالي (" + arabicNumber(total) + ") وعدّاد النهارده، ومش هتقدر ترجعهم.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.resetSalawat()
                    total = 0L
                    todayCount = 0
                    confirmReset = false
                }) { Text("امسح") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Gold.Line)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Text(value, color = Gold.Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}
