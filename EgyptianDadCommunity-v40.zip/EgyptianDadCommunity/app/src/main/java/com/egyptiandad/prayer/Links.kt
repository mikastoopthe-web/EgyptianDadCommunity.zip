package com.egyptiandad.prayer

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

const val FACEBOOK_URL = "https://www.facebook.com/share/1JkBSfpsRh/"

/** Opens a link in the Facebook app if it is installed, otherwise in the browser. */
fun openLink(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        // No app can open the link. Nothing else to do.
    }
}

const val APP_ID = "com.egyptiandad.prayer"
const val PLAY_URL = "https://play.google.com/store/apps/details?id=" + APP_ID

/** Opens the app page in Google Play, or in the browser if Play is not installed. */
fun rateApp(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + APP_ID)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        openLink(context, PLAY_URL)
    }
}

/** Opens the system share sheet with a short message and the app link. */
fun shareApp(context: Context) {
    val send = Intent(Intent.ACTION_SEND)
        .setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, "جرّب تطبيق مواقيت الصلاة والأذكار من Egyptian Dad Community:\n" + PLAY_URL)
    try {
        context.startActivity(Intent.createChooser(send, "مشاركة التطبيق").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        // Nothing can share text. Nothing else to do.
    }
}
