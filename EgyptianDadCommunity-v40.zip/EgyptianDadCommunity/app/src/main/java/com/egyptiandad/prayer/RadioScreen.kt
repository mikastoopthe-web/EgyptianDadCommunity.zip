package com.egyptiandad.prayer

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private enum class RadioTab { LIVE, FAVORITES, HISTORY }

private val barShape = floatArrayOf(
    0.30f, 0.55f, 0.95f, 0.65f, 1.00f, 0.60f, 0.85f, 0.45f,
    0.70f, 0.35f, 0.50f, 0.25f, 0.35f, 0.18f, 0.22f, 0.12f
)

@Composable
fun RadioScreen(onNavigate: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val status = RadioState.status
    val selected = RadioState.station
    val active = status == RadioStatus.LOADING || status == RadioStatus.PLAYING
    val playing = status == RadioStatus.PLAYING

    var tab by remember { mutableStateOf(RadioTab.LIVE) }
    var favorites by remember { mutableStateOf(prefs.favoriteNames()) }
    var history by remember { mutableStateOf(prefs.radioHistory()) }

    fun toggle(index: Int) {
        if (active && index == selected) {
            RadioService.stop()
        } else {
            RadioState.station = index
            RadioState.status = RadioStatus.LOADING
            RadioService.play(ctx, index)
            prefs.addRadioHistory(Stations.all[index].name)
            history = prefs.radioHistory()
        }
    }

    fun toggleFavorite(index: Int) {
        prefs.toggleFavorite(Stations.all[index].name)
        favorites = prefs.favoriteNames()
    }

    // One animation clock for the whole screen. It is only read while drawing, so the lists do not redraw with it.
    val transition = rememberInfiniteTransition(label = "radio")
    val wave: State<Float> = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "wave"
    )

    val current = Stations.all[selected.coerceIn(0, Stations.all.size - 1)]
    val statusLine = when (status) {
        RadioStatus.LOADING -> "جاري الاتصال..."
        RadioStatus.ERROR -> "تعذّر التشغيل. تأكد من الإنترنت وجرّب تاني."
        else -> current.description
    }

    val indices: List<Int> = when (tab) {
        RadioTab.LIVE -> Stations.all.indices.toList()
        RadioTab.FAVORITES -> Stations.all.indices.filter { Stations.all[it].name in favorites }
        RadioTab.HISTORY -> history.mapNotNull { name ->
            val i = Stations.all.indexOfFirst { it.name == name }
            if (i >= 0) i else null
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ScreenHeader(
                title = "الإذاعة",
                onSettings = { onNavigate(Routes.SETTINGS) },
                onProfile = { onNavigate(Routes.SETTINGS) }
            )

            Box(
                modifier = Modifier.fillMaxWidth().height(112.dp),
                contentAlignment = Alignment.Center
            ) {
                Waveform(wave = wave, playing = playing, modifier = Modifier.fillMaxSize())
                HeroButton(active = active, playing = playing, wave = wave) { toggle(selected) }
            }
            Text(
                "استمع إلى أجمل التلاوات والقراءات",
                color = Gold.Gold,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))

            TabBar(selected = tab, onSelect = { tab = it })
            Spacer(Modifier.height(12.dp))

            NowPlayingCard(
                name = current.name,
                line = statusLine,
                label = when {
                    status == RadioStatus.PLAYING && current.playlist -> "جاري التلاوة"
                    status == RadioStatus.PLAYING -> "مباشرة الآن"
                    else -> "المحطة المختارة"
                },
                live = playing,
                isError = status == RadioStatus.ERROR,
                wave = wave
            )
            Spacer(Modifier.height(10.dp))

            val listShape = RoundedCornerShape(30.dp)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(listShape)
                    .background(Gold.Black.copy(alpha = 0.55f))
                    .border(1.dp, Gold.GoldDark.copy(alpha = 0.7f), listShape)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (indices.isEmpty()) {
                    Text(
                        if (tab == RadioTab.FAVORITES) "لسه ماضفتش محطات للمفضلة. اضغط على النجمة جنب أي محطة."
                        else "لسه ماسمعتش أي محطة. اختار محطة من «إذاعة مباشرة».",
                        color = Gold.Muted,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 12.dp)
                    )
                }
                indices.forEachIndexed { pos, index ->
                    val station = Stations.all[index]
                    if (tab == RadioTab.LIVE && pos > 0 && Stations.all[indices[pos - 1]].group != station.group) {
                        Text(
                            station.group,
                            color = Gold.Gold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 6.dp)
                        )
                    }
                    StationRow(
                        station = station,
                        isSelected = index == selected,
                        isPlaying = active && index == selected,
                        isFavorite = station.name in favorites,
                        onFavorite = { toggleFavorite(index) },
                        onPlay = { toggle(index) }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "الإذاعة بتحتاج إنترنت، وبتكمل شغل والشاشة مقفولة. بتقف لوحدها لما الأذان يبدأ.",
                color = Gold.Muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
            Spacer(Modifier.height(12.dp))
        }

        if (active) {
            MiniPlayer(name = current.name, line = statusLine, onStop = { RadioService.stop() })
            Spacer(Modifier.height(4.dp))
        }
    }
}

/** Gold bars on both sides of the play button. They dance while the radio plays. */
@Composable
private fun Waveform(wave: State<Float>, playing: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val start = 72.dp.toPx()
        val spacing = 9.dp.toPx()
        val count = ((cx - start - 6.dp.toPx()) / spacing).toInt().coerceIn(0, barShape.size)
        val phase = wave.value * 6.2831855f
        for (side in 0 until 2) {
            val dir = if (side == 0) 1f else -1f
            for (i in 0 until count) {
                var f = barShape[i]
                if (playing) f *= 0.6f + 0.4f * sin(phase + i * 0.8f + side * 1.3f)
                val half = (this.size.height * 0.46f * f).coerceAtLeast(2.dp.toPx())
                val x = cx + dir * (start + i * spacing)
                drawLine(
                    color = Gold.Gold.copy(alpha = (1f - i / 20f).coerceIn(0.25f, 1f)),
                    start = Offset(x, cy - half),
                    end = Offset(x, cy + half),
                    strokeWidth = 2.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun HeroButton(active: Boolean, playing: Boolean, wave: State<Float>, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(104.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val s = this.size.minDimension
            val c = Offset(s / 2f, s / 2f)
            if (playing) {
                for (k in 0 until 2) {
                    val t = (wave.value + k * 0.5f) % 1f
                    drawCircle(
                        Gold.Gold.copy(alpha = (1f - t) * 0.5f),
                        radius = s * (0.34f + 0.16f * t),
                        center = c,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
            drawCircle(Gold.Gold.copy(alpha = 0.25f), radius = s * 0.49f, center = c, style = Stroke(width = 1.dp.toPx()))
            drawCircle(Gold.Gold.copy(alpha = 0.55f), radius = s * 0.45f, center = c, style = Stroke(width = 1.5.dp.toPx()))
            drawCircle(
                brush = Brush.radialGradient(listOf(Gold.GoldLight, Gold.Gold, Gold.GoldDark), center = c, radius = s * 0.40f),
                radius = s * 0.40f,
                center = c
            )
            if (active) {
                val r = CornerRadius(2.dp.toPx())
                drawRoundRect(Gold.Black, Offset(s * 0.38f, s * 0.35f), Size(s * 0.09f, s * 0.30f), r)
                drawRoundRect(Gold.Black, Offset(s * 0.53f, s * 0.35f), Size(s * 0.09f, s * 0.30f), r)
            } else {
                val tri = Path()
                tri.moveTo(s * 0.43f, s * 0.33f)
                tri.lineTo(s * 0.43f, s * 0.67f)
                tri.lineTo(s * 0.69f, s * 0.50f)
                tri.close()
                drawPath(tri, Gold.Black)
            }
        }
    }
}

@Composable
private fun TabBar(selected: RadioTab, onSelect: (RadioTab) -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Gold.Black.copy(alpha = 0.6f))
            .border(1.dp, Gold.GoldDark.copy(alpha = 0.8f), shape)
            .padding(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TabItem("سجل الاستماع", selected == RadioTab.HISTORY, { onSelect(RadioTab.HISTORY) }) { tint ->
            GoldIcon(IconKind.CLOCK, tint, Modifier.size(19.dp))
        }
        Box(Modifier.width(1.dp).height(28.dp).background(Gold.GoldDark.copy(alpha = 0.6f)))
        TabItem("المفضلة", selected == RadioTab.FAVORITES, { onSelect(RadioTab.FAVORITES) }) { tint ->
            StarGlyph(filled = true, tint = tint, size = 19.dp)
        }
        Box(Modifier.width(1.dp).height(28.dp).background(Gold.GoldDark.copy(alpha = 0.6f)))
        TabItem("إذاعة مباشرة", selected == RadioTab.LIVE, { onSelect(RadioTab.LIVE) }) { tint ->
            GoldIcon(IconKind.RADIO, tint, Modifier.size(19.dp))
        }
    }
}

@Composable
private fun RowScope.TabItem(label: String, isSelected: Boolean, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val tint = if (isSelected) Gold.Black else Gold.Gold
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = Modifier
            .weight(1f)
            .clip(shape)
            .then(
                if (isSelected) Modifier.background(Brush.horizontalGradient(listOf(Gold.GoldLight, Gold.Gold)))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon(tint)
        Spacer(Modifier.height(1.dp))
        Text(label, color = tint, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun NowPlayingCard(name: String, line: String, label: String, live: Boolean, isError: Boolean, wave: State<Float>) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF1C160A), Color(0xFF0E0B06))))
            .border(1.2.dp, Gold.Gold.copy(alpha = 0.85f), shape)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MiniBars(wave = wave, live = live, modifier = Modifier.size(width = 24.dp, height = 28.dp))
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(Gold.Gold))
                Spacer(Modifier.width(6.dp))
                Text(label, color = Gold.Gold, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(2.dp))
            Text(name, color = Gold.Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(
                line,
                color = if (isError) Color(0xFFE57373) else Gold.Muted,
                fontSize = 13.sp
            )
        }
        Spacer(Modifier.width(10.dp))
        RadioRing(size = 48.dp)
    }
}

/** Five little bars. They move only while the radio plays. */
@Composable
private fun MiniBars(wave: State<Float>, live: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val cy = this.size.height / 2f
        val gap = this.size.width / 5f
        val base = floatArrayOf(0.35f, 0.7f, 1f, 0.6f, 0.4f)
        val phase = wave.value * 6.2831855f
        for (i in 0 until 5) {
            var f = base[i]
            if (live) f *= 0.55f + 0.45f * sin(phase + i * 1.1f)
            val half = this.size.height * 0.5f * f
            val x = gap * (i + 0.5f)
            drawLine(Gold.Gold, Offset(x, cy - half), Offset(x, cy + half), 2.5.dp.toPx(), StrokeCap.Round)
        }
    }
}

@Composable
private fun RadioRing(size: Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Gold.Black.copy(alpha = 0.9f))
            .border(1.5.dp, Gold.Gold, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        GoldIcon(IconKind.RADIO, Gold.Gold, Modifier.size(size * 0.52f))
    }
}

@Composable
private fun StationRow(
    station: Station,
    isSelected: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onFavorite: () -> Unit,
    onPlay: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (isSelected) Gold.SurfaceHigh.copy(alpha = 0.8f) else Gold.Black.copy(alpha = 0.45f))
            .border(1.dp, if (isSelected) Gold.Gold.copy(alpha = 0.7f) else Gold.GoldDark.copy(alpha = 0.35f), shape)
            .clickable(onClick = onPlay)
            .padding(horizontal = 6.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onFavorite),
            contentAlignment = Alignment.Center
        ) {
            StarGlyph(filled = isFavorite, tint = Gold.Gold, size = 21.dp)
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Text(
                station.name,
                color = if (isSelected) Gold.GoldLight else Gold.Ink,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(station.description, color = Gold.Muted, fontSize = 12.sp)
        }
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Gold.Black.copy(alpha = 0.8f))
                .border(1.2.dp, Gold.Gold.copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (isPlaying) PauseGlyph(Gold.Gold, 15.dp) else GoldIcon(IconKind.PLAY, Gold.Gold, Modifier.size(15.dp))
        }
    }
}

@Composable
private fun MiniPlayer(name: String, line: String, onStop: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Gold.Black.copy(alpha = 0.9f))
            .border(1.2.dp, Gold.Gold.copy(alpha = 0.8f), shape)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Gold.GoldLight, Gold.Gold)))
                .clickable(onClick = onStop),
            contentAlignment = Alignment.Center
        ) {
            PauseGlyph(Gold.Black, 17.dp)
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.width(1.dp).height(30.dp).background(Gold.GoldDark.copy(alpha = 0.7f)))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(name, color = Gold.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(line, color = Gold.Muted, fontSize = 12.sp, maxLines = 1)
        }
        Spacer(Modifier.width(10.dp))
        RadioRing(size = 40.dp)
    }
}

@Composable
private fun StarGlyph(filled: Boolean, tint: Color, size: Dp) {
    Canvas(modifier = Modifier.size(size)) {
        val s = this.size.minDimension
        val cx = s / 2f
        val cy = s * 0.54f
        val path = Path()
        for (k in 0 until 10) {
            val radius = if (k % 2 == 0) s * 0.46f else s * 0.19f
            val a = Math.toRadians(-90.0 + k * 36.0)
            val x = cx + radius * cos(a).toFloat()
            val y = cy + radius * sin(a).toFloat()
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        if (filled) {
            drawPath(path, tint)
        } else {
            drawPath(path, tint, style = Stroke(width = s * 0.085f, join = StrokeJoin.Round))
        }
    }
}

@Composable
private fun PauseGlyph(tint: Color, size: Dp) {
    Canvas(modifier = Modifier.size(size)) {
        val s = this.size.minDimension
        val r = CornerRadius(s * 0.08f)
        drawRoundRect(tint, Offset(s * 0.18f, s * 0.12f), Size(s * 0.24f, s * 0.76f), r)
        drawRoundRect(tint, Offset(s * 0.58f, s * 0.12f), Size(s * 0.24f, s * 0.76f), r)
    }
}
