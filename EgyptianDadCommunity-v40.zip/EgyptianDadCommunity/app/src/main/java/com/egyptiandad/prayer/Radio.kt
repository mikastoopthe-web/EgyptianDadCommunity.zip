package com.egyptiandad.prayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.ExoPlayer

/**
 * One thing the radio screen can play.
 * [urls] are tried in order for a live stream (the next one is used if one fails).
 * When [playlist] is true the urls are separate files that play one after another.
 */
data class Station(
    val name: String,
    val description: String,
    val urls: List<String>,
    val group: String = "إذاعات مباشرة",
    val playlist: Boolean = false
)

/** Stream addresses. Change them here if a station moves. */
object Stations {
    private const val REFAAT = "https://cdn.mp3quran.net/audio/muhammad-refaat/r1/"
    private const val SHUAISHA = "https://media.way2quran.com/abu-al-ainin-shisha/hafs-an-asim/"

    // Surahs that the Mohammad Refaat collection on mp3quran.net actually has.
    private val refaatSurahs = listOf(
        1, 10, 11, 12, 17, 18, 19, 20, 48, 54, 55, 56, 69, 72, 73, 75,
        76, 77, 78, 79, 81, 82, 83, 85, 86, 87, 88, 89, 96, 98, 100
    )

    // Files of Sheikh Abu Al-Ainain Shuaisha on way2quran.com (full surahs and selections).
    private val shuaishaFiles = listOf(
        "002-001", "002-002", "002-003", "002-004", "003-001", "003-002",
        "004-001", "005-001", "006-001", "007-001", "008-001", "009-001",
        "010-001", "011-001", "012-001", "013-001", "014-001", "015-001",
        "016-001", "016-002", "016-003", "017-001", "017-002", "018-001",
        "019-001", "020-001", "021-001", "022-001", "023-001", "024-001",
        "026-001", "028-001", "028-002", "029-001", "030-001", "033-001",
        "042-001", "043-001", "047-001", "048-001", "051-001", "052-001",
        "053-001", "054-001", "055-001", "055-002", "057-001", "069-001",
        "094", "095", "096", "097", "106"
    )

    val all = listOf(
        Station(
            "إذاعة القرآن الكريم من القاهرة",
            "بث مباشر على مدار الساعة",
            listOf(
                "https://stream.radiojar.com/8s5u5tpdtwzuv",
                "https://n07.radiojar.com/8s5u5tpdtwzuv",
                "https://n12.radiojar.com/8s5u5tpdtwzuv"
            )
        ),
        Station(
            "الشيخ محمود خليل الحصري",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/mahmoud_khalil_alhussary",
                "https://backup.qurango.net/radio/mahmoud_khalil_alhussary"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ محمد جبريل",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/mohammed_jibreel",
                "https://backup.qurango.net/radio/mohammed_jibreel"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ عبد الرحمن السديس",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/abdulrahman_alsudaes",
                "https://backup.qurango.net/radio/abdulrahman_alsudaes"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ ياسر الدوسري",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/yasser_aldosari",
                "https://backup.qurango.net/radio/yasser_aldosari"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ مصطفى إسماعيل",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/mustafa_ismail",
                "https://backup.qurango.net/radio/mustafa_ismail"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ محمد صديق المنشاوي",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/mohammed_siddiq_alminshawi",
                "https://backup.qurango.net/radio/mohammed_siddiq_alminshawi"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ عبد الباسط عبد الصمد",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/abdulbasit_abdulsamad",
                "https://backup.qurango.net/radio/abdulbasit_abdulsamad"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ محمود علي البنا",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/mahmoud_ali__albanna",
                "https://backup.qurango.net/radio/mahmoud_ali__albanna"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ محمد محمود الطبلاوي",
            "القرآن الكريم مرتل، بث متواصل",
            listOf(
                "https://qurango.net/radio/mohammad_altablaway",
                "https://backup.qurango.net/radio/mohammad_altablaway"
            ),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ محمد رفعت",
            "سور مختارة بصوت الشيخ، تتشغل ورا بعض",
            refaatSurahs.map { REFAAT + it.toString().padStart(3, '0') + ".mp3" },
            group = "القرآن بأصوات القراء",
            playlist = true
        ),
        Station(
            "الشيخ أبو العينين شعيشع",
            "تلاوات مختارة بصوت الشيخ، بتتشغل ورا بعض",
            shuaishaFiles.map { SHUAISHA + it + ".mp3" },
            group = "القرآن بأصوات القراء",
            playlist = true
        ),
        Station(
            "الشيخ الزين محمد أحمد",
            "القرآن الكريم مرتل، بث متواصل",
            listOf("https://Qurango.net/radio/alzain_mohammad_ahmad"),
            group = "القرآن بأصوات القراء"
        ),
        Station(
            "الشيخ أحمد خضر الطرابلسي",
            "القرآن الكريم مرتل، بث متواصل",
            listOf("https://Qurango.net/radio/ahmad_khader_altarabulsi"),
            group = "القرآن بأصوات القراء"
        )
    )
}

enum class RadioStatus { IDLE, LOADING, PLAYING, ERROR }

/** What the radio screen shows. The service updates it. */
object RadioState {
    var status by mutableStateOf(RadioStatus.IDLE)
    var station by mutableIntStateOf(0)
}

class RadioService : Service() {
    companion object {
        const val ACTION_PLAY = "com.egyptiandad.prayer.RADIO_PLAY"
        const val ACTION_STOP = "com.egyptiandad.prayer.RADIO_STOP"
        const val EXTRA_STATION = "station"
        private const val CHANNEL = "radio"
        private const val NOTIFICATION_ID = 7001

        @Volatile
        var current: RadioService? = null

        fun play(context: Context, station: Int) {
            val intent = Intent(context, RadioService::class.java)
                .setAction(ACTION_PLAY)
                .putExtra(EXTRA_STATION, station)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop() {
            current?.stopPlayback()
            RadioState.status = RadioStatus.IDLE
        }
    }

    private var player: ExoPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        current = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> startPlayback(intent.getIntExtra(EXTRA_STATION, 0))
            ACTION_STOP -> stopPlayback()
            else -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    private fun startPlayback(index: Int) {
        val station = Stations.all[index.coerceIn(0, Stations.all.size - 1)]
        RadioState.station = Stations.all.indexOf(station)
        RadioState.status = RadioStatus.LOADING

        val notification = buildNotification(station)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        player?.release()

        // Many radio hosts answer an https address with a redirect to a plain http address that carries a token.
        // ExoPlayer refuses that by default, which is why such a stream "does not play". Allow it here.
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setUserAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")

        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        exo.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
        exo.setHandleAudioBecomingNoisy(true)
        exo.setWakeMode(C.WAKE_MODE_NETWORK)

        var urlIndex = 0
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_BUFFERING) RadioState.status = RadioStatus.LOADING
                if (state == Player.STATE_READY) RadioState.status = RadioStatus.PLAYING
            }

            override fun onPlayerError(error: PlaybackException) {
                if (station.playlist) {
                    // One file failed. Skip to the next one, and give up only when none is left.
                    if (exo.hasNextMediaItem()) {
                        exo.seekToNextMediaItem()
                        exo.prepare()
                        exo.play()
                        return
                    }
                } else if (urlIndex + 1 < station.urls.size) {
                    // The live address failed. Try the next address for the same station.
                    urlIndex++
                    RadioState.status = RadioStatus.LOADING
                    exo.setMediaItem(MediaItem.fromUri(station.urls[urlIndex]))
                    exo.prepare()
                    exo.play()
                    return
                }
                RadioState.status = RadioStatus.ERROR
                stopPlayback(keepStatus = true)
            }
        })

        if (station.playlist) {
            exo.setMediaItems(station.urls.map { MediaItem.fromUri(it) })
            exo.repeatMode = Player.REPEAT_MODE_ALL
        } else {
            exo.setMediaItem(MediaItem.fromUri(station.urls[0]))
        }
        exo.playWhenReady = true
        exo.prepare()
        player = exo
    }

    fun stopPlayback(keepStatus: Boolean = false) {
        player?.release()
        player = null
        if (!keepStatus) RadioState.status = RadioStatus.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        if (current === this) current = null
        super.onDestroy()
    }

    private fun buildNotification(station: Station): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val channel = NotificationChannel(CHANNEL, "الإذاعة", NotificationManager.IMPORTANCE_LOW)
            channel.description = "تشغيل إذاعة القرآن الكريم"
            nm.createNotificationChannel(channel)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RadioService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setContentTitle(station.name)
            .setContentText(if (station.playlist) "تلاوة" else "بث مباشر")
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "إيقاف", stop)
            .build()
    }
}
