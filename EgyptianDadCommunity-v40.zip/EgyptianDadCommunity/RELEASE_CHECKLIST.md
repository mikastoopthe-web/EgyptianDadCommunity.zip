# Final release checklist (v3.7 / versionCode 28)

## What is already done in this package
- targetSdk/compileSdk 36 (Google Play requires 36 for new apps and updates since 31 Aug 2026), AGP 8.9.1, Gradle 8.11.1
- Release signing reads a private key from keystore.properties (git-ignored); CI builds a signed AAB when secrets exist
- allowBackup turned off, version bumped, English privacy policy, store listing text, Play declarations text

## You must do (I can't do these for you)
1. Create the upload key ONCE and back it up in 2 places:
   keytool -genkeypair -v -keystore upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   Copy keystore.properties.example to keystore.properties and fill it in. Never lose or share the .jks.
2. Build: ./gradlew bundleRelease  ->  app/build/outputs/bundle/release/app-release.aab (upload this to Play)
   For friends/testing: ./gradlew assembleDebug (the APK).
3. Put your real email in PRIVACY.md and host it as a web page; paste the link in Play Console.
4. Rights (the main rejection/takedown risk):
   - Cairo Quran radio is a third-party Radiojar stream, not confirmed official. Get permission from the Egyptian National Media Authority or remove that station.
   - adhan*.mp3, salawat_reminder.mp3, salawat_page.mp3, prayed_sound.mp3, app_sound.mp3: confirm you own or are licensed to use each. Remove any you can't prove.
   - Reciter streams (Qurango, mp3quran, way2quran): check their terms allow use in an app.
5. Have a trusted source review the adhkar text (e.g. Hisn al-Muslim) before public release.
6. Test on a real phone with Android 14-16: alerts with screen off, after reboot, battery-saver on, radio stops at adhan, notification permission denied.
7. New personal Play accounts must usually run a closed test (12+ testers for 14 days) before production. Check Play Console.

## Known trade-offs
- usesCleartextTraffic=true stays because the Cairo stream redirects to plain http. If you drop that station, set it to false.
- The on-screen crash report is a developer tool; fine for v3.7, replace with a friendlier message later.
