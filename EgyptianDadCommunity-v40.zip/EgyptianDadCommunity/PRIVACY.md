# سياسة الخصوصية: Egyptian Dad Community

آخر تحديث: نوفمبر 2026

تطبيق Egyptian Dad Community بيحسب مواعيد الصلاة واتجاه القبلة على الموبايل نفسه.

- **مش بنجمع أي بيانات شخصية.** مفيش حساب ولا تسجيل دخول.
- **الإنترنت لتشغيل الإذاعة بس.** التطبيق مش بيبعت أي بيانات عنك. لما تشغّل الإذاعة جهازك بيتصل بسيرفر البث زي أي مشغل صوت.
- **الموقع اختياري.** المستخدم بيختار مدينته من قايمة، أو بيضغط "استخدم موقعي" فيتقرا آخر موقع تقريبي مرة واحدة ويتخزن على الجهاز بس ومبيتبعتش.
- **حساس الاتجاه (البوصلة):** بيتقرأ على الجهاز بس لعرض اتجاه القبلة، ومش بيتسجل ولا بيتبعت.
- **اللي بيتخزّن على الجهاز بس:** المدينة المختارة، فترة تكرار التنبيه، وعلامات "صلّيت" لحوالي سنة (عشان عدّاد الأيام)، وعدّاد الأذكار لآخر أيام قليلة، وعدّاد الصلاة على النبي، وإعدادات الأذان والعرض. وبيتمسح كله لما تحذف التطبيق.
- **الصلاحيات:** الإشعارات والمنبهات الدقيقة وتشغيل التنبيهات بعد إعادة تشغيل الموبايل، وكلها لتنبيهات الصلاة بس.

للتواصل: Amrrady009@gmail.com

---

# Privacy Policy: Egyptian Dad Community (English)

Last updated: November 2026

Egyptian Dad Community calculates prayer times and the Qibla direction on your device.

- **We collect no personal data.** No account, no sign-in, no analytics, no ads.
- **Internet is used only to stream radio.** The app sends nothing about you. When you play the radio, your device connects to the stream server like any audio player.
- **Location is optional.** You pick a city from a list, or tap "Use my location": the last approximate location is read once, stored on the device only, and never sent anywhere.
- **Compass sensor:** read on the device only to show the Qibla direction. Not recorded or sent.
- **Stored on the device only:** selected city, reminder interval, "prayed" marks (about one year, for the streak counter), recent dhikr counters, salawat counter, adhan and display settings. All of it is deleted when you uninstall the app.
- **Permissions:** notifications, exact alarms and boot completion, used only for prayer alerts; foreground service for radio playback and the optional persistent countdown notification.

Contact: Amrrady009@gmail.com
