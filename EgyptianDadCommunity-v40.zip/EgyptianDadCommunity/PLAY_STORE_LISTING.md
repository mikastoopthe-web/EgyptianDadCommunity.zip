# Google Play listing (copy into Play Console)

## App name (max 30)
Egyptian Dad Community | مواقيت الصلاة

## Short description (max 80)
AR: مواقيت الصلاة بتنبيه متكرر، قبلة، أذكار وإذاعة القرآن الكريم.
EN: Prayer times with repeat alerts, Qibla, adhkar and Quran radio.

## Full description (Arabic)
تطبيق بسيط وخفيف لمواقيت الصلاة، بثيم أسود وذهبي.

• تنبيه في وقت كل صلاة، حتى والشاشة مقفولة، ويتكرر لحد ما تضغط "صلّيت" أو الوقت يخلص
• أذان بأكتر من صوت تختار منه
• القبلة ببوصلة حديثة
• إذاعة القرآن الكريم وقرّاء كبار، وبتكمل والشاشة مقفولة
• أذكار الصباح والمساء وغيرها بعدّاد
• تذكير بالصلاة على النبي ﷺ (اختياري ومقفول افتراضيًا)
• "إنجازي": عدّاد أيام الالتزام بالصلاة
• إشعار دائم اختياري بالعدّ التنازلي للصلاة الجاية

خصوصيتك: مفيش حساب، ومفيش جمع بيانات. كل حاجة بتتخزن على موبايلك بس.
المواقيت تقديرية (طريقة الهيئة المصرية العامة للمساحة) وممكن تفرق كام دقيقة عن تقويم مسجدك.

## Full description (English)
A simple, light prayer-times app with a black and gold look.

• Alert at every prayer time, even with the screen off, repeating until you tap "Prayed" or the time ends
• Several adhan voices to choose from
• Modern Qibla compass
• Quran radio and renowned reciters, keeps playing with the screen off
• Morning/evening adhkar with counters
• Optional salawat reminder (off by default)
• Streak tracker for your prayers
• Optional persistent countdown notification

No account, no data collection: everything stays on your phone.
Times are estimates (Egyptian General Authority of Survey method) and may differ a few minutes from your local mosque.

## Category / tags
Lifestyle (or Books & Reference). Content rating questionnaire: no violence, no user-generated content.

## Graphics you still need to make
App icon 512x512, feature graphic 1024x500, at least 2 phone screenshots (use Home, Qibla, Radio).

## Data safety form answers
- Data collected: None
- Data shared: None
- Location: processed on device only, never sent off the device (answer "not collected")
- Data encrypted in transit: yes (HTTPS streams); users can request deletion: not applicable (no data held)
- Privacy policy URL: host PRIVACY.md as a web page (GitHub Pages works) and paste the link

## Declarations in Play Console > App content
1. Foreground service "Special use": "Persistent notification showing the countdown to the next prayer, enabled by the user in settings." Add a short demo video of the setting being turned on.
2. Foreground service "Media playback": Quran radio.
3. Exact alarm (USE_EXACT_ALARM): core function is prayer-time alerts that must fire on the minute. Google reviews this one. If it is rejected, remove USE_EXACT_ALARM from the manifest and keep SCHEDULE_EXACT_ALARM (user grants it in settings; the app already handles the denied case).
4. Location: optional, used once for prayer times/Qibla, stays on device.
5. Ads: none. Target audience: 13+ (avoid "for children").
