package com.egyptiandad.prayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.Instant
import kotlin.math.cos
import kotlin.math.sin

data class Dhikr(val text: String, val times: Int, val source: String? = null)

object Adhkar {
    private const val AYAT_KURSI =
        "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ"

    private const val IKHLAS =
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ ﴿٤﴾"

    private const val FALAQ =
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِنْ شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾"

    private const val NAS =
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾"

    private const val ISTIGHFAR =
        "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ"

    private const val AFIYA_BODY =
        "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ"

    private const val BISMILLAH_LA_YADURR =
        "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"

    private const val RADEETU =
        "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيًّا"

    private const val SUBHAN_ALLAH =
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"

    private const val LA_ILAHA =
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"

    private const val AL_AFW =
        "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي، اللَّهُمَّ اسْتُرْ عَوْرَاتِي وَآمِنْ رَوْعَاتِي، اللَّهُمَّ احْفَظْنِي مِنْ بَيْنِ يَدَيَّ وَمِنْ خَلْفِي وَعَنْ يَمِينِي وَعَنْ شِمَالِي وَمِنْ فَوْقِي، وَأَعُوذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِي"

    val morning: List<Dhikr> = listOf(
        Dhikr(AYAT_KURSI, 1, "آية الكرسي، سورة البقرة ٢٥٥"),
        Dhikr(IKHLAS, 3, "سورة الإخلاص"),
        Dhikr(FALAQ, 3, "سورة الفلق"),
        Dhikr(NAS, 3, "سورة الناس"),
        Dhikr(
            "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
            1, "رواه مسلم"
        ),
        Dhikr(
            "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
            1, "رواه الترمذي"
        ),
        Dhikr(ISTIGHFAR, 1, "سيد الاستغفار، رواه البخاري"),
        Dhikr(AFIYA_BODY, 3, "رواه أبو داود"),
        Dhikr(AL_AFW, 1, "رواه أبو داود وابن ماجه"),
        Dhikr(BISMILLAH_LA_YADURR, 3, "رواه أبو داود والترمذي"),
        Dhikr(RADEETU, 3, "رواه أبو داود والترمذي"),
        Dhikr(SUBHAN_ALLAH, 100, "رواه مسلم"),
        Dhikr(LA_ILAHA, 10)
    )

    val evening: List<Dhikr> = listOf(
        Dhikr(AYAT_KURSI, 1, "آية الكرسي، سورة البقرة ٢٥٥"),
        Dhikr(IKHLAS, 3, "سورة الإخلاص"),
        Dhikr(FALAQ, 3, "سورة الفلق"),
        Dhikr(NAS, 3, "سورة الناس"),
        Dhikr(
            "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
            1, "رواه مسلم"
        ),
        Dhikr(
            "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
            1, "رواه الترمذي"
        ),
        Dhikr(ISTIGHFAR, 1, "سيد الاستغفار، رواه البخاري"),
        Dhikr("أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", 3, "رواه الترمذي"),
        Dhikr(AFIYA_BODY, 3, "رواه أبو داود"),
        Dhikr(AL_AFW, 1, "رواه أبو داود وابن ماجه"),
        Dhikr(BISMILLAH_LA_YADURR, 3, "رواه أبو داود والترمذي"),
        Dhikr(RADEETU, 3, "رواه أبو داود والترمذي"),
        Dhikr(SUBHAN_ALLAH, 100, "رواه مسلم"),
        Dhikr(LA_ILAHA, 10)
    )
}

/** Reads a dhikr aloud with the phone's own text-to-speech. Needs no internet when an Arabic voice is installed. */
@Composable
fun AdhkarScreen(onNavigate: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val now = System.currentTimeMillis()
    val hour = Instant.ofEpochMilli(now).atZone(PrayerTimes.zone).hour

    var morning by remember { mutableStateOf(hour < 15) }

    // Old counters are cleaned once, in the background, not on every tap.
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { prefs.pruneDhikr() } }

    val date = PrayerTimes.today(now).toString()
    val period = if (morning) "morning" else "evening"
    val items = if (morning) Adhkar.morning else Adhkar.evening

    // Only the cards on screen are built, and a tap only redraws its own card.
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "header") {
            Column(modifier = Modifier.fillMaxWidth()) {
                ScreenHeader(
                    title = "أذكـار",
                    onSettings = { onNavigate(Routes.SETTINGS) },
                    onProfile = { onNavigate(Routes.SETTINGS) }
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                ) {
                    Diamond()
                    Text("الصباح والمساء", color = Gold.Gold, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Diamond()
                }
                Skyline()
                Spacer(Modifier.height(8.dp))
                PeriodTabs(morning = morning, onSelect = { morning = it })
                Spacer(Modifier.height(12.dp))
                Text(
                    if (morning) "وقتها من بعد الفجر لحد ما الشمس تطلع، ويجوز قبل الظهر."
                    else "وقتها من بعد العصر لحد المغرب، ويجوز لحد نص الليل.",
                    fontSize = 14.sp,
                    color = Gold.Gold.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp)
                )
            }
        }

        itemsIndexed(items, key = { index, _ -> "$period:$index" }) { index, dhikr ->
            var count by remember { mutableIntStateOf(prefs.dhikrCount(date, period, index)) }
            DhikrCard(
                dhikr = dhikr,
                count = count,
                onTap = {
                    count += 1
                    prefs.setDhikrCount(date, period, index, count)
                },
                onReset = {
                    count = 0
                    prefs.setDhikrCount(date, period, index, 0)
                }
            )
        }
    }
}

@Composable
private fun Diamond() {
    Canvas(modifier = Modifier.size(10.dp)) {
        val s = this.size.minDimension
        val p = Path()
        p.moveTo(s / 2f, 0f)
        p.lineTo(s, s / 2f)
        p.lineTo(s / 2f, s)
        p.lineTo(0f, s / 2f)
        p.close()
        drawPath(p, Gold.Gold)
    }
}

/** A dark mosque skyline with a warm glow behind it. */
@Composable
private fun Skyline() {
    Canvas(modifier = Modifier.fillMaxWidth().height(62.dp)) {
        val w = this.size.width
        val h = this.size.height
        val dark = Color(0xFF040A07)
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, Color(0xFF1E8449).copy(alpha = 0.55f)),
                startY = 0f,
                endY = h
            )
        )

        fun dome(cx: Float, rx: Float, baseY: Float, ry: Float) {
            val p = Path()
            p.moveTo(cx - rx, baseY)
            p.arcTo(Rect(cx - rx, baseY - ry, cx + rx, baseY + ry), 180f, 180f, false)
            p.close()
            drawPath(p, dark)
        }

        fun minaret(cx: Float, top: Float) {
            val half = w * 0.012f
            drawRect(dark, topLeft = Offset(cx - half, top + h * 0.18f), size = Size(half * 2f, h - top - h * 0.18f))
            drawRect(dark, topLeft = Offset(cx - half * 1.7f, top + h * 0.26f), size = Size(half * 3.4f, h * 0.06f))
            val tip = Path()
            tip.moveTo(cx - half * 1.3f, top + h * 0.18f)
            tip.lineTo(cx, top)
            tip.lineTo(cx + half * 1.3f, top + h * 0.18f)
            tip.close()
            drawPath(tip, dark)
        }

        drawRect(dark, topLeft = Offset(w * 0.12f, h * 0.70f), size = Size(w * 0.76f, h * 0.30f))
        dome(w * 0.50f, w * 0.12f, h * 0.70f, h * 0.62f)
        dome(w * 0.34f, w * 0.05f, h * 0.70f, h * 0.30f)
        dome(w * 0.66f, w * 0.05f, h * 0.70f, h * 0.30f)
        dome(w * 0.22f, w * 0.04f, h * 0.70f, h * 0.24f)
        dome(w * 0.78f, w * 0.04f, h * 0.70f, h * 0.24f)
        dome(w * 0.10f, w * 0.035f, h * 0.85f, h * 0.20f)
        dome(w * 0.90f, w * 0.035f, h * 0.85f, h * 0.20f)
        minaret(w * 0.16f, h * 0.18f)
        minaret(w * 0.84f, h * 0.18f)
        minaret(w * 0.40f, h * 0.30f)
        minaret(w * 0.60f, h * 0.30f)
        drawRect(dark, topLeft = Offset(0f, h * 0.92f), size = Size(w, h * 0.08f))
    }
}

@Composable
private fun PeriodTabs(morning: Boolean, onSelect: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Gold.Black.copy(alpha = 0.6f))
            .border(1.dp, Gold.GoldDark.copy(alpha = 0.85f), shape)
            .padding(4.dp)
    ) {
        PeriodTab("أذكار الصباح", morning, { onSelect(true) }) { tint -> SunGlyph(tint) }
        PeriodTab("أذكار المساء", !morning, { onSelect(false) }) { tint -> MoonGlyph(tint) }
    }
}

@Composable
private fun RowScope.PeriodTab(label: String, isSelected: Boolean, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val tint = if (isSelected) Gold.Black else Gold.Gold
    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier = Modifier
            .weight(1f)
            .clip(shape)
            .then(
                if (isSelected) Modifier.background(Brush.horizontalGradient(listOf(Gold.GoldLight, Gold.Gold)))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        icon(tint)
        Spacer(Modifier.width(10.dp))
        Text(label, color = tint, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun SunGlyph(tint: Color) {
    Canvas(modifier = Modifier.size(22.dp)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        drawCircle(tint, radius = s * 0.20f, center = c)
        for (k in 0 until 8) {
            val a = Math.toRadians(45.0 * k)
            val dx = cos(a).toFloat()
            val dy = sin(a).toFloat()
            drawLine(
                tint,
                Offset(c.x + s * 0.30f * dx, c.y + s * 0.30f * dy),
                Offset(c.x + s * 0.46f * dx, c.y + s * 0.46f * dy),
                1.8.dp.toPx(),
                StrokeCap.Round
            )
        }
    }
}

@Composable
private fun MoonGlyph(tint: Color) {
    Canvas(modifier = Modifier.size(22.dp)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val a = Path()
        a.addOval(Rect(center = c, radius = s * 0.42f))
        val b = Path()
        b.addOval(Rect(center = Offset(c.x + s * 0.17f, c.y - s * 0.12f), radius = s * 0.36f))
        drawPath(Path.combine(PathOperation.Difference, a, b), tint)
    }
}

/** A small flourish in one corner of a card. The corner is at (x, y) and the flourish grows into the card. */
private fun DrawScope.drawCorner(x: Float, y: Float, sx: Float, sy: Float) {
    val u = 1.dp.toPx()
    withTransform({
        translate(left = x, top = y)
        scale(scaleX = sx, scaleY = sy, pivot = Offset.Zero)
    }) {
        val strong = Gold.Gold.copy(alpha = 0.8f)
        val soft = Gold.Gold.copy(alpha = 0.45f)
        drawArc(
            color = strong, startAngle = 0f, sweepAngle = 90f, useCenter = false,
            topLeft = Offset(-34f * u, -34f * u), size = Size(68f * u, 68f * u),
            style = Stroke(width = 1.3f * u)
        )
        drawArc(
            color = soft, startAngle = 0f, sweepAngle = 90f, useCenter = false,
            topLeft = Offset(-24f * u, -24f * u), size = Size(48f * u, 48f * u),
            style = Stroke(width = 1f * u)
        )
        val curl = Path()
        curl.moveTo(8f * u, 8f * u)
        curl.cubicTo(22f * u, 5f * u, 30f * u, 14f * u, 24f * u, 22f * u)
        curl.cubicTo(19f * u, 28f * u, 11f * u, 24f * u, 14f * u, 17f * u)
        drawPath(curl, strong, style = Stroke(width = 1.2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(strong, radius = 2f * u, center = Offset(40f * u, 3f * u))
        drawCircle(strong, radius = 2f * u, center = Offset(3f * u, 40f * u))
    }
}

@Composable
private fun DhikrCard(
    dhikr: Dhikr,
    count: Int,
    onTap: () -> Unit,
    onReset: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    val done = count >= dhikr.times
    val shape = RoundedCornerShape(30.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF10201A), Color(0xFF08120D))))
            .border(
                1.5.dp,
                Brush.verticalGradient(listOf(Gold.Gold.copy(alpha = 0.9f), Gold.GoldDark.copy(alpha = 0.5f))),
                shape
            )
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val inset = 8.dp.toPx()
            val w = this.size.width
            val h = this.size.height
            drawCorner(inset, inset, 1f, 1f)
            drawCorner(w - inset, inset, -1f, 1f)
            drawCorner(inset, h - inset, 1f, -1f)
            drawCorner(w - inset, h - inset, -1f, -1f)
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 22.dp, end = 22.dp, top = 28.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                dhikr.text,
                color = Gold.Ink,
                fontSize = 22.sp,
                lineHeight = 40.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            dhikr.source?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, fontSize = 12.sp, color = Gold.Muted, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(12.dp))
            CounterDivider(count = count, times = dhikr.times, done = done, onTap = onTap, onReset = onReset)
            Spacer(Modifier.height(12.dp))
            CopyPill(copied = copied) {
                clipboard.setText(AnnotatedString(dhikr.text))
                copied = true
            }
        }
    }
}

@Composable
private fun CounterDivider(count: Int, times: Int, done: Boolean, onTap: () -> Unit, onReset: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.weight(1f).height(1.dp)
                .background(Brush.horizontalGradient(listOf(Gold.Gold.copy(alpha = 0.7f), Color.Transparent)))
        )
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(shape)
                .then(
                    if (done) Modifier.background(Brush.horizontalGradient(listOf(Gold.GoldLight, Gold.Gold)))
                    else Modifier.border(1.dp, Gold.Gold.copy(alpha = 0.8f), shape)
                )
                .clickable { if (done) onReset() else onTap() }
                .padding(horizontal = 14.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    done -> "تمّ ✓"
                    times > 1 -> arabicNumber(count) + " / " + arabicNumber(times) + "   اضغط للعدّ"
                    else -> "اضغط عند الانتهاء"
                },
                color = if (done) Gold.Black else Gold.Gold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
        if (count > 0 && !done) {
            Spacer(Modifier.width(8.dp))
            Text(
                "تصفير",
                color = Gold.Muted,
                fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onReset).padding(4.dp)
            )
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.weight(1f).height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold.Gold.copy(alpha = 0.7f))))
        )
    }
}

@Composable
private fun CopyPill(copied: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(Gold.Black.copy(alpha = 0.45f))
            .border(1.dp, Gold.Gold.copy(alpha = 0.75f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (copied) "تم النسخ ✓" else "نسخ الذكر", color = Gold.Gold, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(8.dp))
        Canvas(modifier = Modifier.size(16.dp)) {
            val s = this.size.minDimension
            val w = 1.3.dp.toPx()
            val r = CornerRadius(s * 0.14f)
            drawRoundRect(Gold.Gold, Offset(s * 0.30f, s * 0.05f), Size(s * 0.62f, s * 0.62f), r, style = Stroke(width = w))
            drawRoundRect(Gold.Gold, Offset(s * 0.08f, s * 0.30f), Size(s * 0.62f, s * 0.62f), r, style = Stroke(width = w))
        }
    }
}
