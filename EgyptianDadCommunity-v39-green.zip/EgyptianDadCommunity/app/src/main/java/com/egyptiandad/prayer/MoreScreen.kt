package com.egyptiandad.prayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.findRootCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

/** Size of the artwork in bg_more.jpg. The title and the cards are placed by fractions of it. */
private const val ART_W = 844f
private const val ART_H = 1863f

private val CardFill = Brush.verticalGradient(listOf(Color(0xFF14241B), Color(0xFF08120D)))
private val CardBorder = Brush.linearGradient(listOf(Gold.GoldLight, Gold.GoldDark, Gold.Gold))
private val BadgeFill = Brush.verticalGradient(listOf(Color(0xFF1B3025), Color(0xFF0C1812)))
private val BadgeBorder = Brush.verticalGradient(listOf(Gold.Gold, Gold.GoldDark))

@Composable
fun MoreScreen(onNavigate: (Int) -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current

    // Where this screen sits inside the window, so the title can sit on the banner of the background.
    var rootW by remember { mutableFloatStateOf(0f) }
    var rootH by remember { mutableFloatStateOf(0f) }
    var originY by remember { mutableFloatStateOf(0f) }

    // The background is drawn with Crop from the top, so its height on screen is this.
    val artHeightPx = max(rootH, rootW * ART_H / ART_W)
    fun yAt(fraction: Float): Dp {
        val px = artHeightPx * fraction - originY
        return with(density) { (if (px < 0f) 0f else px).toDp() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onGloballyPositioned { c ->
                val root = c.findRootCoordinates()
                rootW = root.size.width.toFloat()
                rootH = root.size.height.toFloat()
                originY = c.positionInRoot().y
            }
    ) {
        // Title and divider, on top of the banner.
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = yAt(0.092f), start = 26.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text("المزيد", color = Gold.Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            OrnamentLine(modifier = Modifier.width(120.dp).height(12.dp))
        }

        // Cards. Only this part scrolls.
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = yAt(0.215f))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            MoreCard(IconKind.SALAWAT, "الصلاة على النبي ﷺ", "عدّاد يتحفظ تلقائي") { onNavigate(Routes.SALAWAT) }
            MoreCard(IconKind.STREAK, "إنجازي", "سلسلتك وإحصائيات صلاتك") { onNavigate(Routes.STREAK) }
            MoreCard(IconKind.SETTINGS, "الإعدادات", "الأذان والتذكير والمدينة والعرض") { onNavigate(Routes.SETTINGS) }
            MoreCard(IconKind.FACEBOOK, "تابعنا على فيسبوك", "صفحة Egyptian Dad Community") { openLink(ctx, FACEBOOK_URL) }

            OrnamentDivider(modifier = Modifier.fillMaxWidth().height(22.dp).padding(horizontal = 24.dp))

            MorePill(IconKind.STAR, "قيّم التطبيق", "دعمك يصنع الفرق") { rateApp(ctx) }
            MorePill(IconKind.SHARE, "مشاركة التطبيق", "لنشر الخير") { shareApp(ctx) }
        }
    }
}

@Composable
private fun MoreCard(icon: IconKind, title: String, subtitle: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(shape)
            .background(CardFill)
            .border(1.dp, CardBorder, shape)
            .clickable(onClick = onClick)
    ) {
        FaintMosque(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(150.dp)
                .height(64.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val badgeShape = RoundedCornerShape(14.dp)
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(badgeShape)
                    .background(BadgeFill)
                    .border(1.dp, BadgeBorder, badgeShape),
                contentAlignment = Alignment.Center
            ) {
                GoldIcon(icon, Gold.Gold, Modifier.size(20.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Gold.Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1)
            }
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .border(1.dp, Gold.GoldDark, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("‹", color = Gold.Gold, fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun MorePill(icon: IconKind, title: String, subtitle: String, onClick: () -> Unit) {
    val shape: Shape = RoundedCornerShape(28.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
            .height(54.dp)
            .clip(shape)
            .background(CardFill)
            .border(1.dp, CardBorder, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Gold.Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1)
        }
        GoldIcon(icon, Gold.Gold, Modifier.size(20.dp))
    }
}

/** A thin gold line with a small diamond in the middle. */
@Composable
private fun OrnamentLine(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val y = size.height / 2f
        val cx = size.width / 2f
        val line = Brush.horizontalGradient(
            listOf(Color.Transparent, Gold.Gold, Gold.Gold, Color.Transparent)
        )
        drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
        val d = 4.dp.toPx()
        val diamond = Path()
        diamond.moveTo(cx, y - d)
        diamond.lineTo(cx + d, y)
        diamond.lineTo(cx, y + d)
        diamond.lineTo(cx - d, y)
        diamond.close()
        drawPath(diamond, Gold.Gold)
    }
}

/** The line between the cards and the two small buttons, with a little arch in the middle. */
@Composable
private fun OrnamentDivider(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val y = size.height * 0.72f
        val cx = size.width / 2f
        val line = Brush.horizontalGradient(
            listOf(Color.Transparent, Gold.GoldDark, Gold.Gold, Gold.GoldDark, Color.Transparent)
        )
        drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())

        val w = 26.dp.toPx()
        val h = size.height * 0.62f
        val arch = Path()
        arch.moveTo(cx - w, y)
        arch.cubicTo(cx - w * 0.5f, y, cx - w * 0.45f, y - h, cx, y - h)
        arch.cubicTo(cx + w * 0.45f, y - h, cx + w * 0.5f, y, cx + w, y)
        drawPath(arch, Gold.Gold, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.3.dp.toPx()))

        val d = 2.5.dp.toPx()
        for (dx in listOf(-w - 14.dp.toPx(), w + 14.dp.toPx())) {
            val p = Path()
            p.moveTo(cx + dx, y - d)
            p.lineTo(cx + dx + d, y)
            p.lineTo(cx + dx, y + d)
            p.lineTo(cx + dx - d, y)
            p.close()
            drawPath(p, Gold.Gold)
        }
    }
}

/** A very faint mosque skyline in the corner of a card. */
@Composable
private fun FaintMosque(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val color = Gold.Gold.copy(alpha = 0.07f)

        fun dome(cx: Float, rx: Float, baseY: Float, ry: Float) {
            val p = Path()
            p.moveTo(cx - rx, baseY)
            p.arcTo(Rect(cx - rx, baseY - ry, cx + rx, baseY + ry), 180f, 180f, false)
            p.close()
            drawPath(p, color)
        }

        fun minaret(cx: Float, top: Float) {
            val half = w * 0.025f
            drawRect(color, topLeft = Offset(cx - half, top), size = androidx.compose.ui.geometry.Size(half * 2f, h - top))
            val tip = Path()
            tip.moveTo(cx - half * 1.4f, top)
            tip.lineTo(cx, top - h * 0.18f)
            tip.lineTo(cx + half * 1.4f, top)
            tip.close()
            drawPath(tip, color)
        }

        drawRect(color, topLeft = Offset(w * 0.30f, h * 0.70f), size = androidx.compose.ui.geometry.Size(w * 0.50f, h * 0.30f))
        dome(w * 0.55f, w * 0.15f, h * 0.70f, h * 0.38f)
        dome(w * 0.36f, w * 0.06f, h * 0.70f, h * 0.18f)
        dome(w * 0.74f, w * 0.06f, h * 0.70f, h * 0.18f)
        minaret(w * 0.18f, h * 0.35f)
        minaret(w * 0.88f, h * 0.42f)
    }
}
