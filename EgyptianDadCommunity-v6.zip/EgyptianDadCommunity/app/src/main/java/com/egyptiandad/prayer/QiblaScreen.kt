package com.egyptiandad.prayer

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Qibla {
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LON = 39.8262

    /** Direction to the Kaaba in degrees clockwise from true north. */
    fun bearing(lat: Double, lon: Double): Double {
        val p1 = Math.toRadians(lat)
        val p2 = Math.toRadians(KAABA_LAT)
        val dl = Math.toRadians(KAABA_LON - lon)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }
}

private fun smoothAngle(old: Float, new: Float): Float {
    val diff = ((new - old + 540f) % 360f) - 180f
    return (old + diff * 0.2f + 360f) % 360f
}

/** Phone heading in degrees from magnetic north, or null until the first sensor reading. */
@Composable
private fun rememberMagneticHeading(): Float? {
    val ctx = LocalContext.current
    var heading by remember { mutableStateOf<Float?>(null) }
    DisposableEffect(Unit) {
        val manager = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val rotation = FloatArray(9)
        val orientation = FloatArray(3)
        var smoothed = Float.NaN
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(rotation, event.values)
                SensorManager.getOrientation(rotation, orientation)
                val azimuth = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
                smoothed = if (smoothed.isNaN()) azimuth else smoothAngle(smoothed, azimuth)
                heading = smoothed
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { manager.unregisterListener(listener) }
    }
    return heading
}

@Composable
fun QiblaScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val city = Cities.of(prefs)

    val bearing = remember(city.lat, city.lon) { Qibla.bearing(city.lat, city.lon).toFloat() }
    val declination = remember(city.lat, city.lon) {
        GeomagneticField(city.lat.toFloat(), city.lon.toFloat(), 0f, System.currentTimeMillis()).declination
    }

    val magnetic = rememberMagneticHeading()
    val heading: Float? = if (magnetic != null) (magnetic + declination + 360f) % 360f else null
    val angle: Float = if (heading != null) (bearing - heading + 360f) % 360f else bearing
    val aligned = heading != null && (angle < 4f || angle > 356f)

    val ringColor = MaterialTheme.colorScheme.onSurfaceVariant
    val arrowColor = if (aligned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "اتجاه القبلة من " + city.arabic,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )

        Canvas(modifier = Modifier.size(280.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f - 8.dp.toPx()

            drawCircle(
                color = ringColor.copy(alpha = 0.35f),
                radius = r,
                center = c,
                style = Stroke(width = 3.dp.toPx())
            )

            // Small dot on the ring that always points to north.
            rotate(degrees = -(heading ?: 0f), pivot = c) {
                drawCircle(color = ringColor, radius = 7.dp.toPx(), center = Offset(c.x, c.y - r))
            }

            rotate(degrees = angle, pivot = c) {
                val arrow = Path()
                arrow.moveTo(c.x, c.y - r * 0.82f)
                arrow.lineTo(c.x + r * 0.16f, c.y - r * 0.38f)
                arrow.lineTo(c.x + r * 0.05f, c.y - r * 0.38f)
                arrow.lineTo(c.x + r * 0.05f, c.y + r * 0.30f)
                arrow.lineTo(c.x - r * 0.05f, c.y + r * 0.30f)
                arrow.lineTo(c.x - r * 0.05f, c.y - r * 0.38f)
                arrow.lineTo(c.x - r * 0.16f, c.y - r * 0.38f)
                arrow.close()
                drawPath(path = arrow, color = arrowColor)
            }
        }

        Text(
            text = when {
                magnetic == null -> "بجهّز البوصلة... لو مفيش حاجة بتتحرك يبقى الموبايل مفيهوش حساس اتجاه، وده الاتجاه بالدرجات."
                aligned -> "أنت في اتجاه القبلة"
                else -> "لفّ لحد ما السهم يبقى لفوق"
            },
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = if (aligned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "القبلة ${arabicNumber(bearing.roundToInt())}° من الشمال الحقيقي",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "ضع الموبايل أفقي وبعيد عن المعادن والمغناطيس. لو القراءة مش مظبوطة، حرّك الموبايل على شكل ٨ في الهوا كذا مرة. النقطة الصغيرة على الدايرة بتشاور على الشمال.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
