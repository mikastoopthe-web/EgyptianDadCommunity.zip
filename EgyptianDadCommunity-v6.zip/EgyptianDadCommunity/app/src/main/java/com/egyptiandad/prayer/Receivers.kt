package com.egyptiandad.prayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fires at the start of a prayer and then at every repeat until the prayer is marked or its time ends. */
class PrayerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra(Scheduler.EXTRA_KEY)
        val at = intent.getLongExtra(Scheduler.EXTRA_AT, 0L)
        val now = System.currentTimeMillis()
        val prefs = Prefs(context)

        if (key != null && prefs.remindersOn && !prefs.isPrayed(key)) {
            val city = Cities.of(prefs)
            val event = PrayerTimes.events(city, PrayerTimes.today(now)).firstOrNull { it.key == key }
            // Skip a reminder that arrives after its prayer time already ended (phone was off or asleep).
            if (event == null || now < event.end) {
                Notifier.show(context, key, intent.getBooleanExtra(Scheduler.EXTRA_REPEAT, false))
            }
        }
        Scheduler.scheduleNext(context, maxOf(now, at))
    }
}

/** The "صلّيت" button on the notification. */
class PrayedReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION = "com.egyptiandad.prayer.PRAYED"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra(Scheduler.EXTRA_KEY) ?: return
        Prefs(context).setPrayed(key, true)
        Notifier.cancel(context, key)
        Scheduler.scheduleNext(context)
    }
}

/** Re-arms the alarm after reboot, app update, clock change or a change in exact-alarm permission. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.scheduleNext(context)
    }
}
