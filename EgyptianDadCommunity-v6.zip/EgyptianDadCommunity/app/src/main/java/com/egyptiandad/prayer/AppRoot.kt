package com.egyptiandad.prayer

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppRoot() {
    var tab by remember { mutableIntStateOf(0) }
    val labels = listOf("المواقيت", "القبلة", "الأذكار", "الصلاة ﷺ", "إنجازي", "الإعدادات")

    Box(modifier = Modifier.fillMaxSize()) {
        GeometricBackground()
        Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
            Box(modifier = Modifier.weight(1f)) {
                Crossfade(targetState = tab, animationSpec = tween(250), label = "screen") { page ->
                    when (page) {
                        0 -> TimesScreen()
                        1 -> QiblaScreen()
                        2 -> AdhkarScreen()
                        3 -> SalawatScreen()
                        4 -> StreakScreen()
                        else -> SettingsScreen()
                    }
                }
            }
            GoldBottomBar(selected = tab, labels = labels, onSelect = { tab = it })
        }
    }
}

@Composable
private fun GoldBottomBar(selected: Int, labels: List<String>, onSelect: (Int) -> Unit) {
    Column {
        HorizontalDivider(color = Gold.Line)
        Row(modifier = Modifier.fillMaxWidth().background(Gold.Surface)) {
            labels.forEachIndexed { index, label ->
                val isSelected = index == selected
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) Gold.Gold else Gold.Muted,
                    label = "tabColor"
                )
                val indicator by animateDpAsState(
                    targetValue = if (isSelected) 24.dp else 0.dp,
                    label = "tabIndicator"
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelect(index) }
                        .padding(top = 8.dp, bottom = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .height(3.dp)
                            .width(indicator)
                            .background(Gold.Gold, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        label,
                        color = textColor,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
