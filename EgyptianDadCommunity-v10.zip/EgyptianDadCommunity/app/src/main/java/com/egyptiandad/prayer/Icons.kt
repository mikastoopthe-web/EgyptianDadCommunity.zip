package com.egyptiandad.prayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

enum class IconKind { HOME, QIBLA, RADIO, ADHKAR, MORE, SALAWAT, STREAK, SETTINGS, PLAY, STOP, FACEBOOK, CALENDAR, PIN, CLOCK, TROPHY, HOURGLASS, CHECK, PROFILE, MOSQUE, MINARET, TROPHY_LAUREL }

private class ParsedLayer(val path: Path, val fill: Boolean, val stroke: Float)

private val artCache = HashMap<IconKind, List<ParsedLayer>>()

/** The drawn artwork for an icon, or null when the icon is still drawn by the code below. */
private fun artFor(kind: IconKind): List<ParsedLayer>? {
    val key = if (kind == IconKind.STREAK) IconKind.TROPHY else kind
    artCache[key]?.let { return it }
    val source = ICON_ART[key] ?: return null
    val parsed = source.map { layer ->
        val path = PathParser().parsePathString(layer.d).toPath()
        path.fillType = PathFillType.EvenOdd
        ParsedLayer(path, layer.mode != 'S', if (layer.mode == 'F') 0f else layer.width)
    }
    artCache[key] = parsed
    return parsed
}

/** Simple line icons drawn in code, so the app needs no image files. */
@Composable
fun GoldIcon(kind: IconKind, tint: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier = modifier) {
        val s = size.minDimension
        val art = artFor(kind)
        if (art != null) {
            withTransform({ scale(s / 100f, s / 100f, pivot = Offset.Zero) }) {
                for (layer in art) {
                    if (layer.fill) drawPath(layer.path, tint)
                    if (layer.stroke > 0f) {
                        drawPath(layer.path, tint, style = Stroke(width = layer.stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
            }
            return@Canvas
        }
        val stroke = Stroke(width = s * 0.08f, cap = StrokeCap.Round)
        when (kind) {
            IconKind.HOME -> {
                val dome = Path()
                dome.moveTo(s * 0.18f, s * 0.82f)
                dome.lineTo(s * 0.18f, s * 0.50f)
                dome.quadraticTo(s * 0.50f, s * 0.00f, s * 0.82f, s * 0.50f)
                dome.lineTo(s * 0.82f, s * 0.82f)
                dome.close()
                drawPath(dome, tint, style = stroke)
                drawLine(tint, Offset(s * 0.50f, s * 0.08f), Offset(s * 0.50f, s * 0.02f), s * 0.08f, StrokeCap.Round)
                drawRect(tint, Offset(s * 0.42f, s * 0.60f), Size(s * 0.16f, s * 0.22f))
            }
            IconKind.QIBLA -> {
                drawCircle(tint, radius = s * 0.42f, center = center, style = stroke)
                val needle = Path()
                needle.moveTo(center.x, s * 0.20f)
                needle.lineTo(center.x + s * 0.12f, center.y)
                needle.lineTo(center.x, s * 0.80f)
                needle.lineTo(center.x - s * 0.12f, center.y)
                needle.close()
                drawPath(needle, tint)
            }
            IconKind.RADIO -> {
                drawRoundRect(tint, Offset(s * 0.12f, s * 0.36f), Size(s * 0.76f, s * 0.48f), CornerRadius(s * 0.1f), style = stroke)
                drawLine(tint, Offset(s * 0.30f, s * 0.36f), Offset(s * 0.72f, s * 0.12f), s * 0.07f, StrokeCap.Round)
                drawCircle(tint, radius = s * 0.11f, center = Offset(s * 0.34f, s * 0.60f))
                drawLine(tint, Offset(s * 0.54f, s * 0.54f), Offset(s * 0.76f, s * 0.54f), s * 0.06f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.54f, s * 0.68f), Offset(s * 0.76f, s * 0.68f), s * 0.06f, StrokeCap.Round)
            }
            IconKind.ADHKAR -> {
                val left = Path()
                left.moveTo(s * 0.50f, s * 0.26f)
                left.lineTo(s * 0.14f, s * 0.20f)
                left.lineTo(s * 0.14f, s * 0.78f)
                left.lineTo(s * 0.50f, s * 0.84f)
                left.close()
                val right = Path()
                right.moveTo(s * 0.50f, s * 0.26f)
                right.lineTo(s * 0.86f, s * 0.20f)
                right.lineTo(s * 0.86f, s * 0.78f)
                right.lineTo(s * 0.50f, s * 0.84f)
                right.close()
                drawPath(left, tint, style = stroke)
                drawPath(right, tint, style = stroke)
            }
            IconKind.MORE -> {
                for (i in 0 until 3) {
                    drawCircle(tint, radius = s * 0.09f, center = Offset(s * (0.22f + 0.28f * i), s * 0.5f))
                }
            }
            IconKind.SALAWAT -> {
                val outer = Path()
                outer.addOval(Rect(center = center, radius = s * 0.40f))
                val cut = Path()
                cut.addOval(Rect(center = Offset(center.x + s * 0.17f, center.y - s * 0.07f), radius = s * 0.34f))
                val moon = Path.combine(PathOperation.Difference, outer, cut)
                drawPath(moon, tint)
                drawCircle(tint, radius = s * 0.05f, center = Offset(s * 0.72f, s * 0.30f))
            }
            IconKind.STREAK -> {
                for (k in 0 until 2) {
                    val star = Path()
                    for (n in 0 until 4) {
                        val a = Math.toRadians(45.0 * k + 90.0 * n + 45.0)
                        val x = center.x + s * 0.42f * cos(a).toFloat()
                        val y = center.y + s * 0.42f * sin(a).toFloat()
                        if (n == 0) star.moveTo(x, y) else star.lineTo(x, y)
                    }
                    star.close()
                    drawPath(star, tint, style = stroke)
                }
            }
            IconKind.SETTINGS -> {
                drawCircle(tint, radius = s * 0.16f, center = center, style = stroke)
                for (k in 0 until 8) {
                    val a = Math.toRadians(45.0 * k)
                    val c = cos(a).toFloat()
                    val d = sin(a).toFloat()
                    drawLine(
                        tint,
                        Offset(center.x + s * 0.30f * c, center.y + s * 0.30f * d),
                        Offset(center.x + s * 0.42f * c, center.y + s * 0.42f * d),
                        s * 0.09f,
                        StrokeCap.Round
                    )
                }
                drawCircle(tint, radius = s * 0.30f, center = center, style = stroke)
            }
            IconKind.PLAY -> {
                val p = Path()
                p.moveTo(s * 0.28f, s * 0.16f)
                p.lineTo(s * 0.84f, s * 0.50f)
                p.lineTo(s * 0.28f, s * 0.84f)
                p.close()
                drawPath(p, tint)
            }
            IconKind.STOP -> {
                drawRoundRect(tint, Offset(s * 0.20f, s * 0.20f), Size(s * 0.60f, s * 0.60f), CornerRadius(s * 0.08f))
            }
            IconKind.CALENDAR -> {
                drawRoundRect(tint, Offset(s * 0.14f, s * 0.22f), Size(s * 0.72f, s * 0.64f), CornerRadius(s * 0.1f), style = stroke)
                drawLine(tint, Offset(s * 0.14f, s * 0.42f), Offset(s * 0.86f, s * 0.42f), s * 0.07f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.34f, s * 0.12f), Offset(s * 0.34f, s * 0.28f), s * 0.07f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.66f, s * 0.12f), Offset(s * 0.66f, s * 0.28f), s * 0.07f, StrokeCap.Round)
                drawCircle(tint, radius = s * 0.04f, center = Offset(s * 0.34f, s * 0.60f))
                drawCircle(tint, radius = s * 0.04f, center = Offset(s * 0.50f, s * 0.60f))
                drawCircle(tint, radius = s * 0.04f, center = Offset(s * 0.66f, s * 0.60f))
            }
            IconKind.PIN -> {
                drawCircle(tint, radius = s * 0.24f, center = Offset(s * 0.5f, s * 0.38f), style = stroke)
                drawLine(tint, Offset(s * 0.30f, s * 0.54f), Offset(s * 0.5f, s * 0.90f), s * 0.08f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.70f, s * 0.54f), Offset(s * 0.5f, s * 0.90f), s * 0.08f, StrokeCap.Round)
                drawCircle(tint, radius = s * 0.07f, center = Offset(s * 0.5f, s * 0.38f))
            }
            IconKind.CLOCK -> {
                drawCircle(tint, radius = s * 0.42f, center = center, style = stroke)
                drawLine(tint, center, Offset(center.x, s * 0.26f), s * 0.08f, StrokeCap.Round)
                drawLine(tint, center, Offset(s * 0.68f, s * 0.58f), s * 0.08f, StrokeCap.Round)
            }
            IconKind.TROPHY -> {
                val cup = Path()
                cup.moveTo(s * 0.28f, s * 0.14f)
                cup.lineTo(s * 0.72f, s * 0.14f)
                cup.lineTo(s * 0.72f, s * 0.38f)
                cup.quadraticTo(s * 0.72f, s * 0.60f, s * 0.50f, s * 0.60f)
                cup.quadraticTo(s * 0.28f, s * 0.60f, s * 0.28f, s * 0.38f)
                cup.close()
                drawPath(cup, tint, style = stroke)
                val left = Path()
                left.moveTo(s * 0.28f, s * 0.22f)
                left.quadraticTo(s * 0.10f, s * 0.22f, s * 0.12f, s * 0.36f)
                left.quadraticTo(s * 0.14f, s * 0.46f, s * 0.28f, s * 0.46f)
                drawPath(left, tint, style = stroke)
                val right = Path()
                right.moveTo(s * 0.72f, s * 0.22f)
                right.quadraticTo(s * 0.90f, s * 0.22f, s * 0.88f, s * 0.36f)
                right.quadraticTo(s * 0.86f, s * 0.46f, s * 0.72f, s * 0.46f)
                drawPath(right, tint, style = stroke)
                drawLine(tint, Offset(s * 0.5f, s * 0.60f), Offset(s * 0.5f, s * 0.78f), s * 0.08f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.34f, s * 0.84f), Offset(s * 0.66f, s * 0.84f), s * 0.09f, StrokeCap.Round)
            }
            IconKind.HOURGLASS -> {
                val top = Path()
                top.moveTo(s * 0.26f, s * 0.14f)
                top.lineTo(s * 0.74f, s * 0.14f)
                top.lineTo(s * 0.50f, s * 0.50f)
                top.close()
                val bottom = Path()
                bottom.moveTo(s * 0.50f, s * 0.50f)
                bottom.lineTo(s * 0.74f, s * 0.86f)
                bottom.lineTo(s * 0.26f, s * 0.86f)
                bottom.close()
                drawPath(top, tint, style = stroke)
                drawPath(bottom, tint)
                drawLine(tint, Offset(s * 0.22f, s * 0.14f), Offset(s * 0.78f, s * 0.14f), s * 0.07f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.22f, s * 0.86f), Offset(s * 0.78f, s * 0.86f), s * 0.07f, StrokeCap.Round)
            }
            IconKind.CHECK -> {
                drawLine(tint, Offset(s * 0.22f, s * 0.54f), Offset(s * 0.42f, s * 0.74f), s * 0.11f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.42f, s * 0.74f), Offset(s * 0.80f, s * 0.28f), s * 0.11f, StrokeCap.Round)
            }
            IconKind.FACEBOOK -> {
                drawCircle(tint, radius = s * 0.44f, center = center, style = stroke)
                drawLine(tint, Offset(s * 0.56f, s * 0.84f), Offset(s * 0.56f, s * 0.36f), s * 0.09f, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.42f, s * 0.50f), Offset(s * 0.70f, s * 0.50f), s * 0.08f, StrokeCap.Round)
                val hook = Path()
                hook.moveTo(s * 0.56f, s * 0.38f)
                hook.quadraticTo(s * 0.56f, s * 0.22f, s * 0.72f, s * 0.22f)
                drawPath(hook, tint, style = stroke)
            }
            else -> {}
        }
    }
}

/** A gold ring with the icon in it and the label under it, like the feature buttons in the design. */
@Composable
fun FeatureButton(kind: IconKind, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(66.dp)
                .clip(CircleShape)
                .background(Gold.Black.copy(alpha = 0.7f))
                .border(1.5.dp, Gold.Gold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            GoldIcon(kind, Gold.Gold, Modifier.size(32.dp))
        }
        Text(label, color = Gold.Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** A row of feature buttons. */
@Composable
fun FeatureRow(items: List<Triple<IconKind, String, () -> Unit>>) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        for ((kind, label, action) in items) {
            FeatureButton(kind, label, action, Modifier.weight(1f))
        }
    }
}
